/* jshint devel:true */
console.log('\'Allo \'Allo!');
