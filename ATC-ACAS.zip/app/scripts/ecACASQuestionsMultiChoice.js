var EC_ACAS_Questions_Multi_Choice = (function($)
{
    'use strict';
    
    var module = {},
        questionData;
    
    module.createQuestion = function (_parentElement, _data) {
        
    };
    
    module.selectRadio = function (_data) {
        
    };
    
    module.mcRandomise = function (_data) {
        
    };
    
    module.mcReset = function (_data) {
        
    };
    
    module.createQuestion = function (_data) {
        
    };
    
    return module;
    
}($));