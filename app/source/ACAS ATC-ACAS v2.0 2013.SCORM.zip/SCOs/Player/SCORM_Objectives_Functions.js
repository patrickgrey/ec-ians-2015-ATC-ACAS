function fSetObjectiveStatus( p_sObjectiveID, p_sStatus )
{
	API = parent.API;
	
	if ( !API || !API.SetValue )
		return;
	
	// searches through each objective available via the LMS
	var nNumObjectives = API.GetValue( "cmi.objectives._count" );
	for ( var i = 0; i < nNumObjectives; i++ )
	{
		// if the objective matches the one we're looking for, set the status
		var sObjectiveID = API.GetValue( "cmi.objectives." + i + ".id" );
		if ( sObjectiveID == p_sObjectiveID )
		{
			// if the status is already set to failed, don't set it - basically once you fail an objective, you've failed it
			var sCurrStatus = API.GetValue( "cmi.objectives." + i + ".success_status" );
			if ( sCurrStatus != "failed" )
				API.SetValue( "cmi.objectives." + i + ".success_status", p_sStatus );
			
			return;
		}
	}
}
