//PHP's urlencode is used to encode the data and javascript unescape is used to decode it.
//The one difference is that PHP's urlencode converts spaces to plus signs but javascript's
//unescape does not convert the plus signs back to spaces so this is done manually below.
//Actual plus signs are safe as they are encoded by PHP....

var MainLoaded = false;
var Widgets = new Array ( );
var HookableEvents = new Array();
var MouseDownHandled = false;
var g_QuestionTracking = new Array();

function fsBuildAnswers( p_sLaunchData )
{
	var asTempAnswers = p_sLaunchData.split("|");
	for ( var i = 0; i < asTempAnswers.length; i++ )
	{
		var oTemp = g_asAnswers;
		var asTempAnswerData = asTempAnswers[i].split(",");
		var nNumAnswers = asTempAnswerData.length;
		for ( var j = 0; j < nNumAnswers - 1; j++ )
		{
			if ( j < nNumAnswers - 2 )
			{
				if ( oTemp[asTempAnswerData[j]] == null )
					oTemp[asTempAnswerData[j]] = new Array();
				oTemp = oTemp[asTempAnswerData[j]];
			}
			else
				oTemp[asTempAnswerData[j]] = decodeURIComponent(asTempAnswerData[asTempAnswerData.length - 1].replace(/\+/g,' '));
		}
	}
}

function RandomizeQuestions()
{
  if(!window.RandomQuestions)
    return;

  var i,Swap1,Swap2,TempSwap;
  var Limit = window.g_aDOCs.length-1; //length of all available pages
  var ShuffleArray = new Array();

  //Load ALL pages into an array for shuffling (with questions values to keep accurate after shuffle)
  for(i=0;i<=Limit;i++)
  {
    ShuffleArray[i] = new Array(window.g_aDOCs[i][1],window.g_aDOCs[i][2]);
  }

  //Let's shuffle them up!!!!
  for(i=0;i<5000;i++)
  {
    Swap1 = Math.round(Math.random() * Limit);
    Swap2 = Math.round(Math.random() * Limit);
    TempSwap = ShuffleArray[Swap1];
    ShuffleArray[Swap1] = ShuffleArray[Swap2];
    ShuffleArray[Swap2] = TempSwap;
  }

  //Reload g_aPages array with shuffled questions and set TotalScoreSCO
  window.TotalScoreSCO = 0;
  for(i=0;i<window.RandomQuestions;i++)
  {
    window.g_aPages[i][0] = ShuffleArray[i][0];
    window.TotalScoreSCO += ShuffleArray[i][1];
  }
}
