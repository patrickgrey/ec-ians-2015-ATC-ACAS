var g_bDisplayErrorMessages = true;
var g_bFinished = false;
var EndPageShowing = false;
var EndOfSCO = false;

function fDisplayError()
{
	if ( !g_bDisplayErrorMessages )
		return;
	
	var sError = ""
		+ "Error Code: " + API.LMSGetLastError() + "\n\n"
		+ API.LMSGetErrorString(API.LMSGetLastError()) + "\n\n"
		+ API.LMSGetDiagnostic(API.LMSGetLastError())
	
	alert(sError);
}
function LMSFinish()
{
      if(!window.ScoredMessageTxt){
        ScoredMessageTxt = 'You scored'; 
      }
      
	if ( !API || g_bFinished )
		return;
	
	Score = 0;
	for(i in g_anScores)
	{
	  Score+=(typeof(g_anScores[i][0]) == 'undefined')?0:g_anScores[i][0];
	}
    
        if(TotalScoreSCO > 0) //Diagnostic Cluster
        {
	  var nPercentage = Math.floor(Score / TotalScoreSCO * 100);
	  var sPercentage = String((nPercentage < 0) ? 0 : nPercentage);
	  var MasteryPct = parseInt(API.LMSGetValue("cmi.student_data.mastery_score"),10);
	  if(isNaN(MasteryPct)) MasteryPct = MasteryScore;
	  PassFail = (sPercentage < MasteryPct) ? 'failed' : 'passed';
        }

	if(window.ShowEndPage && !EndPageShowing && EndOfSCO)
	{
  	  EndPageShowing = true;

          Content.document.write('<TABLE WIDTH="100%" HEIGHT="100%"><TR><TD ALIGN="CENTER" VALIGN="CENTER">');

          if(ShowScore && TotalScoreSCO > 0)
	    Content.document.write('<SPAN STYLE="font-family:arial;font-size:12pt;font-weight:bold;">' + ScoredMessageTxt + ' ' + Score+' / '+TotalScoreSCO+' = '+sPercentage+'%</SPAN><BR><BR>');

          if(EndTextMessage)
	    Content.document.write(EndTextMessage+'<BR><BR>');

          if(TotalScoreSCO > 0) //Diagnostic Cluster
          {
            if(PassFail == 'passed')
  	      Content.document.write('<SPAN STYLE="font-size:14pt;color:green;">'+PassMessageTxt+'</SPAN>');
            else
  	      Content.document.write('<SPAN STYLE="font-size:14pt;color:red;">'+FailMessageTxt+'</SPAN>');
          }

          Content.document.write('</TD></TR></TABLE>');

	  Functions.RightArrow = Functions.LeftArrow = Functions.CourseHome = Functions.CloseWin;

          return;
	}

	// setting the bookmark
	var sLocation = "";
	if ( !DiagnosticMode )
		sLocation = String( PageNum );
	
	if ( PageNum != g_aDOCs.length )
	{
		API.LMSSetValue( "cmi.core.lesson_location", sLocation );
		API.LMSSetValue( "cmi.core.exit", "suspend" );
	}
	else
	{
		API.LMSSetValue( "cmi.core.lesson_location", "" );
		API.LMSSetValue( "cmi.core.exit", "" );
	}
	
    var sMode = API.LMSGetValue("cmi.core.lesson_mode");
    if ( API.LMSGetLastError() == "0" )
        sMode = "normal";
	if ( TotalScoreSCO > 0 && sMode == "normal" )
	{
		API.LMSSetValue("cmi.core.score.raw", sPercentage);
		API.LMSSetValue("cmi.core.lesson_status", PassFail);
	}
	else
	{
		var sLessonStatus = "completed";
		for ( key in PagesVisited )
		{
			if ( !PagesVisited[ key ].visited &&  PagesVisited[ key ].countInCompletion )
			{
				sLessonStatus = "incomplete";
				break;
			}
		}
		var sCompletionString = "";
		for ( key in PagesVisited )
			sCompletionString += ( !PagesVisited[ key ].visited ? "0" : "1" )
		API.LMSSetValue( "cmi.suspend_data", sCompletionString );
		API.LMSSetValue( "cmi.core.lesson_status", sLessonStatus );
	}
	
	if ( !API.LMSFinish("") )
		fDisplayError();
	else
		g_bFinished = true;
}

function LMSInitialize()
{
	if ( !API )
		return;
	
	if ( !API.LMSInitialize("") )
		fDisplayError();
	
	// filling the answers array
	if ( g_asAnswers != null )
	{
//		var sLaunchData = API.LMSGetValue("cmi.launch_data");
		if ( sLaunchData != "" )
			fsBuildAnswers(sLaunchData);
	}
	
	// retrieving PagesVisited data if it exists
	var sCompletionString = API.LMSGetValue( "cmi.suspend_data" );
	if ( sCompletionString != "" )
	{
		var nCurrCharIndex = 0;
		for ( key in PagesVisited )
		{
			PagesVisited[ key ].visited = ( sCompletionString.charAt( nCurrCharIndex ) == "1" ? true : false );
			nCurrCharIndex++;
		}
	}
	
	// moving to the existing bookmark if there is one
	var sLessonLocation = API.LMSGetValue( "cmi.core.lesson_location" );
	if ( sLessonLocation == "" )
		Functions.fGoToPage( 1 );
	else
		Functions.fGoToPage( Number( sLessonLocation ) );
}

function findAPI( p_oWindow ) 
{
	var oAPI = null;
    var nDepth = 0;
	
    while ( p_oWindow.API == null && p_oWindow.parent != null && p_oWindow.parent != p_oWindow )
    {
        nDepth++;
        if ( nDepth > 7 )
            return null;
        p_oWindow = p_oWindow.parent;
    }
	
    return p_oWindow.API;
}
function getAPI()
{
	var oAPI = findAPI( window );
	
	if ( oAPI == null && window.opener != null && typeof( window.opener ) != "undefined" )
		oAPI = findAPI( window.opener );
	
	return oAPI;
}

API = getAPI();
//if(API == null)
//  alert('Cannot find LMS API');
