//   define the start pages for each frame
var  topic0_L = "topic_0/m01_t00_p00.htm";
var  topic0_R = "topic_0/m01_t00_p00_1r.htm";
var  topic1_L = "topic_1/m01_t01_p00.htm";
var  topic1_R = "topic_1/m01_t01_p00_1r.htm";
var  topic2_L = "topic_2/m01_t02_p00.htm";
var  topic2_R = "topic_2/m01_t02_p00_1r.htm";
var  topic3_L = "topic_3/m01_t03_p00.htm";
var  topic3_R = "topic_3/m01_t03_p00_1r.htm";
var  topic4_L = "topic_4/m01_t04_p00.htm";
var  topic4_R = "topic_4/m01_t04_p00_1r.htm";

// list of pages for each topic in module
var pageList0_L = new Array("m01_t00_p00.htm");
var pageList0_R = new Array("m01_t00_p00_1r.htm");
var pageList1_L = new Array("m01_t01_p00.htm","m01_t01_p05.htm","m01_t01_p10.htm","m01_t01_p15.htm","m01_t01_p20.htm");
var pageList1_R = new Array("m01_t01_p00_1r.htm","m01_t01_p05_1r.htm","m01_t01_p10_1r.htm","m01_t01_p15_1r.htm","m01_t01_p20_1r.htm");
var pageList2_L = new Array("m01_t02_p00.htm","m01_t02_p05.htm","m01_t02_p10.htm","m01_t02_p15.htm","m01_t02_p20.htm","m01_t02_p25.htm");
var pageList2_R = new Array("m01_t02_p00_1r.htm","m01_t02_p05_1r.htm","m01_t02_p10_1r.htm","m01_t02_p15_1r.htm","m01_t02_p20_1r.htm","m01_t02_p25_1r.htm");
var pageList3_L = new Array("m01_t03_p00.htm");
var pageList3_R = new Array("m01_t03_p00_1r.htm");
var pageList4_L = new Array("m01_t04_p00.htm","m01_t04_p05.htm","m01_t04_p10.htm");
var pageList4_R = new Array("m01_t04_p00_1r.htm","m01_t04_p05_1r.htm","m01_t04_p10_1r.htm");

// these arrays to pick up the list of pages for each topic
var pageListL = new Array();
var pageListR = new Array();
var totalPages;
var currenttopic = 3; //value to modify for each imported topic
var currentPageRef ;
var topicstatus = "FFF"; //the total number of F should be equal or greater than the total number of topics of the module

function init_topic() {
	loadNewPage(0);
}

function loadNewPage(x) {
	var contentFramePath = String(self.location);
	var lastSlash = contentFramePath.lastIndexOf("/");
	var uptoIndex = contentFramePath.substring(0,lastSlash+1);
	
	self.pageListL=eval("self.pageList" + self.currenttopic + "_L");
	self.pageListR=eval("self.pageList" + self.currenttopic + "_R");
	self.totalPages=(eval("self.pageList" + self.currenttopic + "_L.length"));
	
	if (x < self.pageListL.length) {
		//NH: I think we have a / too much here, but it seems to work anyway...
		left.location = uptoIndex + "/" + "topic_" + self.currenttopic + "/" + self.pageListL[x];
		right.location = uptoIndex + "/" + "topic_" + self.currenttopic + "/" + self.pageListR[x];
		self.currentPageRef = x+1; //used to display page number.
	} else {
		alert("system error: page number higher than total of pages that exist.");
	}
}