/* Series of functions for Navigation based on ForceTen functions*/

/*///////////////////////////////////////////
////////////General functions////////////////
///////////////////////////////////////////*/
/*This set of functions are the basic functions to be able to develop javascript coding in F10.
The goal of these functions is to be able to define functions which are independant, as much as possible, from the type of delivery.
The code developer should be able to use them without having to think about the type of delivery the content is being developed for.

In the case that F10 packaging would evolve, there might be a need to update these functions.
However code based on these functions should remain much alike.
*/


/*///////////Functions to identify the type of delivery ////////////*/

/* 3 types of deliveries are possible:
a) Dynamic: content delivered from the LCMS (during a preview of the course, if the course is distributed throught the portal or if the course is delivered through an LMS with a dynamic manifest).
b) Static: Content packaged and delivered from an LMS (when using a SCORM Content package)
c) Standalone (When course is packaged in SCORM Content package and it is launched from the RunCourse.html and not from the manifest through LMS actions)
These functions have not been tested for dynamic integration of content (access of content on the LCMS from the LMS interface). Content has been slightly tested with a dynamic manifest distributed to an LMS.

Dynamic is often refered in F10 documentation as Online whereas Static and Standalone are referred as Offline.

Identification of delivery is necessary as content is packaged differently according to the type of delivery.
The content structure and frameset are different thus Java Script reference to frames have to be modified.
Access to word in glossary is different if there is a dynamic integration of content or not.
Page numbering is likely to be different according to the type of delivery.
*/

/*Function code provided by Eedo knowledgware to identify if content is delivered from the LCMS or not.
To be checked it seems to be working. */
function deliveryIsDynamic() {
	var mainFrameset = getMainFrameset();
	if (mainFrameset) {
		if (typeof(mainFrameset.g_anScores) == "undefined")
		{
			return true; /*Dynamic delivery*/
		}
	}
  	else
  	{
    	return false; /*Static or Standalone delivery*/
  	}
}

/*function that checks if the content has been packaged and delivered within an LMS*/
function deliveryIsStaticLMS() {
	var isStaticLMS = false;
	var scormFrame = getSCORMAPIFrame();
	if (typeof(scormFrame) != 'undefined') {
		isStaticLMS = true;
	}
	else {
		isStaticLMS = false ;
	}
	return isStaticLMS ;
}

/*function that checks if delivered in a Standalone mode*/
function deliveryIsStandalone() {
	var isStandalone = false;
	if ( (deliveryIsStaticLMS() != true) && (deliveryIsDynamic() != true) ) {
		isStandalone = true;
	}
	else {
		isStandalone = false;
	}
	return isStandalone ;
}

/*Function that detect within an LMS delivery if the package has been open in a new window or if the current window has been reused. This information is necessary to close windows on some occasions and not on others*/
function contentInNewWindow() {
	var scormAPIFrame = getSCORMAPIFrame();
	var isInNewWindow;
	if (scormAPIFrame && scormAPIFrame.opener) {
		var openingWindow = scormAPIFrame.opener ;
		if (scormAPIFrame.opener && scormAPIFrame.opener.WindowOpen) {
			isInNewWindow = true;
		} else {
			isInNewWindow = false;
		}
	}
	return isInNewWindow;
}


/*This function allows to retrieve the cluster ID of the currently displayed cluster based on a series of variables available at runtime in Offline mode.
(in Dynamic mode the access to DOM variable Frames should be privileged)
An alternative method could be to parse g_anClusterPages and find in which cluster interval the current page reference is fitting. */

function getClusterID() {
	var myClusterID = null;
	var mainFrameset = getMainFrameset();
	if (deliveryIsDynamic()) {
		if (mainFrameset && mainFrameset.g_sSCO_ID) {
			myClusterID = mainFrameset.g_sSCO_ID;
		}
	} else {
		var pageNum = mainFrameset.PageNum;
		for (i in mainFrameset.g_anClusterPageIndices) {
			for (j in mainFrameset.g_anClusterPageIndices[i]) {
				if (pageNum == mainFrameset.g_anClusterPageIndices[i][j]) {
					myClusterID = i;
				}
			}
		}
	}
	return myClusterID;
}


/*THis function retrieve the value of the Page index as available in PageVisited array*/
function getPageIndex(pageNumber) {
	var mainFrameset = getMainFrameset();
	var myClusterID = getClusterID();
	var myPageIndex ;
	if (mainFrameset && mainFrameset.g_anClusterPageIndices && mainFrameset.g_anClusterPageIndices[myClusterID]) {
		for (i in mainFrameset.g_anClusterPageIndices[myClusterID]) {
			if (mainFrameset.g_anClusterPageIndices[myClusterID][i] == (pageNumber-1)) {
				var pageIndexAndNum = i;		
			}
		}
	}
	
	if (pageIndexAndNum != null) {
		var lastIndex = pageIndexAndNum.indexOf("-");
		myPageIndex = pageIndexAndNum.substring(0,lastIndex);
	}
	/*Code for if the F10 bug is resolved
	
	if (mainFrameset && mainFrameset.g_aPages && mainFrameset.g_aPages[pageNumber - 1]) {
		var myPageIndex = mainFrameset.g_aPages[pageNumber - 1][0];
	}
	*/
	return myPageIndex;
}

/*Solution to get Current PageID which should be faster*/
function getCurrentPageID() {
	var domVariablesFrame = getDOMVariablesFrame() ;
	var myPageID = null ;
	if (domVariablesFrame && domVariablesFrame.document.forms && domVariablesFrame.document.forms.Main && domVariablesFrame.document.forms.Main.DocID && domVariablesFrame.document.forms.Main.DocID.value) {
		domVariablesFrame.document.forms.Main.DocID.value;
	}
	return myPageID;
}


/*//////////////////////////////////////////////////////////////////
///////////Functions to identify the path to the frames ////////////
/////////////////////////////////////////////////////////////////////
The frameset is different depending on the delivery mode and if we have to do with HTML imported content or not.
Please Refer to 

The frameset structure is detailed in a seperate document, the following information is given here as a reminder:
The name of the navigation frames created by F10 are the following: 'TBorder' (Top bar), 'RBorder' (Right Bar), 'LBorder' (Left Bar), 'BBorder' (Bottom Bar). These bars should be defined in Course properties. They are associated with F10 elements (HTML import, Hotspot...) and their size is defined.
The name of the frame displaying F10 Pages is 'Content'.
Content Variables used for delivery are associated with the Content frame except in dynamic delivery with an HTML import. In this case the content frame is divided in 2 frames: 'Imported' where HTML import content is displayed and 'Variables' where associated variables for deliveries are accessible.
ForceTen Functions associated that can be used in a Navigation bar (Index, next, Glossary...) are located in a frame named 'Functions'.
*/


/* This function extract Nodes (Elements) of type "Frame" from a Node (Element) list and returns a Node list with only Frame Nodes inside*/
function returnFrames(elementsList) {
	
	var frameList = new Array();
	
	for (var i=0; i < elementsList.length; i++) {
		if (elementsList[i].nodeName == "FRAME") {
			frameList[frameList.length] = elementsList[i] ;
		} /*else do not copy the element*/
	}
	return frameList ;
}

/*Function to define where is the Content Frame.
This frame is a central frame to access DOM variables or Runtime Metadata*/
function getContentFrame() {
	
	var contentFrame ;
	/*Two choices:
	a) the function is called from a navigation bar (their should not be any nested frameset in the navigation bar)
	b) the function is called from within the content
	
	Case a) parent.Content
	Case b) self.name == content? if more deeply nested parent or parent.parent...
	*/
	var testedFrame = self;
	if (self.parent.Content) { /* case a) */
		contentFrame = parent.Content ;		
	} else {
		var frameFound = false;
		while ( (frameFound == false) && (parent.parent != parent)) {
			if ((testedFrame.name) && (testedFrame.name == "Content")) {
				contentFrame = testedFrame ; /*This method to check is not Robust in the case you have an HTML import with a frame called 'Content'.*/
				frameFound = true ;
			}
			else {
				testedFrame = testedFrame.parent;
			}
		}
	}
	
	return contentFrame;
}


/*
This frame allows to identify the path to the root of HTML imported files.
This is very useful when you are trying to access javascript variables or functions that are created within the import from the navigation bar.
In LMS Static Delivery and standalone mode, the HTML import frame is the Content Frame
In Dynamic Mode the HTML import frame is Content.Imported*/
function getHTMLImportFrame() {
	var htmlImportFrame = null;
	var contentFrame = getContentFrame();
	if (deliveryIsDynamic()) {
		if (contentFrame && contentFrame.Imported) {
			htmlImportFrame = contentFrame.Imported;
		}
	}
	else {
		htmlImportFrame = contentFrame;
	}
	return htmlImportFrame;
}

/*This function retrieves the path to the folder used for HTML import.
The path to this folder is required by some navigation function to access file directly.
Relative paths are not working when these functions are called from outside the HTML import.*/
function getPathToHTMLImportFolder(contentFrame) {
	/*Get The path of the frame. Need modification find a better solution to extract the path and get rid of the HTML file name*/
	if (contentFrame && contentFrame.location) {
		var contentFramePath = String(contentFrame.location);
		var lastSlash = contentFramePath.lastIndexOf("/");
		var htmlImportFolderPath = contentFramePath.substring(0,lastSlash+1); /*the last slash should be included*/
	}
	return htmlImportFolderPath;
}

/*Function that return the frame associated with F10 Run-time Data (Metadata, Current Page numbers...).
In order to access F10 DOM Variables, you need to get the DOM Variable frame.
See Documentation for the list of Run-Time data available*/
function getMainFrameset() {
	/*The Main Frameset is always the parent of the Content frame*/
	var contentFrame = getContentFrame();
	var mainFrame = null;
	if (contentFrame) {
		mainFrame = contentFrame.parent ;
	}
	return (mainFrame);
}

/* This function allows to access DOM variables. These variables are only available in dynamic mode.
These variables are documented within "F10 Scripting, Variables and Runtime Data" Advanced developer guide provided during the training*/
function getDOMVariablesFrame() {
	/*The DOM Variables frame is the Content frame except when accessing HTML imported content in an online mode*/
	var contentFrame = getContentFrame();
	var domVariablesFrame ;
	if (contentFrame && contentFrame.Variables) {
		domVariablesFrame = contentFrame.Variables ;
	} else {
		domVariablesFrame = contentFrame ;		
	}
	return (domVariablesFrame);
}


/*Function that return the frame associated with F10 functions for navigation (index, glossary, next...)*/
function getFunctionsFrame() { 
	var mainFrameset = getMainFrameset();
	var functionFrame = null;
	if (mainFrameset && mainFrameset.Functions) {
		functionFrame = mainFrameset.Functions;
	}
	return (functionFrame);
}


/*function that return the frame where the functions and variables defined in SCORM API are available.
This function can only be called in a LMS delivery. 
These elements are associated with F10_RAL_Wrapper.htm which is including a reference to F10_RAL.js a JavaScript file containing all the eleements of SCORM API.
F10_RAL_Wrapper.htm is associated with a single frame: F10_RAL_WrapperFrame where content is launched.
The SCOs local SCORM functions (LMSInitialize, LMS Finish...) and Variables (SCO's Score and Status as stored within the SCO itself) are located in the html file associated with the frame "F10_RAL_WrapperFrame"*/
function getSCORMAPIFrame() {
	var mainFrame = getMainFrameset(); /*We do not expect more than one element with the name 'F10_RAL_WrapperFrame' in the whole page.*/
	var scormAPIFrame ;
	if (mainFrame && mainFrame.name && (mainFrame.name == "F10_RAL_WrapperFrame") ) {
		scormAPIFrame = mainFrame.parent ;
	}
	return (scormAPIFrame); /*alternative is to return self.top but it could be a problem when the content is open in the current window as self.top would refer to the top LMS window.*/
}

/*function that returns an array with the frame objects, corresponding to the navigation bar in the following positions in order: [Top, Bottom, Left, Right]. If no navigation bar is found, then the value null is set to null
Look within the code to see the style of the array returned */
function getNavigationBars() {
	var navigationBars = new Array('TBorder','BBorder','LBorder','RBorder');
	
	/*In all cases, navigation bars can be accessed from the Content frame by Content.parent.XBorder
	This method of access is preferable as other frames with similar names could exist*/
	var mainFrameset = getMainFrameset();
	if (mainFrameset) {
		var aFrame ;
		for (var i = 0; i<mainFrameset.frames.length ; i++) {
			aFrame = mainFrameset.frames[i];
				switch (aFrame.name)
				{
					case "TBorder":
						navigationBars['TBorder'] = aFrame;
						break;
					case "BBorder":
						navigationBars['BBorder'] = aFrame;
						break;
					case "LBorder":
						navigationBars['LBorder'] = aFrame;
						break;
					case "RBorder":
						navigationBars['RBorder'] = aFrame;
						break;
				}
		}
	}
	return navigationBars ;
}

/* This function return the frame corresponding to the navigation bar used. If several bars are used the default navigation bar returned are the following (in order of preference): Top, Bottom, Left, Right*/
function getNavigationBar() {
	var navigationBars = getNavigationBars();
	var defaultNavigationBar ;
	
	if ( typeof(navigationBars['TBorder']) != 'undefined' ) {
		defaultNavigationBar = navigationBars['TBorder'] ;
	} else if ( typeof(navigationBars['BBorder']) != 'undefined' ) {
		defaultNavigationBar = navigationBars['BBorder'] ;
	} else if ( typeof(navigationBars['LBorder']) != 'undefined' ) {
		defaultNavigationBar = navigationBars['LBorder'] ;
	} else if ( typeof(navigationBars['RBorder']) != 'undefined' ) {
		defaultNavigationBar = navigationBars['RBorder'] ;
	}
	return defaultNavigationBar ;
}

/*This function return the path to the HTML import of the navigation bar*/
function getPathToNavBar() {
	var myNavBar = getNavigationBar() ;
	return getPathToHTMLImportFolder(myNavBar);
}

/*/////////////////////////////////////////
////////////////Navigation Functions////////
//////////////////////////////////////////*/


/* Function that Navigate to a next page within an HTML import based on topicdefinition.js*/
function nextHTMLImportPage() {
	var contentFrame = getHTMLImportFrame() ;
	if(contentFrame.currentPageRef<contentFrame.totalPages) { /* Variables defined within topicdefinition.js*/
		contentFrame.currentPageRef ++; /*Increase of page reference by 1, this variable is used for the display of page number*/
		var pageIndex = contentFrame.currentPageRef - 1;   /* array index starts at 0 so need to substract 1 from displayed page number.	*/
		
		//NH: changed to refer to the load function inside the module, which is adapted according to each module(group) structure
		contentFrame.loadNewPage(pageIndex);
		/*var uptoIndex = getPathToHTMLImportFolder(contentFrame);		
		contentFrame.left.location= uptoIndex + "/" + "topic_" + contentFrame.currenttopic + "/" + contentFrame.pageListL[pageIndex];
		contentFrame.right.location= uptoIndex + "/" + "topic_" + contentFrame.currenttopic + "/" + contentFrame.pageListR[pageIndex];*/
		updateHTMLImportPageNumbers(contentFrame.currentPageRef, contentFrame.totalPages);
		return true;
	}
	else {
		 return false;
	}
	
}

/*Function that goes to previous page based on F10 pages. F10 version is not compatible with Firefox and is not working both in online and offline mode*/
function nextF10Page() {
	var functionFrame = getFunctionsFrame() ;
	functionFrame.RightArrow('../../../');
	updateF10PageNumbers ( getF10CurrentPageNumber() , getF10TotalPageNumber() ); /*F10 function is not compatible with firefox so Update has to be done using this custom function*/
}

/* Function that Navigate to a previous page within an HTML import based on topicdefinition.js*/
function previousHTMLImportPage() {
	var contentFrame = getHTMLImportFrame() ;
	if(contentFrame.currentPageRef>1) { /* Variables defined within topicdefinition.js*/
		contentFrame.currentPageRef --; /*Decrease of page reference by 1, this variable is used for the display of page number*/
		var pageIndex = contentFrame.currentPageRef - 1;   /* array index starts at 0 so need to substract 1 from displayed page number.	*/
		//NH: changed to refer to the load function inside the module, which is adapted according to each module(group) structure
		contentFrame.loadNewPage(pageIndex);
		/*var uptoIndex = getPathToHTMLImportFolder(contentFrame);		
		contentFrame.left.location= uptoIndex + "/" + "topic_" + contentFrame.currenttopic + "/" + contentFrame.pageListL[pageIndex];
		contentFrame.right.location= uptoIndex + "/" + "topic_" + contentFrame.currenttopic + "/" + contentFrame.pageListR[pageIndex];*/
		updateHTMLImportPageNumbers(contentFrame.currentPageRef, contentFrame.totalPages);
		return true;
	}
	else {
		 return false;
	}
	
}

/*Function that goes to previous page based on F10 pages. F10 version is not compatible with Firefox and is not working both in online and offline mode without the path parameter*/
function previousF10Page() {
	var functionFrame = getFunctionsFrame() ;
	functionFrame.LeftArrow('../../../');
	updateF10PageNumbers ( getF10CurrentPageNumber() , getF10TotalPageNumber() ); /*F10 function is not compatible with firefox so Update has to be done using this custom function*/
}

/*/////////SCO Navigation//////////////////
When imported in F10, SCos are treated very specifically.
SCO are supposed to get their own navigation system and the do not rely on F10 functionalies such as glossary, notes....

- When an imported SCO is displayed in Dynamic, F10 navigation bar is removed and the SCO is displayed using the whole window except for a small bar at the bottom.
This small bar allows to navigate to the next or previous SCO. This navigation bar can be hidden by modifying Cluster Metadata (Check the box "Custom SCO to SCO Navigation").
To replace it, the navigation code of the SCO can be modified to trigger the call to the nextSCO and previousSCO functions when the user reaches the end or the beginning of the SCO.

- When an imported SCO is displayed in Standalone mode, the default navigation bar is displayed and its allows to navigate between the SCOs using the F10 Next function.

- When an imported SCO is displayed in LMS delivery mode, there are 2 cases: SCORM 1.2 and SCORM 2004.
In 1.2, the user should use the LMS interface to navigate between the SCOs. When called in 1.2 these functions will close the content window.
In 2004, it is to modify navigation code of the SCO to trigger the call to the nextSCO and previousSCO functions when the user reaches the end or the beginning of the SCO.


*/

/*function that allows to go to the next SCO working both in dynamic, stanalone and SCORM 2004 delivery
This function should not be used within content developed in F10.
It should only be used in already developed content or integrated in a F10 navigation bar with appropriate coding to determine when to call it*/
/*Further testing is required before validation: it should be seen clearly what is the behaviour of the LMS and if completion status should be changed when using this type of navigation.
Possibily, it would require to pass on PagesVisited Array values in the suspend data String.*/

function nextSCO() {
	var result;
	if (deliveryIsDynamic()) {
		top.Navigation.NavigationBar.Next.click();
	}
	else if (deliveryIsStaticLMS()) { /*Need to be customized to check that tracking data is passed and that the window is closed */
		/*Close the current window for SCORM 1.2 LMS, Call the next SCO for SCORM 2004 LMS*/
		var scormAPIFrame = getSCORMAPIFrame();
		var MyAPI = scormAPIFrame.F10_RAL["API"];
		var functionFrame = getFunctionsFrame();
		if (scormAPIFrame.F10_RAL["API_Type"] == "SCORM 1.2") {
			/* Check if SC0 is finished or not and submit appropriate data to the suspend data string?*/
			if (contentInNewWindow()) {functionFrame.CloseWin();}
			else {functionFrame.fSCOCompleted();}
		}
		else {
			MyAPI.SetValue("adl.nav.request","continue");
			/*scoWrapperWindow = scormAPIFrame.opener.F10_RAL_WrapperWindow;*/
			var mainFrameset = getMainFrameset() ;
			mainFrameset.fCloseWindow();
/*			functionFrame.fSCOCompleted();*/
/*			if (contentInNewWindow()) {scoWrapperWindow.close();}*/
		}
	} else { /*We are in Static configuration. Next function would work except if at the end of the course set by default*/
		nextF10Page();
	}
}

/*function that allows to go to the previous SCO working both in dynamic, stanalone and SCORM 2004 delivery*/
function previousSCO() {
	
	if (deliveryIsDynamic()) {
		top.Navigation.NavigationBar.Previous.click();
		result = true ;
	}
	else if (deliveryIsStaticLMS()) { /*Need to be customized to check that tracking data is passed and that the window is closed */
		/*Close the current window for SCORM 1.2 LMS, Call the next SCO for SCORM 2004 LMS*/
		var scormAPIFrame = getSCORMAPIFrame();
		var MyAPI = scormAPIFrame.F10_RAL["API"];
		var functionFrame = getFunctionsFrame();
		if (scormAPIFrame.F10_RAL["API_Type"] == "SCORM 1.2") {
			MyAPI.F10_RAL_Commit();
			functionFrame.fSCOCompleted();
			if (contentInNewWindow()) {top.window.close();} /*We need to get the F10_RAL_SCO_Player which has open the F10_RAL_Wrapper window and has a function to close it*/
		}
		else {
			MyAPI.SetValue("adl.nav.request","previous");
			functionFrame.fSCOCompleted();
			if (contentInNewWindow()) {top.window.close();} /*We need to get the F10_RAL_SCO_Player which has open the F10_RAL_Wrapper window and has a function to close it*/
		}
	} else { /*We are in Static configuration. Previous function would work except if at the beginning of the course set by default*/
		previousF10Page();
	}
}

/*/////////////////Content Navigation/////////////////////*/

/*Function that allows to navigate between SCOs.
That function should only be called within a static SCORM 2004 LMS delivery context
The parameter of the function is the SCO item identifier that can be read in the manifest. IANS implementation of F10 is producing SCOs with the following ID:
'ItemIANS_XXX' where XXX is the ID of the Cluster, Module or Course
*/
function gotoSCO(scoItemdentifier) {
	var result;
	var scormAPIFrame = getSCORMAPIFrame();
	var MyAPI = scormAPIFrame.F10_RAL["API"];
	var functionFrame = getFunctionsFrame();
	var mySCOtarget = "{target =" + scoItemdentifier + "}choice" ;
	MyAPI.SetValue("adl.nav.request",mySCOtarget);
	functionFrame.fSCOCompleted();
	if (contentInNewWindow()) { /*We need to get the F10_RAL_SCO_Player which has open the F10_RAL_Wrapper window and has a function to close it*/
		top.window.close();
	}
}


/*Function that allows to jump to anywhere in the course in dynamic mode or standalone mode.
This function can also be used to jump from a page within a SCO in LMS static delivery mode.

The code of this function is inspired by EEDO's documentation.
When calling this function in dynamic mode, the 3 first parameters are required.
When calling this function in standalone or LMS static delivery mode, only the page number is required. This number referencial is the position of the page within the whole course. 
ClusterID is a string whereas the other parameters are numbers.
*/
function goToF10Page(clusterID, clusterNumber, docNumber, pageNumber) {
	if (deliveryIsDynamic()) {
		var domForm = (getDOMVariablesFrame()).document.forms.Main ;
		domForm.ClusterID.value = clusterID;
		domForm.ClusterNumber.value = clusterNumber;
		domForm.DocNumber.value = docNumber;
		domForm.ClusterGoing.value = '';
		domForm.DCDocIDs.value = '';
		domForm.action = 'RunThruCluster.php';
		domForm.target = 'Content';
		domForm.submit();
	} else {
		var functionFrame = getFunctionsFrame() ;	
		functionFrame.fGoToPage (pageNumber, '../../../');
	}	
}

/*This is a version of the function that should be used for navigation in a linear mode (a page can only be visited if the previous pages have been visited*/
function goToF10Page_Linear(clusterID, clusterNumber, docNumber, pageNumber) {
	if (deliveryIsDynamic()) { /*We do not check for linear navigation*/
		var domForm = (getDOMVariablesFrame()).document.forms.Main ;
		domForm.ClusterID.value = clusterID;
		domForm.ClusterNumber.value = clusterNumber;
		domForm.DocNumber.value = docNumber;
		domForm.ClusterGoing.value = '';
		domForm.DCDocIDs.value = '';
		domForm.action = 'RunThruCluster.php';
		domForm.target = 'Content';
		domForm.submit();
	} else if (deliveryIsStaticLMS()) {
		if (checkInternalSequencing(pageNumber)) {
			var functionFrame = getFunctionsFrame() ;	
			functionFrame.fGoToPage (pageNumber, '../../../');
		} else {
			alert("You need to view previous content once before accessing this section");
		}
	} else { /*In standalone mode we do not prevent navigation to other pages*/
		var functionFrame = getFunctionsFrame() ;	
		functionFrame.fGoToPage (pageNumber, '../../../');
	}
}


/*///////////////Series of Home functions///////////////////////*/
/*Function to go to a Cluster's Home
If content is packaged in SCORM 2004 format, Cluster Home is the same as Course Home*/
function goToClusterHome() {	
	if (deliveryIsDynamic()) {
		var domVariablesFrame = getDOMVariablesFrame() ;
		var domForm = domVariablesFrame.document.forms.Main ;
		domForm.DocNumber.value = 1;
		domForm.ClusterGoing.value = '';
		domForm.DCDocIDs.value = '';
		domForm.action = 'RunThruCluster.php';
		domForm.target = 'Content';
		domForm.submit();		
	} else { /*Offline delivery*/
		var functionFrame = getFunctionsFrame() ;
		var mainFrameset = getMainFrameset() ;
		var clusterID = getClusterID();
		var pageIndex = mainFrameset.g_anClusterPages[clusterID];	
		functionFrame.fGoToPage(pageIndex+1,'../../../');
	}
}

/*function that allows to go to the first page of a course.
This function should work in both dynamic and standalone mode*/
function goToCourseHome() {
	if (deliveryIsDynamic()) {
		var domVariablesFrame = getDOMVariablesFrame() ;
		var domForm = domVariablesFrame.document.forms.Main ;
		var mainFrameset = getMainFrameset() ;
		var firstClusterID ;
		for (key in mainFrameset.g_anClusterPages)  {
			firstClusterID = key;
			break;
		}
		domForm.ClusterID.value = firstClusterID; /*Check if we can put the CourseID or else try to get the first cluster ID by parsing g_anClusterPages*/
		domForm.ClusterNumber.value = 1; /*Check if it is the correct number*/
		domForm.DocNumber.value = 1;
		domForm.ClusterGoing.value = '';
		domForm.DCDocIDs.value = '';
		domForm.action = 'RunThruCluster.php';
		domForm.target = 'Content';
		domForm.submit();		
	} else {
		var functionFrame = getFunctionsFrame();
		functionFrame.CourseHome('../../../');
	}
}

/*//////////////////////////////////////////////
////////////////Page Numbering Functions////////
//////////////////////////////////////////////*/

/*
There are 2 types of page numbering. The first is based on HTML Import internal Page numbering.
The second is based on F10 Page numbering.

In order to have page numbering appears in Navigation bars or in Page content, it is necessary to put the following code:
For HTML Import Pages:
Page <span id="htmlImportPageRef"> 0</span> of <span id="htmlImportPagesTotal"> 0</span>
HTML import page numbers are updated automatically with next and previous actions.

For F10 pages:
<b><SPAN ID="PageN"></SPAN>&nbsp;&nbsp;<SPAN ID="Slash"></SPAN>&nbsp;<SPAN ID="OfN"></SPAN></b>
In addition it is necessary to place the following script in the navigation bar:
<SCRIPT type="text/javascript">
var mainFrameset = getMainFrameset() ;
mainFrameset.PageNumbering = true;
var defaultNavBar = getNavigationBar() ;
mainFrameset.PageFrame = defaultNavBar.Name ;
</SCRIPT>

F10 page numbers are updated automatically with F10 Next and Previous actions.
When working with a more complex set of navigation bars, you can manage to find the navigation bar or to find the value of the page numbers directly by looking more closely at the code.
*/

/*That function search for the page numbers in the navigation bars and update the page references.
If page numbers are put elswhere, it is necessary to update them somewhere else*/
function updateHTMLImportPageNumbers(currentPage, totalPages) {
	/* This function finds the frame where the pages numbers are passed and update the values*/
	var navigationBars = getNavigationBars();
	var thisBar ;
	var pageRefObject ;
	
	if ( typeof(navigationBars['TBorder']) != 'undefined' ) {
		thisBar = navigationBars['TBorder'] ;
		pageRefObject = thisBar.document.getElementById("htmlImportPageRef");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("htmlImportPagesTotal").innerHTML = totalPages;
		}
	}
	
	if ( typeof(navigationBars['BBorder']) != 'undefined' ) {
		thisBar = navigationBars['BBorder'] ;
		pageRefObject = thisBar.document.getElementById("htmlImportPageRef");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("htmlImportPagesTotal").innerHTML = totalPages;
		}
	}
	
	if ( typeof(navigationBars['LBorder']) != 'undefined' ) {
		thisBar = navigationBars['LBorder'] ;
		pageRefObject = thisBar.document.getElementById("htmlImportPageRef");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("htmlImportPagesTotal").innerHTML = totalPages;
		}
	}
	
	if ( typeof(navigationBars['RBorder']) != 'undefined' ) {
		thisBar = navigationBars['RBorder'] ;
		pageRefObject = thisBar.document.getElementById("htmlImportPageRef");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("htmlImportPagesTotal").innerHTML = totalPages;
		}
	}
}

function updateF10PageNumbers (currentPage, totalPages) {
	
	var navigationBars = getNavigationBars();
	var thisBar ;
	var pageRefObject ;
	
	if ( typeof(navigationBars['TBorder']) != 'undefined' ) {
		thisBar = navigationBars['TBorder'] ;
		pageRefObject = thisBar.document.getElementById("PageN");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("OfN").innerHTML = totalPages;
			thisBar.document.getElementById("Slash").innerHTML = "/"; 
		}
	}
	
	if ( typeof(navigationBars['BBorder']) != 'undefined' ) {
		thisBar = navigationBars['BBorder'] ;
		pageRefObject = thisBar.document.getElementById("PageN");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("OfN").innerHTML = totalPages;
			thisBar.document.getElementById("Slash").innerHTML = "/"; 
		}
	}
	
	if ( typeof(navigationBars['LBorder']) != 'undefined' ) {
		thisBar = navigationBars['LBorder'] ;
		pageRefObject = thisBar.document.getElementById("PageN");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("OfN").innerHTML = totalPages;
			thisBar.document.getElementById("Slash").innerHTML = "/"; 
		}
	}
	
	if ( typeof(navigationBars['RBorder']) != 'undefined' ) {
		thisBar = navigationBars['RBorder'] ;
		pageRefObject = thisBar.document.getElementById("PageN");
		if (pageRefObject != null ) {
			pageRefObject.innerHTML = currentPage;
			thisBar.document.getElementById("OfN").innerHTML = totalPages;
			thisBar.document.getElementById("Slash").innerHTML = "/"; 
		}
	}
}

/*
F10 page numbering is based on a dual system:
- Page numbers corresponding to the sequence of pages in a document
- page numbers as they are displayed to the users.
The choice to continute page numbering from one cluster to another can be defined within the Cluster Metadata.

The variable "PageNum" defined in the mainframeset seems to be refering to the page number in the sequence of the course.
In Offline mode the display page number is found in the array g_aPages. See documentation on the information provided within that array.
*/
function getF10CurrentPageNumber() {
	var mainFrameset = getMainFrameset() ;
	if (mainFrameset) {
		var	currentPage = mainFrameset.PageNum ;
	}
	if(deliveryIsDynamic())  {
		/*We have the right value*/
	} else {
		if (mainFrameset && (mainFrameset.g_aPages) && (mainFrameset.g_aPages[currentPage-1]) && (mainFrameset.g_aPages[currentPage-1][3])) {
			currentPage = mainFrameset.g_aPages[currentPage-1][3];  /*Arrays are starting at 0 so we have to withdraw 1 to get the index in the array*/
		}
	}
	return currentPage;
}

function getF10TotalPageNumber() {
	var mainFrameset = getMainFrameset() ;
	var	CurrPageIndx = mainFrameset.PageNum - 1 ; /*Arrays are starting at 0 so we have to withdraw 1 to get the index in the array*/
	var totalPages ;
	
	if(deliveryIsDynamic())  {
    	totalPages = mainFrameset.PageCount;
  	}
  	else
  	{
		if (mainFrameset && (mainFrameset.g_aPages) && (mainFrameset.g_aPages[CurrPageIndx]) && (mainFrameset.g_aPages[CurrPageIndx][4])) {
	    	totalPages = mainFrameset.g_aPages[CurrPageIndx][4];
		}
  	}
  	return totalPages;
}
	
/*//////////////////////////////////////////////
////////////////Access to Metadata/////////////
//////////////////////////////////////////////*/
/*Two simple functions are presented to access User Metadata. To access other kind of Metadata, build your own function in the same way.
Interesting Metadata roots are the following, refer to F10 configuration to see which sets of Metadata are associated with Profiles, Courses, Pages...:
Metadata['Course']
Metadata['Cluster']
Metadata['Page']
*/

function getStudentName() {
	var myName ;
	if (deliveryIsDynamic()) { /*The function needs to be checked to see if dynamic delivery would work appropriately*/
		var mainFrameset = getMainFrameset() ;
		if (mainFrameset.Metadata['Profile']) {
			myName = mainFrameset.Metadata['Profile']['FIRST_NAME'] + " " + mainFrameset.Metadata['Profile']['LAST_NAME'] ;
		}
	} else if (deliveryIsStaticLMS()) {
		var scormAPIFrame = getSCORMAPIFrame();
		myName = scormAPIFrame.F10_RAL_Intercept_API.LMSGetValue("cmi.core.student_name");
	} else {/*standalone delivery*/
		myName = "Guest User";
	}
	return (myName) ;	
}

function getStudentEmail() {
	var mainFrameset = getMainFrameset() ;
	return (mainFrameset.Metadata['Profile']['EMAIL_ADDRESS']) ;		
}

/*//////////////////////////////////////////////
////////////Sequencing and Navigation //////////
//////////////////////////////////////////////*/
/* This section introduces functinoalities that are used to control navigation based on content which is presented.
*/

/*This function sets a page as Uncompleted if it has not been completed on previous attempts. This function only works in Offline static mode.
Typically, this function would be used when there is an activity on a page and that the user would have to complete this activity to get the progress as completed.
This function would be used in coordination with the setPageComplete() function (to be called when the activity is successful)
Parameter: PageNumber (integer). This number is the page number as counted by F10 in its list of page number.
To set the current page as uncomplete, write the following code:
	var mainFrameset = getMainFrameset() ;
	setPageUncomplete(mainFrameset.PageNum);
*/

function setPageUncomplete(PageNumber) {
	var mainFrameset = getMainFrameset() ;
	var sCompletionString ;
	var myPageIndex = getPageIndex(PageNumber) ;
	var pageAlreadyVisited = 0; /*by default we consider the page has not been visited before*/

	/* retrieving PagesVisited data if it exists. We expect that suspend_data is not updated everytime a page is accessed. Else, we would not be able to access original completion data.*/
	var scormAPIFrame = getSCORMAPIFrame();
	if (scormAPIFrame && scormAPIFrame.F10_RAL && scormAPIFrame.F10_RAL["API_Type"]) {
		var myAPI = scormAPIFrame.F10_RAL["API"];
		switch ( scormAPIFrame.F10_RAL["API_Type"] )
		{
			case "SCORM 1.2":
				sCompletionString = myAPI.LMSGetValue("cmi.suspend_data");
				break;
			case "SCORM 2004":
				sCompletionString = myAPI.GetValue("cmi.suspend_data");
				break;
		}
		/*Evaluating original completion status of a page.*/
		if ( sCompletionString != "" && (PageNumber > 0) ) {
			pageAlreadyVisited = sCompletionString.charAt(PageNumber-1); /*first character of a string should be char (0) need to withdraw 1 (to be confirmed)*/
		} else { /*There is no suspend data which means it is the first access*/
			pageAlreadyVisited = "0";
		}
		
		if (pageAlreadyVisited == "0") { /*if page has already been visited, we should not not modify the reset the completion status.*/
			mainFrameset.PagesVisited[myPageIndex] = false;
		}
	}

}

function setThisPageUncomplete(){
	var mainFrameset = getMainFrameset() ;
	setPageUncomplete(mainFrameset.PageNum);
}

function getSuspendData() {
	var mainFrameset = getMainFrameset() ;
	var sCompletionString ;
	/* retrieving PagesVisited data if it exists. We expect that suspend_data is not updated everytime a page is accessed. Else, we would not be able to access original completion data.*/
	var scormAPIFrame = getSCORMAPIFrame();
	if (scormAPIFrame && scormAPIFrame.F10_RAL && scormAPIFrame.F10_RAL["API_Type"]) {
		var myAPI = scormAPIFrame.F10_RAL["API"];
		switch ( scormAPIFrame.F10_RAL["API_Type"] )
		{
			case "SCORM 1.2":
				sCompletionString = myAPI.LMSGetValue("cmi.suspend_data");
				break;
			case "SCORM 2004":
				sCompletionString = myAPI.GetValue("cmi.suspend_data");
				break;
		}
	}
	return sCompletionString;
}

function showSuspendData() {
	alert ("Suspend Data value: " + getSuspendData());
}

function showPagesVisited() {
	var mainFrameset = getMainFrameset() ;
	var sCompletionString = "" ;
	if (mainFrameset && mainFrameset.PagesVisited) {
		for (key in mainFrameset.PagesVisited) {
			sCompletionString = sCompletionString + mainFrameset.PagesVisited[key];
		}
	}	
	alert("PagesVisited values: " + sCompletionString);
}



/*This function work in pair with the previous one and set the page as completed This function only works in Offline static mode.
Typically, this function would be used when there is an activity on a page and that the user would have to complete this activity to get the progress as completed.
This function would be used in coordination with the setPageUncomplete() function (to be called at the beginning of the activity)
Parameter: PageNumber (integer). This number is the page number as counted by F10 in its list of page number.
To set the current page as Complete, write the following code:
	var mainFrameset = getMainFrameset() ;
	setPageComplete(mainFrameset.PageNum);
*/

function setPageComplete(PageNumber) {
	var mainFrameset = getMainFrameset() ;
	var myPageIndex = getPageIndex(PageNumber) ;
	var sCompletionString = "";
	if ( myPageIndex && mainFrameset.PagesVisited) {
		mainFrameset.PagesVisited[myPageIndex] = true;
	}
	
	/*create completion string*/
	for ( key in mainFrameset.PagesVisited ) {
		if (!(mainFrameset.PagesVisited[ key ])) {
			sCompletionString = sCompletionString + "0";
		} else {
			sCompletionString = sCompletionString + "1";
		}
	}
	
	var scormAPIFrame = getSCORMAPIFrame();
	if (scormAPIFrame && scormAPIFrame.F10_RAL && scormAPIFrame.F10_RAL["API_Type"]) {
		var myAPI = scormAPIFrame.F10_RAL["API"];
		switch ( scormAPIFrame.F10_RAL["API_Type"] )
		{
			case "SCORM 1.2":
				myAPI.LMSSetValue("cmi.suspend_data",sCompletionString);
				myAPI.LMSCommit("");
				break;
			case "SCORM 2004":
				myAPI.SetValue("cmi.suspend_data",sCompletionString);
				myAPI.Commit("");
				break;
		}
	}
}

function setThisPageComplete() {
	var mainFrameset = getMainFrameset() ;
	setPageComplete(mainFrameset.PageNum);
}

/*This function works only for offline delivery through the LMS when using the standalone mode, the function will always return true*/
function checkInternalSequencing(pageNumber) {
	var mainFrameset = getMainFrameset() ;
	var myPageIndex = getPageIndex(pageNumber) ;
	var pageCanBeVisited = false; /*by default we consider the page cannot be visited*/
	var pageAlreadyVisited = 0 ; /*We consider pages have not been visited before by default*/

	if ( myPageIndex && mainFrameset.PagesVisited) {
		if (mainFrameset.PagesVisited[myPageIndex] || (pageNumber == 1)) {
			pageCanBeVisited = true;
		} else {
			var previousPageIndex = getPageIndex(pageNumber - 1);
			if (mainFrameset.PagesVisited[previousPageIndex]) {
				pageCanBeVisited = true;
			}
		}
	}
	return pageCanBeVisited ;
}

/*These function set the value of a variable used to determine navigation to the next page. ForceTen default navigation is checking for the current value of the input field before allowing navigation.
This function should be used in combination with setPageUncomplete to force the user to perform an activity on a page before going on*/
function setProceedToFalse() {
	var domVariablesFrame = getDOMVariablesFrame() ;
	domVariablesFrame.document.forms.Main.Proceed.value = "N";
}

function setProceedToTrue() {
	var domVariablesFrame = getDOMVariablesFrame() ;
	domVariablesFrame.document.forms.Main.Proceed.value = "Y";
}