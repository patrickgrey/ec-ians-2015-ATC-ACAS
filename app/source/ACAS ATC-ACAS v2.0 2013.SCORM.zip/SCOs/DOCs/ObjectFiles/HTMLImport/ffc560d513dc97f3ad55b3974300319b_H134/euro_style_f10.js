function attachCSStoPage (stylesheetName) {
	var h = window.document.getElementsByTagName("head")[0];
   	var s = document.createElement("link");
	var topNavBar = self.parent.TBorder ;
	var contentFramePath = String(topNavBar.location);
	var lastSlash = contentFramePath.lastIndexOf("/");
	var folderPath = contentFramePath.substring(0,lastSlash+1); //the last slash should be included

	s.rel = "stylesheet";
   	s.type = "text/css";
   	s.href = folderPath + stylesheetName; /*This assumes the name of the stylesheet is passed with the extension style.css and that it is in the root of the HTML import of the navigation bar*/

   if (h.hasChildNodes())
   {
       h.insertBefore(s,h.firstChild);
   }
   else
   {
       h.AppendChild(s);
   }

}

function setStyle (ObjectID,StyleID) {
	var isIE = (window.ActiveXObject)?true:false;
	var originalStyle;
	var backgroundIndexStart;
	var backgroundIndexStop;
	var styleElementToKeep;
	
	var mydiv = document.getElementById(ObjectID);
	if (isIE) {
		originalStyle = mydiv.style.cssText;
		if (originalStyle) {
			backgroundIndexStart = originalStyle.indexOf("BACKGROUND");
			backgroundIndexStop = originalStyle.indexOf(";",backgroundIndexStart);
			styleElementToKeep = originalStyle.substring(0,backgroundIndexStart);
			mydiv.style.cssText = styleElementToKeep;
		}
		mydiv.setAttribute("className",StyleID);
	} else {
		originalStyle = mydiv.getAttribute("style");
		if (originalStyle) {
			backgroundIndexStart = originalStyle.indexOf("BACKGROUND");
			backgroundIndexStop = originalStyle.indexOf(";",backgroundIndexStart);
			styleElementToKeep = originalStyle.substring(0,backgroundIndexStart);
			mydiv.setAttribute("style",styleElementToKeep);
		}
		mydiv.setAttribute("class",StyleID);
	}
}