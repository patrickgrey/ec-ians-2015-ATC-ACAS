var DaysInMonthArray = new Array(31,28,31,30,31,30,31,31,30,31,30,31);

function Trim ( source )
{
  source = LTrim ( source );
  source = RTrim ( source );
  return source;
}

function LTrim ( source )
{
  var re = /^\s+/g;
  return source.replace ( re, "" );
}

function RTrim ( source )
{
  var re = /\s+$/g;
  return source.replace ( re, "" );
}

function ValidateDate(Field)
{
  if(!Field.value.length)
    return true;
   
  Parts = Field.value.split("-");

  if(Field.value.substr(4,1) != '-' || Field.value.substr(7,1) != '-' || Parts.length != 3)
  {
    alert("Invalid Date Format.\nFormat is: YYYY-MM-DD");
    Field.focus();
    return false;
  }

  yyyy = Parts[0];
  mm   = Parts[1];
  dd   = Parts[2];

  if(yyyy != parseInt(yyyy,10) || yyyy.length != 4)
  {
    alert("Invalid Year");
    Field.focus();
    return false;
  }
  
  if(mm.length != 2 || mm != parseInt(mm,10) || mm < 1 || mm > 12)
  {
    alert("Invalid Month");
    Field.focus();
    return false;
  }
 
  DaysInMonth = DaysInMonthArray[mm-1];
  if(mm == 2)
    if(!(yyyy % 4) && (yyyy % 100) || !(yyyy % 400))
      DaysInMonth++;

  if(dd.length != 2 || dd != parseInt(dd,10) || dd < 1 || dd > DaysInMonth)
  {
    alert("Invalid Day");
    Field.focus();
    return false;
  }

  return true;

}
var lastMouseOverObj = null;
function TouchOutHTML()
{
  if(lastMouseOverObj)
  {
    lastMouseOverObj.hoverSpan.parentNode.removeChild(lastMouseOverObj.hoverSpan);
    lastMouseOverObj = null;
  }
}
function MouseOverHTML(event,HTML,which)
{
  lastMouseOverObj = which;
  SaveX = event.clientX;
  SaveY = event.clientY;
  var hover = document.createElement('SPAN');
  hover.style.position = 'absolute';
  hover.style.left = hover.style.top = 0;
  hover.style.backgroundColor = '#FFFFE1';
  hover.style.border = '1px solid black';
  hover.style.zIndex = 100000;
  hover.style.padding = '3px';
  hover.style.fontFamily = 'arial';
  hover.style.fontSize = '8pt';
  hover.innerHTML = HTML;
  hover.style.visibility = 'hidden';
  document.body.appendChild(hover);
  //Left to Right
  DistanceRight = document.body.clientWidth - SaveX;
  DistanceLeft  = SaveX;
  if(hover.clientWidth < DistanceRight)
    hover.style.left = SaveX + 10;
  else if(hover.clientWidth < DistanceLeft)
    hover.style.left = SaveX - hover.clientWidth - 10;
  else
  {
    if(DistanceRight > DistanceLeft)
    {
      hover.style.width = DistanceRight - 20;
      hover.style.left  = SaveX + 10;
    }
    else
    {
      hover.style.width = DistanceLeft - 20;
      hover.style.left  = SaveX - hover.clientWidth - 10;
    }
  }
  //Top to Bottom
  DistanceBottom = document.body.clientHeight - SaveY;
  DistanceTop  = SaveY;
  if(hover.clientHeight < DistanceBottom)
    hover.style.top = SaveY + 10;
  else if(hover.clientHeight < DistanceTop)
    hover.style.top = SaveY - hover.clientHeight - 10;
  else
  {
    if(DistanceBottom > DistanceTop)
    {
      hover.style.height = DistanceBottom - 10;
      hover.style.top   = SaveY + 10;
    }
    else
    {
      hover.style.height = DistanceTop - 10;
      hover.style.top  = SaveY - hover.clientHeight - 10;
    }
  }
  hover.style.visibility = 'visible';
  which.hoverSpan = hover;
}

function MouseOutHTML(which)
{
  which.hoverSpan.parentNode.removeChild(which.hoverSpan);
}

function ViewPage(DocID,x,y,w,h,title)
{
  var windowURL = 'PreviewDocFrame.php?DocVersion=1&DocID='+DocID+
              '&UserID='+document.forms.Main.UserID.value+
              '&SessionKey='+document.forms.Main.SessionKey.value+'&VPTitle='+title;
  var windowName = new Date().getTime();
  var windowParms = 'left='+x+',top='+y+',width='+w+',height='+h+',scrollbars=yes';
  var urlParts = windowURL.split('?');
  formElements = urlParts[1].split('&');
  var winHandle = window.open('about:blank',windowName,windowParms); 
  if (!winHandle) return false;
  var html = '<HTML><BODY><FORM METHOD="POST" ACTION="' + urlParts[0] + '">';
  for(var i=0;i<formElements.length;i++)
  {
    NVPair = formElements[i].split('=');
    html += '<INPUT TYPE="HIDDEN" NAME="' + NVPair[0] + '" VALUE="' + NVPair[1] + '"/>';
  }
  html += "</FORM><"+"SCRIPT>" + 'var url_prefix = ""; var loc_href = document.location.href; if ( loc_href.indexOf("ObjectFiles") !== -1 ) { var sub_url = loc_href.substr(loc_href.indexOf("ObjectFiles")); var sua = sub_url.split("/"); for ( var i = 0; i < sua.length - 1; i++ ) url_prefix += "../"; if ( url_prefix ) url_prefix += "NewLinx/"; document.forms[0].action = url_prefix + "' + urlParts[0] + '"; } ' + "document.forms[0].submit();<"+"/SCRIPT>";
  winHandle.document.write(html);
}

function getProperty ( /* PropertyName [, DefaultValue] */ )
{
  var PropertyName = getProperty.arguments[0];
  if (parent.PropertyBag)
    if (typeof(parent.PropertyBag[PropertyName]) != 'undefined')
      return parent.PropertyBag[PropertyName];
  if(getProperty.arguments.length > 1)
    return getProperty.arguments[1];
  return 'undefined';
}

function HideFeedbackArea(ID)
{
  if(document.layers)
    document.layers[ID].visibility = "hide";
  else
  {
    document.getElementById(ID).style.visibility = "hidden";
    document.getElementById(ID).innerHTML = '';
  }
  return;
}

function SetFeedbackAreaHTML ( ID, HTML )
{

  if(!document.getElementById(ID)) return;
  if(ID == 'Feedback') ID = 'CFeedback'; //fix for legacy....

    // If the user is visually impaired, we also throw an alert on the screen
    // for two reasons:

    // 1 - JAWS does not read out DHTML changes in real-time.  Changes will be
    // picked up if a frame changes location, an HREF is followed or if the user
    // manually invokes INSERT+ESCAPE.  At least, these are the conditions I was
    // able to determine

    // 2 - The Feedback and Instruction areas are usually at the end of the
    // form.  That means they'd have to navigate through all the widgets to get
    // their next instruction and feedback.
      // strip html and spaces on left and right side
    if(parent.UserVisionImpaired)
    {
      var SimpleText = Trim ( HTML.replace (  /<[^>]*>/g, "" ) );
      // Don't invoke a message box if we have nothing to say
      // (happens when buttons change, for example)
      if ( SimpleText.length > 0 && ( ID == 'CFeedback' || ID == 'Instructions' ) )
      {
        // ID is either "Feedback" or "Instructions"
        alert ( ID + ': ' + SimpleText );
      }
    }
    document.getElementById(ID).innerHTML =  HTML;
    document.getElementById(ID).style.visibility = 'visible';
    setTimeout( "document.getElementById(\'"+ID+"\').innerHTML += '';", 1);// IE6 will not render images without this line
}

function fResizeGRForPDA( p_oImage )
{
	var nScreenWidth = document.body.clientWidth - 20;
	var nObjWidth = p_oImage.width;
	if ( nScreenWidth > nObjWidth || nObjWidth < 1 )
		return;
	
	var nScale = nScreenWidth / nObjWidth;
	p_oImage.height = Math.floor(p_oImage.height * nScale);
	p_oImage.width = Math.floor(p_oImage.width * nScale);
}

function fResizeAllGRsForPDA()
{
	var aoImages = document.images;
	for ( var i = 0; i < aoImages.length; i++ )
		fResizeGRForPDA( aoImages[i] );
}

function toggle(Obj,Path)
{
  var ObjPtr = Obj.parentNode.nextSibling;
  if(ObjPtr.style.display == 'none')
  {
    ObjPtr.style.display = 'block';
    Obj.src = Obj.src.substr(0,Obj.src.lastIndexOf("plus")) + 'minus.png';
    Obj.nextSibling.src = Path + 'openfoldericon.png';
  }
  else
  {
    ObjPtr.style.display = 'none';    
    Obj.src = Obj.src.substr(0,Obj.src.lastIndexOf("minus")) + 'plus.png';
    Obj.nextSibling.src = Path + 'foldericon.png';
  }
}
function setSelRange(inputEl, selStart, selEnd) { 
 if (inputEl.setSelectionRange) { 
  inputEl.focus(); 
  inputEl.setSelectionRange(selStart, selEnd); 
 } else if (inputEl.createTextRange) { 
  var range = inputEl.createTextRange(); 
  range.collapse(true); 
  range.moveEnd('character', selEnd); 
  range.moveStart('character', selStart); 
  range.select(); 
 } 
}        

function ctrlTextAreaLength(obj, maxlength){
  if(window.TA_onpropertychange_block)
    return;
 
  window.TA_onpropertychange_block=true;
  var s = obj.value;
  var p = s.indexOf('\n');
  /*
  re=/(\n\r|\n|\r)/gm;
  s = s.replace(re, " ");
  */
  s= s.split('\n').join(' ').split('\r').join('');
  if(s.length> maxlength){
    s = s.slice(0,maxlength);
  }
  if(obj.value != s){
    obj.value = s;
    if(p >= 0)
      setSelRange(obj, p, p);
  }
  window.TA_onpropertychange_block=false;
}

function ValidateTextArea(which)
{
  which.value = which.value.replace(/\n/g," ");
}

function ValidateTextAreaRealTime(e,which)
{
  var event = e ? e : window.event;
  if(event.keyCode == 13)
  {
    which.value += ' ';
    if(event.preventDefault)
      event.preventDefault();
    return false;
  }
}

function playObjAttributeSound(obj)
{
  if(!(obj && obj.getAttribute('SOUND') && obj.getAttribute('SOUND') != ''))
    return;

  parent.Media_Player.play( obj.getAttribute('SOUND'), parent.document.getElementById("smilAudio"), true, null, null, true );
}
function getNextSibling(node)
{
  do{node = node.nextSibling;} while(!node.tagName) return node;
}
    function ViewPage(DocID,x,y,w,h,title,p_sPath)
    {
      var ViewWin = window.open('', '', 'width='+w+',height='+h+',left='+x+',top='+y+',scrollbars=yes,toolbar=no,menubar=no,statusbar=no');
                  DocID = DocID.split('^').join('') + '.htm';
                  var desiredFile =( p_sPath ? p_sPath : '' ) + '../DOCs/'+DocID;
                  ViewWin.document.write('<script>');
                  ViewWin.document.write('windowOpenPOST = opener.parent.windowOpenPOST;');
                  ViewWin.document.write('var MainLoaded = false;');
                  ViewWin.document.write('var Widgets = new Array ( );');
                  ViewWin.document.write('var HookableEvents = new Array();');
                  ViewWin.document.write('var MouseDownHandled = false;');
                  ViewWin.document.write('var g_QuestionTracking = new Array();');
                  ViewWin.document.write('</script>');
                  ViewWin.document.write('<html><head><title>' + title + '</title></head>');
                  ViewWin.document.write('<frameset  rows="*,0,0">');
                  ViewWin.document.write('<frame name="Content" src="' + desiredFile + '" marginwidth="0" marginheight="0" frameborder="0">');
                  ViewWin.document.write('<frame name="Trick" src="../Player/Blank.htm" noresize scrolling="NO" marginwidth="0" marginheight="0" frameborder="no">');
                  ViewWin.document.write('<frame name="Functions" src="../Player/CourseFunctions2.htm" noresize scrolling="NO" marginwidth="0" marginheight="0" frameborder="no">');
                  ViewWin.document.write('</frameset>');
                  ViewWin.document.write('</html>');
                }