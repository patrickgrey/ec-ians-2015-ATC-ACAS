function safariMedia()
{
  if(!(navigator.userAgent.toLowerCase().indexOf('safari') > -1 && navigator.userAgent.toLowerCase().indexOf('chrome') == -1))
    return;
  var arr = document.getElementsByTagName('OBJECT');
  for(var i = 0; i < arr.length; i++)
  {
    if(arr[i].getAttribute('classid') == "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" && navigator.userAgent.toLowerCase().indexOf('mobile') != -1) //show flash placeholder
      arr[i].previousSibling.style.display = 'block';
    //else if(arr[i].getAttribute('ObjType') == "VI")
      //convertVideoToHTML5(arr[i]);
  }
}

function convertVideoToHTML5(HTML4Video)
{
  var HTML5Video = document.createElement("video");
  HTML5Video.width = HTML4Video.width;
  HTML5Video.height = HTML4Video.height;
  HTML5Video.src = HTML4Video.firstChild.value;
  HTML5Video.controls = "controls";
  HTML4Video.parentNode.insertBefore(HTML5Video, HTML4Video);
  HTML4Video.style.display = "none";
}

function writeMediaObjects()
{
  if(document.all)
    document.body.insertAdjacentHTML('beforeEnd',MediaObjects);
  else
  {
    var r = document.body.ownerDocument.createRange();
    r.setStartBefore(document.body);
    var parsedHTML = r.createContextualFragment(MediaObjects);
    document.body.appendChild(parsedHTML);
  }
  safariMedia();
}
