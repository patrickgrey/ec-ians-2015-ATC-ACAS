// Function to properly encode UTF-8 strings
// Use this instead of escape() to ensure a correctly encoded url string (RFC1738)
function urlEncode(str)
{
  len = str.length;
  res = new String();
  charOrd = new Number();

  for (i = 0; i < len; i++)
  {
    charOrd = str.charCodeAt(i);
    if ((charOrd >= 65 && charOrd <= 90) || (charOrd >= 97 && charOrd <= 122) || (charOrd >= 48 && charOrd <= 57) || (charOrd == 33) || (charOrd == 36) || (charOrd == 95))
    {
      // this is alphanumeric or $-_.+!*'(), which according to RFC1738 we don't escape
      res += str.charAt(i);
    }
    else
    {
      res += '%';
      if (charOrd > 255) res += 'u';
      hexValStr = charOrd.toString(16);
      if ((hexValStr.length) % 2 == 1) hexValStr = '0' + hexValStr;
      {
        res += hexValStr;
      }
    }
  }

  return res;
}

var hexchars = "0123456789ABCDEF";
var okURIchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
function utf8(wide) {
  var c, s;
  var enc = "";
  var i = 0;
  while(i<wide.length) {
    c= wide.charCodeAt(i++);
    // handle UTF-16 surrogates
    if (c>=0xDC00 && c<0xE000) continue;
    if (c>=0xD800 && c<0xDC00) {
      if (i>=wide.length) continue;
      s= wide.charCodeAt(i++);
      if (s<0xDC00 || c>=0xDE00) continue;
      c= ((c-0xD800)<<10)+(s-0xDC00)+0x10000;
    }
    // output value
    if (c<0x80) enc += String.fromCharCode(c);
    else if (c<0x800) enc += String.fromCharCode(0xC0+(c>>6),0x80+(c&0x3F));
    else if (c<0x10000) enc += String.fromCharCode(0xE0+(c>>12),0x80+(c>>6&0x3F),0x80+(c&0x3F));
    else enc += String.fromCharCode(0xF0+(c>>18),0x80+(c>>12&0x3F),0x80+(c>>6&0x3F),0x80+(c&0x3F));
  }
  return enc;
}
function toHex(n) {
  return hexchars.charAt(n>>4)+hexchars.charAt(n & 0xF);
}
function encodeURIComponentNew(s) {
  if(typeof encodeURIComponent == 'function'){
    return encodeURIComponent(s);
  }else{
    var s = utf8(s);
    var c;
    var enc = "";
    for (var i= 0; i<s.length; i++) {
      if (okURIchars.indexOf(s.charAt(i))==-1)
        enc += "%"+toHex(s.charCodeAt(i));
      else
        enc += s.charAt(i);
    }
    return enc;
  }
}
