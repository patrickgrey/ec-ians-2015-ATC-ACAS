function NextUnansweredQuestion( parent_path )
{
  if(parent.clusterTimedOut)
    return;
  if ( !parent_path )
    parent_path = parent;
  var sForm = parent_path.Content.document.forms.Main;
  UnansweredQuestion = false;
  for( var i=0; sForm.RunningMode.value != 'R' && i<parent_path.g_QuestionTracking.length; i++)
  {
    if(parent_path.g_QuestionTracking[i].split('^^')[2] == '')
    {
      var iframe = parent_path.Content.document.createElement('IFRAME');
      iframe.style.position = 'absolute';
      iframe.style.width  = 400;
      iframe.style.height = 300;
      iframe.scrolling = 'no';
      iframe.style.left = (parent_path.Content.document.body.clientWidth  - 400) / 2;
      iframe.style.top  = (parent_path.Content.document.body.clientHeight - 300) / 2;
      iframe.style.border = '5px solid #0055F1';
      iframe.src = 'Includes/SubmitExam.php?page_index='+i+'&CourseID='+parent_path.Content.document.forms.Main.CourseID.value;
      iframe.style.zIndex = 999999;
      parent_path.Content.document.body.appendChild(iframe);
      UnansweredQuestion = true;
      break;
    }
  }
  if(!UnansweredQuestion)
  {
    parent_path.Functions.SubmitExam(true);
  }
}
