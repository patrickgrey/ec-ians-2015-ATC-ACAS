function SetSoftSimScore(percentage)
{
  percentage = Number(percentage) / 100;
  var form = document.forms.Main;
  var possibleScore = Number(form.PossibleScore.value);
  var questionValue = Number(form.QuestionValue.value);
  form.PossibleScore.value = possibleScore + questionValue;
  form.Score.value = Number(form.Score.value) + (questionValue * percentage);
  API.score = Number(form.Score.value);
}
var API =
{
	LMSInitialize		: function() { return "true";	},
	LMSCommit		: function() { return "true"; },
	LMSFinish		: function()
	{
		if ( API.status == "completed" || API.status == "passed" )
			var status = "C";
		else
			var status = "I";
		track_si_answer( status, API.score );
		return "true";
	},
	LMSGetDiagnostic	: function() {},
	LMSGetErrorString	: function() {},
	LMSGetLastError		: function() { return "0"; },
	LMSGetValue		: function( element ) {	return ""; },
	LMSSetValue		: function( element, value )
	{
		switch ( element )
		{
			case "cmi.core.score.raw":
				SetSoftSimScore(value);
				return "true";
			case "cmi.core.lesson_status":
				API.status = value;
				return "true";
			default:
				return "true";
		}
	},
	score : 1,
	status : 'completed'
};
var API_1484_11 =
{
	Initialize	: function() { return "true";	},
	Commit		: function() { return "true"; },
	Terminate	: function() { return "true";	},
	GetDiagnostic	: function() {},
	GetErrorString	: function() {},
	GetLastError	: function() { return "0"; },
	GetValue	: function( element ) {	return ""; },
	SetValue	: function( element, value )
	{
		switch ( element )
		{
			case "cmi.score.raw":
				SetSoftSimScore(value);
				return "true";
			default:
				return "true";
		}
	}
};
