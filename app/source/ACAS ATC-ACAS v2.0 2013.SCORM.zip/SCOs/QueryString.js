function faQueryStringData()
{
    var sQS = unescape(unescape(window.location.search)).substr(1);
    var asQS = sQS.split("&");
    var asReturn = new Array();
    
    for ( var i = 0; i < asQS.length; i++ )
    {
        var asEntity = asQS[i].split("=");
        var sKey = asEntity.splice(0, 1);
        asReturn[ sKey ] = fsArrayToString( asEntity, "=" );
    }
    
    return asReturn;
}
function fsArrayToString( p_aArray, p_sDelimiter )
{
    var sReturn = "";
    
    for ( var i = 0; i < p_aArray.length; i++ )
    {
        sReturn += p_aArray[i];
        if ( i < p_aArray.length - 1 )
            sReturn += p_sDelimiter;
    }
    
    return sReturn;
}
QueryString = faQueryStringData();
