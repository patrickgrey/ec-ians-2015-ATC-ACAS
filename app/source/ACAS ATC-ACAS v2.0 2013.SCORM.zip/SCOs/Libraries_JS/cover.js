function Cover( params )
{
	params = params ? params : new Array();
	this.z = params.z ? params.z : 10000;
	this.color = params.color ? params.color : "#6699cc";
	this.transparency = params.transparency && params.transparency >= 1 && params.transparency <= 100 ? params.transparency : 70;
	this.target = params.target ? params.target : document.body;
	this.target_document = params.target_document ? params.target_document : document;
	this.cover = this.target_document.createElement("div");
	var style = this.cover.style;
	style.position = "absolute";
	style.display = "none";
	style.zIndex = this.z;
	style.top = "0px";
	style.left = "0px";
    style.height = (this.target.scrollHeight > this.target.clientHeight)? this.target.scrollHeight:this.target.clientHeight + "px";
	style.width = this.target.clientWidth + "px";
	style.backgroundColor = this.color;
	style.filter = "alpha(opacity=" + this.transparency + ")";
	style.opacity = this.transparency / 100;
	style.MozOpacity = this.transparency / 100;
	
	this.target.appendChild( this.cover );
}
Cover.prototype.show = function()
{
    this.cover.style.height = ((this.target.scrollHeight > this.target.clientHeight)? this.target.scrollHeight:this.target.clientHeight) + "px";
	this.cover.style.width = this.target.clientWidth + "px";
	this.cover.style.display = "block";
}
Cover.prototype.hide = function()
{
	try
	{
		this.cover.style.display = "none";
	}
	catch(e) {}
}
