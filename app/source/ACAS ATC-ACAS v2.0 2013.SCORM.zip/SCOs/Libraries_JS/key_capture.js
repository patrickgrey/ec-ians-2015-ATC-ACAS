/********************
DESCRIPTION
Used to disable keystrokes or apply a shortcut-key to a function.

KeyCapture takes one parameter - an object to which the
event capturing will take place.

The two public functions of KeyCapture are disable and execute.
Both functions take an associative array as parameters.

DISABLE
control		true|false
key			1 character alpha-numeric string

EXECUTE
control		true|false
key			1 character alpha-numeric string
script		a string of javascript that can be run via eval

NOTE
If calling execute and disable for the same key, you must call execute first

EXAMPLES
kc = new KeyCapture( document.getElementById("input1") );
kc.disable({ "control" : true, "key" : "v" }); // disables paste shortcut-key on an object with an id of input1
kc.execute({ "key" : 1, "script" : "callMe('bob');" }); // when 1 is pressed, the callMe function is run with a parameter of 'bob'
kc.disable({ "key" : 1 }); // disables 1 - note that functions can still be executed by pressing the number using kc.execute
********************/

function KeyCapture( obj )
{
	this.triggers = new Array();
	this.triggers["down"] = new Array();
	this.triggers["press"] = new Array();
	
	this.obj = obj;
	this.obj.onkeydown = this.downTrigger.bind(this);
	this.obj.onkeypress = this.pressTrigger.bind(this);
}
KeyCapture.prototype.enableCapture = function()
{
	this.obj.onkeydown = this.downTrigger.bind(this);
	this.obj.onkeypress = this.pressTrigger.bind(this);
}
KeyCapture.prototype.disableCapture = function()
{
	this.obj.onkeydown = null;
	this.obj.onkeypress = null;
}
KeyCapture.prototype.downTrigger = function(e)
{
	var keyCode = null;
	var ctrl = false;
	var src = null;
	
	if ( window.event ) // IE
	{
		keyCode = window.event.keyCode;
		ctrl = window.event.ctrlKey;
		src = event.srcElement;
	}
	else if (e) // Firefox
	{
		keyCode = e.which;
		ctrl = e.ctrlKey;
		src = e.target;
	}
	
	return this.executeTrigger( "down", keyCode, ctrl, src );
}
KeyCapture.prototype.pressTrigger = function(e)
{
	var keyCode = null;
	var ctrl = false;
	var src = null;
	
	if ( window.event ) // IE
	{
		keyCode = window.event.keyCode;
		ctrl = window.event.ctrlKey;
		src = event.srcElement;
	}
	else if (e) // Firefox
	{
		keyCode = e.which;
		ctrl = e.ctrlKey;
		src = e.target;
	}
	
	return this.executeTrigger( "press", keyCode, ctrl, src );
}
KeyCapture.prototype.executeTrigger = function( eventType, keyCode, ctrl, src )
{
	var triggers = this.triggers[eventType];
	
	for ( var i = 0; i < triggers.length; i++ )
	{
		if ( triggers[i]["control"] && !ctrl )
			continue;
		if ( KeyCapture.getKeyCode( triggers[i]["key"], ctrl ) == keyCode )
		{
			switch ( triggers[i]["action"] )
			{
				case "disable":
					// do not disable backspace and left arrow for input boxes and text areas
					if ( ( triggers[i]["key"] == "backspace" || triggers[i]["key"] == "left arrow" )
						&&
						( src.tagName == "TEXTAREA" || (src.tagName == "INPUT" && src.type == "text") ) )
					{
						return true;
					}
					return false;
				case "execute":
						eval( triggers[i]["script"] );
					break;
			}
		}
	}
	
	return true;
}
KeyCapture.prototype.disable = function( params )
{
	params["action"] = "disable";
	this.triggers["down"].push( params );
	this.triggers["press"].push( params );
}
KeyCapture.prototype.execute = function( params )
{
	params["action"] = "execute";
	if ( params["control"] || params["key"].substr(0,1) == 'F')
		this.triggers["down"].push( params );
	else
		this.triggers["press"].push( params );
}
KeyCapture.getKeyCode = function( key, ctrl )
{
	if(key.substr(0,1) == "F")  //function key
		return parseInt(key.substr(1),10) + 111;
		
	if ( key >= 0 && key <= 9 )
		return key + 48;
	
	var value = 0;
	
	switch ( key )
	{
		case "a":	value = 1; break;
		case "b":	value = 2; break;
		case "c":	value = 3; break;
		case "d":	value = 4; break;
		case "e":	value = 5; break;
		case "f":	value = 6; break;
		case "g":	value = 7; break;
		case "h":	value = 8; break;
		case "i":	value = 9; break;
		case "j":	value = 10; break;
		case "k":	value = 11; break;
		case "l":	value = 12; break;
		case "m":	value = 13; break;
		case "n":	value = 14; break;
		case "o":	value = 15; break;
		case "p":	value = 16; break;
		case "q":	value = 17; break;
		case "r":	value = 18; break;
		case "s":	value = 19; break;
		case "t":	value = 20; break;
		case "u":	value = 21; break;
		case "v":	value = 22; break;
		case "w":	value = 23; break;
		case "x":	value = 24; break;
		case "y":	value = 25; break;
		case "z":	value = 26; break;
		
		case "backspace":
			return 8;
		case "left arrow":
			return 37;
		case "up arrow":
			return 38;
		case "right arrow":
			return 39;
		case "down arrow":
			return 40;
	}
	
	if ( ctrl )
		return value + 64;
	else
		return value + 96;
}
