Browser =
{
	name : "unknown",
	version : 0,
	
	load_data : function()
	{
		var data = [];
		if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))
			data = ["Firefox", new Number(RegExp.$1)];
		else if (/Chrome[\/\s](\d+\.\d+)/.test(navigator.userAgent))
			data = ["Chrome", new Number(RegExp.$1)];
		else if (/Safari[\/\s](\d+\.\d+)/.test(navigator.userAgent))
			data = ["Safari", new Number(RegExp.$1)];
		else if (/MSIE[\ \s](\d+\.\d+)/.test(navigator.userAgent))
			data = ["Internet Explorer", new Number(RegExp.$1)];
		
		Browser.name = data[0] || "unknown";
		Browser.version = data[1] || 0;
	}
}
Browser.load_data();