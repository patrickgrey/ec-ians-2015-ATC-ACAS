/**********************************************************************
source					(string) the src attribute to be assigned
audio_node				(element) the media node used to run the audio
sound_locked			(bool) the sound is locked
sound_ended_callback	(function) the function to be called when
						the audio has completed playing
callback_param			(?) param to be passed to the callback function
**********************************************************************/

if ( typeof Media_Player == "undefined" ) { // only defining the object if it has not already been done

var Media_Player = {};
Media_Player.nav = navigator.userAgent.toLowerCase();
Media_Player.safari_mobile = (Media_Player.nav.indexOf('safari') != - 1 && Media_Player.nav.indexOf('mobile') != - 1);
Media_Player.absPath = '../';
Media_Player.play = function( source, audio_node, sound_locked, sound_ended_callback, callback_param, userDriven )
{
	if ( !source || source == "undefined")
	{
		if ( sound_ended_callback )
			sound_ended_callback(callback_param);
		return;
	}
	
	var file = source.replace(/..\/ObjectFiles\//gi, "").replace(/ObjectFiles\//gi, "");

	if ( file == '' )
	{
		if ( sound_ended_callback )
			sound_ended_callback(callback_param);
		return;
	}

	if(location.href.indexOf('RunCourse.htm') != -1)
	{
	  Media_Player.absPath = location.href.replace('RunCourse.htm','SCOs/');
	  file = Media_Player.absPath + 'DOCs/ObjectFiles/' + file;
	}
	else if(document.title == 'SCO Player')
	{
	  Media_Player.absPath = location.href.substr(0,location.href.lastIndexOf('/')+1);
	  file = Media_Player.absPath + 'DOCs/ObjectFiles/' + file;
	}
	else
	  file = '../ObjectFiles/' + file;  
	  
	if ( !sound_locked && sound_ended_callback )
	{
		sound_ended_callback(callback_param);
		sound_ended_callback = null;
	}

	Media_Player.sound_ended = function()
	{
		if ( sound_ended_callback )
			sound_ended_callback(callback_param);
		if(audio5 = document.getElementById("HTML5Audio"))
			audio5.parentNode.removeChild(audio5);
	}
	
	if ( !userDriven && Media_Player.safari_mobile )
	{
		Media_Player.show_audio_icon(file, audio_node);
	}
	else if ( !document.all )
	{
		Media_Player.HTML5Audio(file, audio_node);
	}
	else
	{
		if ( typeof(audio_node.resetElement) == "unknown" )
		{
			audio_node.resetElement();
			audio_node.begin = 0;
			audio_node.src = file;
			audio_node.beginElement();
			if ( audio_node.currTimeState.stateString == "cueing" )
				audio_node.onend = Media_Player.sound_ended;
			else
				Media_Player.HTML5Audio(file, audio_node);
		}
		else
			Media_Player.HTML5Audio(file, audio_node);
	}
}
Media_Player.pause = function(audio_node)
{
  if(typeof(audio_node.resetElement) == "unknown" && audio_node.hasAudio)
    audio_node.pauseElement();
  else
  {
    if(!(audio_node = document.getElementById("HTML5Audio")))
      return;
    if(audio_node.getAttribute('plugin') == '1')
    {
      try
      {
        document.getElementById('pluginSound').Pause();
      }
      catch(e) 
      {
        try
        {
          document.getElementById('pluginSound').Stop();
        }
        catch(e) 
        {
        	try
        	{
			document.getElementById('pluginSound').controls.pause();
		}
		catch(e) {}
        }
      }
    }
    else
      audio_node.pause();
  }
}
Media_Player.unpause = function(audio_node)
{
  if(typeof(audio_node.resetElement) == "unknown" && audio_node.hasAudio)
    audio_node.resumeElement();
  else
  {
    if(!(audio_node = document.getElementById("HTML5Audio")))
      return;
    if(audio_node.getAttribute('plugin') == '1')
    {
      try
      {
        document.getElementById('pluginSound').Play();
      }
      catch(e) 
      {
        try
        {
          document.getElementById('pluginSound').controls.play();
        }
        catch(e) {}
      }
    }
    else
      audio_node.play();
  }
}
Media_Player.use_background_sound = function( file, audio_node )
{
	var bgSound = null;
	if ( !(bgSound = document.getElementById("SOUNDTRICK")) )
	{
		bgSound = document.createElement("BGSOUND");
		bgSound.id = "SOUNDTRICK";
		document.body.appendChild(bgSound);
	}
	bgSound.src = file;
	Media_Player.sound_ended();
}
Media_Player.HTML5Audio = function( file, audio_node )
{
	var audio5 = null;
	if(audio5 = document.getElementById("HTML5Audio"))
		audio5.parentNode.removeChild(audio5);
	audio5 = document.createElement("audio");
	audio5.id = "HTML5Audio";
	document.body.appendChild(audio5);
	audio5.onerror = function()
	{
		audio5.setAttribute('plugin','1');
		var handle = null;
		if ( (handle = document.getElementById("pluginSound")) )
			handle.parentNode.removeChild(handle);
		if(document.all)
		{
			var plugin = document.createElement("div");
			plugin.innerHTML = '<object id=pluginSound classid="clsid:22D6F312-B0F6-11D0-94AB-0080C74C7E95">'
		        	         + '<param name="filename" value="'+file+'"/><param name="Volume" value="0"/></OBJECT>';
		}
		else
		{
			var plugin = document.createElement("embed");
			plugin.id = "pluginSound";
			plugin.src = file;
			plugin.setAttribute("autostart","true");
			if(parent.audioPlugin)
		  		plugin.type = parent.audioPlugin;
			plugin.setAttribute("postdomevents","true");
			if(document.addEventListener)
			{
				if(window.frames.Content && Content.pageTimers)
					plugin.addEventListener('qt_canplaythrough',function() { Content.pageTimers.tl5 = new Content.pausableTimeout(Media_Player.audio5ErrorFunctionEnd,plugin.GetDuration()/plugin.GetTimeScale()*1000); },false);
				else
					plugin.addEventListener('qt_canplaythrough',function() { setTimeout(Media_Player.audio5ErrorFunctionEnd,plugin.GetDuration()/plugin.GetTimeScale()*1000); },false);
			}
		}
		plugin.style.position = 'absolute';
		plugin.style.visibility = 'hidden';
		Media_Player.audio5ErrorFunctionEnd = function()
		{
		  audio5.parentNode.removeChild(audio5);
		  plugin.parentNode.removeChild(plugin);
		  Media_Player.audio5ErrorCall = false;
		  Media_Player.sound_ended();
		}
		document.body.appendChild(plugin);
		Media_Player.audio5ErrorCall = true;
	}
	if(document.addEventListener)
		audio5.addEventListener('ended',Media_Player.sound_ended,false);
	else
		audio5.attachEvent('onended',Media_Player.sound_ended);
	audio5.setAttribute('plugin','0');
	audio5.src = file;
	if(audio5.play)
		audio5.play();
	else
		audio5.onerror();
}
Media_Player.show_audio_icon = function(sound, audio_node)
{
  var audio5 = null;
  if(audio5 = document.getElementById("HTML5Audio"))
    audio5.parentNode.removeChild(audio5);
  audio5 = document.createElement("audio");
  audio5.id = "HTML5Audio";
  document.body.appendChild(audio5);
  audio5.addEventListener('ended',Media_Player.sound_ended,false);
  audio5.setAttribute('plugin','0');
  audio5.src = sound;

  if(Media_Player.cover)
    Media_Player.cover.style.display = 'block';
  else
  {
    Media_Player.cover = document.createElement('div');
    with(Media_Player.cover.style)
    {
      backgroundColor = '#e3e3e3';
      opacity = .7;
      position = 'absolute';
      left = '0px';
      top = '0px';
      width = '100%';
      height = '100%';
      zIndex = 1001;
    }
    document.body.appendChild(Media_Player.cover);
  }
  
  var iconClick = function() 
  {
    Media_Player.cover.style.display = 'none';
    this.style.display = 'none';
    audio5.play();
  }

  if(Media_Player.audio_icon)
    Media_Player.audio_icon.style.display = 'block';
  else
  {
    Media_Player.audio_icon = document.createElement("IMG");
    Media_Player.audio_icon.src = Media_Player.absPath+'images/playButton.png';
    with(Media_Player.audio_icon.style)
    {
      backgroundColor = "transparent";
      position = "absolute";
      top =  (document.body.clientHeight-130)/2 + 'px';
      left = (document.body.clientWidth-130)/2 + 'px';
      zIndex = 1002;
    }
    document.body.appendChild( Media_Player.audio_icon );
  }
  Media_Player.audio_icon.onclick = iconClick;
}
Media_Player.kill_audio = function()
{
  unload_kill = function()
  {
    var handle = document.getElementById("smilAudio");
    if(typeof(handle.resetElement) == "unknown" && handle.hasAudio)
    {
      handle.onend = null;
      handle.src = null;
    }
    else
    {
      if(handle = document.getElementById("HTML5Audio"))
        handle.parentNode.removeChild(handle);
      if(handle = document.getElementById("pluginSound"))
        handle.parentNode.removeChild(handle);
      if(Media_Player.audio_icon)
        Media_Player.audio_icon.style.display = 'none';
    }
    Media_Player.sound_ended = null;
    Media_Player.audio5ErrorCall = false;
    Media_Player.audio5ErrorFunctionEnd = null;
  }

  if(window.frames.Content)
  {
    if(document.addEventListener)
      Content.window.addEventListener('unload',unload_kill,false);
    else
      Content.window.attachEvent('onunload',unload_kill);
  }
}
} // closing the if Media_Player block