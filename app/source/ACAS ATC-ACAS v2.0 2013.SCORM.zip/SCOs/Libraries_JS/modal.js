// requires id, obj, or url
// remember that a global variable cannot have the same name as an element id
// it is recommended that _ be added to the beginning of the variable name
// requires the Cover object
function Modal( params )
{
	Modal.currObj = null;
	
	this.method = params.method ? params.method.toUpperCase() : "GET";
	this.url    = params.url;
	this.z = params.z ? params.z : 200000; // z-index
	this.coverColor = params["cover color"] ? params["cover color"] : null;
	this.coverTransparency = params["cover transparency"] ? params["cover transparency"] : null;
	this.target = !params.target ? document.body : params.target;
	this.target_document = params.target_document ? params.target_document : document; // used to get around an issue with IE7 that requires the object be created in the same document to which it will be appended
	this.frame_id = params.frame_id || "modalFrame"; 
	
    var cleanupObj = null;
	if(cleanupObj = this.target_document.getElementById(this.frame_id))
		this.target.removeChild(cleanupObj);

	// callbacks
	this._end_hide = params.end_hide;
	this._end_show = params.end_show;
	
	if ( params.id )
		this.obj = document.getElementById( params.id );
	else if ( params.obj )
		this.obj = params.obj;
	else // params.url
	{
		try { this.obj = this.target_document.createElement("<iframe id='" + this.frame_id + "' name='" + this.frame_id + "'" + (!params.onload ? "" : " onload='" + params.onload + "(this);'") + ">"); } // IE
		catch (e) // FF
		{
		   this.setIframe(this.frame_id);  
		}
		
		if(params.transparent){
                  this.obj.allowTransparency = "true";
                  this.obj.style.backgroundColor = "transparent";
                }
                
		this.obj.border = "0px";
		this.obj.margin = "0px";
		this.obj.padding = "0px";
		this.target.appendChild( this.obj );
		
		if(this.method == "POST")
		{
		   this.navigatePOST();
		}   
		else
		{
		   this.obj.src = this.url;
                } 		   
	}
	
	// fixing the target if necessary
        try{
	if ( this.obj.parentNode != this.target)
		this.target.appendChild( this.obj );
        }catch(e){}
	
	var style = this.obj.style;
    this.obj.frameBorder = '0';
	style.display = "none"; // hiding the object
	style.position = "absolute";
	style.overflow = "auto";
	style.zIndex = this.z + 1;
	if ( params.height != "auto" )
		style.height = params.height ? params.height : "90%";
	if ( params.width != "auto" )
		style.width = params.width ? params.width : "90%";
	if ( !this.obj.style.backgroundColor )
		style.backgroundColor = "#ffffff";
	
	if ( params.height == "auto" || params.width == "auto" )
		style.padding = "10px";
	
	if(params.cover !== false)
	  this.cover = new Cover({ z: this.z, color: this.coverColor, transparency: this.coverTransparency, target: this.target, target_document: this.target_document });
	
	if ( params.show )
		this.show();
}
Modal.prototype.show = function( params )
{
	if ( !params || !params.activate )
	{
		if ( Modal.currObj )
			Modal.currObj.hide();
		Modal.currObj = this;
	}
	
	var style = this.obj.style;
	style.visibility = "hidden"; // hiding the obj so that it cannot be seen, but keeping the display so that it can be measured
	style.display = "block";
	style.left = ( this.target.clientWidth - this.obj.offsetWidth ) / 2 + "px";
	style.top = (( this.target.clientHeight - this.obj.offsetHeight ) / 2) + this.target.scrollTop + "px";
	style.display = "none"; // hiding the object
	style.visibility = "visible";
	
	if(this.cover)
	  this.cover.show();
	style.display = "block";
	
	if ( this._end_show )
		this._end_show(this);
}
Modal.prototype.hide = function( params )
{
	this.obj.style.display = "none";
	if(this.cover)
		this.cover.hide();
	
	if ( !params || params.erase !== false )
		this.currObj = null;
	
	if ( this._end_hide )
		this._end_hide(this);
}
Modal.prototype.destroy = function()
{
	this.target.removeChild( this.obj );
}
Modal.prototype.standard_hide = function()
{
	this.obj.style.display = "none";
	if(this.cover)
		this.cover.hide();
	Modal.currObj = null;
}
Modal.prototype.navigatePOST = function()
{
  var urlParts = this.url.split('?');
  formElements = urlParts[1].split('&');
  var oForm = this.target_document.createElement('FORM');
  oForm.method = 'POST';
  oForm.action = urlParts[0];
  for(var i=0;i<formElements.length;i++)
  {
    NVPair = formElements[i].split('=');
    oElm = this.target_document.createElement('INPUT');
    oElm.type = 'hidden';
    oElm.name = NVPair[0];
    oElm.value = decodeURIComponent(NVPair[1]);
    oForm.appendChild(oElm);
  }
  if(!this.target_document.body)
     this.target_document.documentElement.appendChild(document.createElement('BODY'));   
  document.body.appendChild(oForm);
  oForm.target = this.obj.name;
  oForm.submit();
}
Modal.prototype.setIframe = function(id)
{
   this.obj = this.target_document.createElement("iframe");
   this.obj.id = id;
   this.obj.name = id;
}  
  
  
