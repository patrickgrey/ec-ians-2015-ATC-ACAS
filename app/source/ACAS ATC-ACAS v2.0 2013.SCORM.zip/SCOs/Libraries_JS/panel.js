/****************************************************************************************************

GLOBALS

modal				A pre-generated modal panel attached to the document.body where this file is
					included at a z-index of 10,000. This modal comes preset with the following keys:
					loading, processing, signing_in, saving, and publishing

Panel.alert( text | text, callback )
	displays the given text in the modal Panel (see modal above) with a continue button that will
	hide the modal when clicked
	text			the text string to be displayed
	callback		a function called when the continue button is clicked (replaced the hide call)


OPTIONAL PARAMS

content				{ key : content } processed by add_content
display_header		[ (true) | false ] the header is displayed
draggable			[ (true) | false ] the panel can be dragged by its title
show				[ (false) | true ] show the panel once it is rendered
style				panel | modal | accordion
top/left			coordinates, must be valid css values
height/width		dimensions, must be valid css values
target				(document.body) the node to which the panel is to be attached
z_index				(10000) the z-index of the panel


METHODS

add_content( content | key, content | content, params | key, content, params )

	adds an HTML element to the panel
	key			a string that keys the content so that it can be displayed (q.v. Panel::show)
	content		an element, id, or HTML stored as a block of data in the panel
	params {}
		buttons			buttons displayed at the bottom of the content
						a keyed array where the key is the display value of the button and the value
						is the function called upon clicking
		display_close	[true|false] display the close button in the header of the panel
		image			the src path of an image to be displayed on the left of the header area
		title			text to be displayed in the header of the content

hide()

	hides the panel

show( null | key | duration | key, duration )

	displays the panel
	key			displays the content with the associated key
	duration	displays the content for the specified time (given in seconds)

show_previous

	displays the previously displayed content
	this is used when content in the panel shows different content in the panel
	e.g. an image uploader content area may show an uploading content area in the panel,
	but upon completion wish to re-show the original uploader content area

toggle

	toggles the visibility of the panel


STRUCTURE - INTERNAL USE ONLY

cover
panel
	header
		title_image, title, close_image (actual nodes are arranged close_image, title_image, title)
	contents_container
		{ contents } > content (pointer to the currently visible contents element)

****************************************************************************************************/
/* TO DO:
Allow panels to have specific coordinates
Limit the panel size based on the target dimensions
Automatically resize and/or reposition the cover and panel onresize
Create get_content_keys
Allow graphical backgrounds and borders
Allow borders and colors
*/

function Event( callbacks )
{
	var callbacks = callbacks || [];
	this.callbacks = [];
	
	this.add = function( param_1, param_2 )
	{
		var key = null, callback = param_1;
		
		if ( param_2 )
		{
			key = param_1;
			callback = param_2;
		}
		
		if ( key )
			this.callbacks[ key ] = callback;
		else
			this.callbacks.push( callback );
	}
	
	this.process = function()
	{
		for ( key in this.callbacks )
			this.callbacks[ key ]();
	}
	
	this.remove = function( key )
	{
		delete this.callbacks[ key ];
	}
	
	for ( var i = 0; i < callbacks.length; i++ )
		this.add( callbacks[i] );
}
Event.generate_events = function( event_array )
{
	var events = [];
	
	for ( var i = 0; i < event_array.length; i++ )
		events[ event_array[i] ] = new Event();
	
	return events;
}

function Panel( params )
{
	params = params || {};
	
	// backward compatibility
	if ( params.modal )
		params.style = "modal";
	
	// properties
	this.style = params.style || "panel";
	this.draggable = params.draggable !== false ? true : false;
	this.display_header = params.display_header !== false ? true : false;
	this.visible = false;
	this.curr_key = null;
	this.return_key = null;
	this.top = params.top;
	this.left = params.left;
	this.height = params.height;
	this.width = params.width;
	
	// style limitations on properties
	switch ( this.style )
	{
		case "accordion":
			this.draggable = false;
			this.display_header = true;
			if ( params.content && params.show !== false ) // show by default if possible
				params.show = true;
			this.bottom_cap = params.bottom_cap;
			this.top_cap = params.top_cap;
			break;
		case "modal":
			this.draggable = false;
			break;
		case "panel":
			break;
	}
	
	// elements
	this.contents = {};											// an associative array of content node containers
	this.content = null;										// the currently displayed content node - stores a pointer to the content node
	this.contents_container = document.createElement("div");	// the container holding all the contents
	this.cover = this.style == "modal" ? document.createElement("div") : null;	// the cover for the rest of the screen if the panel is modal
	this.panel = document.createElement("div");					// the panel node
	this.target = params.target || document.body;				// the node to which the panel is to be attached
	
	this.events = Event.generate_events
	([
		"starting_show",
		"finished_show"
	]);
	
	// classes
	this.contents_container.className = "panel_contents_container";
	if ( this.cover )
		this.cover.className = "modal_cover";
	this.panel.className = this.style != "accordion" ? "panel" : "accordion_panel";
	if ( this.top || this.left )
		this.panel.style.position = "absolute";
	if ( this.top )
		this.panel.style.top = this.top;
	if ( this.left )
		this.panel.style.left = this.left;
	if ( this.height )
		this.panel.style.height = this.height;
	if ( this.width )
		this.panel.style.width = this.width;
	this.panel.appendChild( this.contents_container );
	
	// if this is a modal, generate a positioner element to allow for proper centering
	if ( this.cover )
	{
		// positioner centering
		this.positioner = document.createElement("div");
		var ps = this.positioner.style;
		ps.position = "absolute";
		ps.top = "50%";
		ps.left = "50%";
		
		// panel centering
		ps = this.panel.style;
		ps.position = "relative";
		ps.left = "-50%";
	}
	
	// setting the z-index
	var z_index = params.z_index || 10000;
	if ( this.cover )
	{
		this.cover.style.zIndex = z_index;
		this.positioner.style.zIndex = z_index + 1;
	}
	else // no cover
		this.panel.style.zIndex = z_index;
	
	// does not attach the panel if the target has not yet been rendered
	if ( this.target )
		this.attach_panel();
	
	// adding content
	params.content = params.content || {};
	var num_contents = params.content.length;
	for ( var i = 0; i < num_contents; i++ )
		this.add_content( params.content[i][0], params.content[i][1], params.content[i][2] );
	
	// does not attempt to show the panel if the target has not yet been rendered
	if ( this.target && params.show )
		this.show();
}
// params: content || key, content || content, params || key, content, params
// content can be an object, an id string, or HTML
// params can be title, image, buttons, display_close
// buttons is a keyed array where the key is the display value of the button and the value is the function called upon clicking
Panel.prototype.add_content = function( param_1, param_2, params )
{
	var key = param_2 ? param_1 : null;
	var content = key ? param_2 : param_1;
	var content_container = document.createElement("div");
	params = params || {};
	
	// style limitations on properties
	if ( this.style == "accordion" )
	{
		params.display_close = false;
		if ( !params.title && key )
			params.title = key.replace(/_/g, " ");
	}
	
	if ( this.style == "accordion" )
	{
		var bc = document.createElement("img"); // bottom cap, the cap on the bottom of the content area
		bc.src = this.bottom_cap || "";
		var bcs = bc.style;
		bcs.backgroundColor = "#ffffff";
		bcs.display = "none";
		content_container.appendChild(bc);
	}
	
	// header
	if ( params.title || params.image )
	{
		var header = document.createElement("div");
		header.className = "panel_header";
		
		// clicking on the title bar of accordion content expands or collapses the content
		if ( this.style == "accordion" )
		{
			var ref = this;
			header.className = "panel_accordion_header";
			header.onmouseover = function() { this.className = "panel_accordion_header_highlight"; }
			header.onmouseout = function() { this.className = "panel_accordion_header"; }
			header.onclick = function() { ref.show(key); }
		}
		
		// the image must go first as it is floated right
		if ( params.display_close !== false )
		{
			var header_close = document.createElement("img");
			header_close.className = "panel_title_image";
			header_close.src = "images/remove_gray.gif";
			header_close.onmouseover = function() { this.src = "images/remove_red.gif"; }
			header_close.onmouseout = function() { this.src = "images/remove_gray.gif"; }
			header_close.onclick = this.hide.bind(this);
			header.appendChild(header_close);
		}
		
		if ( params.image )
		{
			var header_image = document.createElement("img");
			header_image.className = "panel_title_image";
			header_image.src = params.image;
			header.appendChild(header_image);
		}
		
		if ( params.title )
		{
			var header_text = document.createElement("div");
			header_text.className = "panel_title";
			header_text.innerHTML = params.title;
			header.appendChild( header_text );
		}
		
		content_container.appendChild( header );
		
		// making the panel draggable
		header.unselectable = "on";
		if ( this.draggable )
			var drag_trigger = new Drag_Trigger({ trigger : header, object : [ this.panel ] });
	}
	
	if ( this.style == "accordion" )
	{
		var tc = document.createElement("img"); // top cap, the cap on the top of the content area
		tc.src = this.top_cap || "";
		var tcs = tc.style;
		tcs.backgroundColor = "#ffffff";
		tcs.display = "none";
		content_container.appendChild(tc);
	}
	
	if ( typeof( content ) == "string" )
	{
		if ( content.length < 256 && $(content) ) // checking to see if the string is an ID and not HTML
			content = $(content);
		else
		{
			var html = content;
			content = document.createElement("div");
			content.innerHTML = html;
		}
	}
	if ( !content.className )
		content.className = (this.style == "accordion" ? "accordion_" : "") + "panel_inner_content_container";
	content_container.appendChild( content );
	
	content_container.style.display = "none";
	
	// adding buttons to the content
	if ( params.buttons )
	{
		content_container.buttons = {};
		
		var footer = document.createElement("div");
		footer.className = "panel_footer";
		
		for ( button_value in params.buttons )
		{
			var button = document.createElement("input");
			button.type = "button";
			button.value = button_value.replace(/_/g, " ");
			button.className = "panel_footer_button";
			if ( button.addEventListener )
				button.addEventListener("click", params.buttons[button_value], false);
			else
				button.attachEvent("onclick", params.buttons[button_value]);
			footer.appendChild( button );
			content_container.buttons[ button_value ] = button;
		}
		content_container.appendChild( footer );
	}
	
	// removing any existing contents if the key already exists
	if ( key && this.contents[ key ] )
		this.contents_container.removeChild( this.contents[ key ] );
	
	this.contents_container.appendChild( content_container );
	
	if ( key )
		this.contents[ key ] = content_container;
	
	if ( !this.content )
		this.content = content_container;
}
Panel.alert = function( text, callback )
{
	modal.return_key = modal.get_curr_key();
	var continue_function = modal.return_key ? function() { modal.show_previous.bind(modal)(); if ( typeof(callback) != "undefined" ) callback(); } : function() { modal.hide(); if ( typeof(callback) != "undefined" ) callback(); };
	var result = modal.add_content("alert", "<div class='panel_message'>" + text + "</div>", {buttons : {"continue":continue_function} });
	
	result = modal.show("alert");
	modal.content.buttons["continue"].focus();
	
	return result;
}
// TO DO: see if this can be a modal somehow, perhaps recalling the callee with modal value set that gets unset upon recall?
Panel.confirm = function( text, callback )
{
	modal.return_key = modal.get_curr_key();
	var continue_function = modal.return_key ? function() { modal.show_previous.bind(modal)(); if ( typeof(callback) != "undefined" ) callback(); } : function() { modal.hide(); if ( typeof(callback) != "undefined" ) callback(); };
	var cancel_function = modal.return_key ? function() { modal.show_previous.bind(modal)(); } : function() { modal.hide(); };
	var result = modal.add_content("alert", "<div class='panel_message'>" + text + "</div>", {buttons : {"continue":continue_function, "cancel":cancel_function} });
	
	result = modal.show("alert");
	modal.content.buttons["continue"].focus();
	
	return result;
}
Panel.prototype.attach_panel = function()
{
	if ( this.target )
	{
		if ( this.cover )
		{
			this.target.appendChild( this.cover );
			this.positioner.appendChild( this.panel );
			this.target.appendChild( this.positioner );
		}
		else // not modal
			this.target.appendChild( this.panel );
		
		return true;
	}
	
	return false;
}
// assumes the correct content is set
Panel.prototype.center_panel = function()
{
	var ps = this.panel.style;
	ps.marginTop = (( this.panel.offsetHeight / 2 ) * -1 ) + "px";
}
Panel.prototype.exists = function( key )
{
	return typeof( this.contents[ key ] ) != "undefined";
}
Panel.prototype.get_curr_key = function() { return this.curr_key; }
Panel.prototype.hide = function()
{
	this.panel.style.display = "none";
	
	if ( this.cover )
		this.cover.style.display = "none";
	
	this.visible = false;
	this.curr_key = null;
}
Panel.prototype.is_visible = function() { return this.visible; }
Panel.prototype.remove_content = function( key )
{
	if ( key )
	{
		if ( this.contents[ key ] === this.content )
			this.content = null;
		
		delete this.contents[ key ];
	}
	else // remove all content
	{
		this.content = null;
		this.contents = {};
	}
}

Panel.prototype.set_cover_color = function( color ) { this.cover.style.backgroundColor = color; }

// displays the panel and cover (if there is one)
// if a key is passed in, the associated content node is assigned to be the current content node
// params: key || duration (in seconds) || key, duration (in seconds)
Panel.prototype.show = function( param_1, param_2 )
{
	this.events.starting_show.process();
	
	// ensuring there are no accidental global references
	var key = null;
	var duration = null;
	
	if ( param_1 && typeof( param_1 ) == "string" )
		key = param_1;
	else if ( param_1 ) // assume it's a number if it's not a string
		duration = param_1;
	
	if ( param_2 ) // can only be a duration
		duration = param_2;
	
	// ensuring the panel has been attached
	if ( !this.target )
	{
		if ( !document.body )
			return alert("The panel cannot be shown as it has not yet been rendered");
		
		this.target = document.body;
		this.attach_panel();
	}
	
	// displaying the appropriate content
	if ( key )
	{
		if ( !this.contents[ key ] )
			return alert("The panel cannot be shown as the selected content (" + key + ") does exist");
		
		if ( !this.curr_key ) // storing the key of the currently displayed panel
			this.return_key = key;
		
		// hiding the previous content
		if ( this.content )
			this.content.style.display = "none";
		
		this.content = this.contents[ key ];
		this.curr_key = key;
	}
	else if ( !this.content )
		return alert("The panel cannot be shown as no content has been set");
	
	// start adjusting for a bug with width:auto in quirks mode
	if ( this.cover )
		this.cover.style.display = "block";
	
	if ( this.style != "accordion" )
		this.content.style.display = "block";
	else // accordion style always displays the header of all content
	{
		var key_found = false;
		for ( content_key in this.contents )
		{
			if ( !key )
				key = this.curr_key = this.curr_key ? this.curr_key : content_key;
			
			var nodes = this.contents[content_key].children;
			if ( key_found && this.bottom_cap )
			{
				nodes[0].style.display = "block";
				key_found = false;
			}
			else
				nodes[0].style.display = "none";
			nodes[1].style.display = "block";
			if ( content_key == key )
			{
				if ( this.top_cap )
					nodes[2].style.display = "block";
				else
					nodes[2].style.display = "none";
				key_found = true;
			}
			else
				nodes[2].style.display = "none";
			nodes[3].style.display = "none";
			
			this.contents[content_key].style.display = "block";
		}
		
		// recalculate the height of the contents to fill the panel height
		if ( this.style == "accordion" )
		{
			this.content.children[3].style.height = (this.panel.offsetHeight - this.contents_container.offsetHeight) + "px";
			this.content.children[3].style.display = "block";
		}
		else
			this.content.children[1].style.display = "block"; // opens the currently selected content area
	}
	this.panel.style.display = "block";
	
	// fixing width issues with quirks mode
/*	this.header.style.display = "none";
	var true_contents_container_width = this.contents_container.offsetWidth;
	if ( this.display_header )
		this.header.style.display = "block";
	if ( this.contents_container.offsetWidth != true_contents_container_width )
		this.header.style.width = true_contents_container_width;
	*/
	this.panel.style.display = "";
	this.panel.style.display = "block";
	
	if ( this.cover )
		this.center_panel();
	// end adjusting for a bug with width:auto in quirks mode
	
	this.visible = true;
	
	this.events.finished_show.process();
	
	if ( duration )
		setTimeout( this.hide.bind(this), duration * 1000 );
}
Panel.prototype.show_previous = function()
{
	if ( this.return_key )
		this.show( this.return_key );
	else
		alert("Unable to show the previous content as no return key is set.");
}

Panel.prototype.toggle = function()
{
	if ( !this.visible )
		this.show();
	else
		this.hide();
}

modal = new Panel
({
	modal : true,
	z_index : 100000,
	display_header : false,
	content :
	[
		["loading", "<div class='panel_message'>loading...</div>"],
		["processing", "<div class='panel_message'>processing...</div>"],
		["signing_in", "<div class='panel_message'>signing in...</div>"],
		["saving", "<div class='panel_message'>saving...</div>"],
		["publishing", "<div class='panel_message'>publishing...</div>"]
	]
});
