function AICC_Incomplete()
{
    var prefix = top.MainContent ? top.MainContent : parent;
    score = 0;
    lesson_status = 'i';
    lesson_location = '';
    credit = 'c';
    lesson_mode = 'n';
    path = '';
    TimeSpent = Math.round((new Date().getTime() - prefix.StartTime) / 1000);
    Seconds = TimeSpent % 60;
    Minutes = Math.floor(TimeSpent / 60);
    Minutes = Minutes % 60;
    Hours   = Math.floor(TimeSpent / 3600);
    if(Seconds < 10) Seconds = '0'+Seconds;
    if(Minutes < 10) Minutes = '0'+Minutes;
    TimeSpent = Hours+':'+Minutes+':'+Seconds;
    putdata = "%5Bcore%5D%0D%0A" + "lesson_location%3d" + lesson_location + "%0D%0A" + "credit%3D" + credit + "%0D%0A" + "lesson_mode%3D" + lesson_mode + "%0D%0A" + "lesson_status%3D" + lesson_status + "%0D%0A" + "path%3D" + path  + "%0D%0A" + "time%3D" + TimeSpent + "%0D%0A" + "score%3D" + score + "%0D%0A";
    try
    { 
      if(top.window.opener.aiccSubmission)
      {
        top.window.opener.document.forms.aiccput.aicc_data.value = decodeURIComponent(putdata);
        top.window.opener.document.forms.aiccput.submit();
      }
      else
      {
        top.windowOpenPOST(window,'aicc_callback.php?aicc_url='+prefix.aicc_url+'&aicc_sid='+prefix.aicc_sid+'&putdata='+putdata,'','top=200,left=200,width=200,height=100');
      }
    }
    catch(e)
    {
      top.windowOpenPOST(window,'aicc_callback.php?aicc_url='+prefix.aicc_url+'&aicc_sid='+prefix.aicc_sid+'&putdata='+putdata,'','top=200,left=200,width=200,height=100');
    }
}
