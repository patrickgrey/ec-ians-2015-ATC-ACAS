var offline = location.href.indexOf('NewLinx') == -1 ? (location.href.indexOf('SCOs') == -1 ? 'SCOs/DOCs/' : 'DOCs/') : false; 
var PageLink =
{
	panel : new Panel({ id:"page_link_panel", top:"0px", left:"0px", width:"100%", height:"100%"}),
	show : function ( page_id )
	{
		if(parent.object_actions && parent.object_actions.actions)
			parent.save_object_actions = parent.object_actions.actions;
		else if(window.object_actions && window.object_actions.actions)
			window.save_object_actions = window.object_actions.actions;
		else
			parent.save_object_actions = false;
		if ( !PageLink.panel.exists( page_id ) )
		{
			var iframe = document.createElement("iframe");
			if(offline)
				iframe.src = offline+page_id.split('^').join('')+'.htm';
			else
				iframe.src = "BuildDoc.php?FromPrintPreview=Y&DocID=" + page_id + "&ClusterID=" + g_sSCO_ID + "&UserID=" + encodeURIComponent(Content.document.forms.Main.UserID.value) + "&SessionKey=" + Content.document.forms.Main.SessionKey.value + "&no_borders=true";
			iframe.style.height = "100%";
			iframe.style.width = "100%";
			iframe.style.border = "none";
			var ps = PageLink.panel.panel.style;
			ps.padding = "0px";
			ps.border = "0px";
			PageLink.panel.add_content( page_id, iframe );
			PageLink.panel.panel.style.height = $("Content").clientHeight + "px";
			PageLink.panel.panel.style.width = $("Content").clientWidth + "px";
			PageLink.panel.panel.style.top = $("Content").style.top;
			PageLink.panel.panel.style.left = $("Content").style.left;
			PageLink.panel.contents_container.style.height = "100%";
			PageLink.panel.contents_container.children[0].style.height = "100%";
		}
		PageLink.panel.show( page_id );
	}
}