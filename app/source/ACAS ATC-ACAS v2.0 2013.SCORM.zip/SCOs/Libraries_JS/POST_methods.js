function windowOpenPOST(which,windowURL,windowName,windowParms)
{
  switch(arguments.length)
  {
    case 2:
      windowName = new Date().getTime();
      windowParms = '';   
      break;
    case 3:
      if(!windowName || windowName == '_blank')
        windowName = new Date().getTime();
      windowParms = '';   
      break;
    case 4:
      if(!windowName || windowName == '_blank')
        windowName = new Date().getTime();
      break;
    default:
      winHandle = which.window.open();
      storeWinHandle(winHandle);
      return winHandle;
  }
  var urlParts = windowURL.split('?');
  if(urlParts.length < 2)
  {
    winHandle = which.window.open(windowURL,windowName,windowParms);
    storeWinHandle(winHandle);
    return winHandle;
  }
  if(urlParts[0].split(".").reverse()[0].toLowerCase() != 'php' )
  {
    winHandle = which.window.open(windowURL,windowName,windowParms);
    storeWinHandle(winHandle);
    return winHandle;
  }

  formElements = urlParts[1].split('&');
  if ( windowName != "SCORM_Wrapper_Frame" )
  {
	  var winHandle = which.window.open('about:blank',windowName,windowParms); 
	  if (!winHandle) return false;
  }
  else
  	winHandle = window.SCORM_Wrapper_Frame;

  var oForm = which.document.createElement('FORM');
  oForm.method = 'POST';
  oForm.action = urlParts[0];
  oForm.target = winHandle.name;
  for(var i=0;i<formElements.length;i++)
  {
    NVPair = formElements[i].split('=');
    oElm = which.document.createElement('INPUT');
    oElm.type = 'hidden';
    oElm.name = NVPair[0];
    oElm.value = decodeURIComponent(NVPair[1]);
    oForm.appendChild(oElm);
  }
  if(!which.document.body)
     which.document.documentElement.appendChild(which.document.createElement('BODY'));   
  which.document.body.appendChild(oForm);
  oForm.submit();
  which.document.body.removeChild(oForm);
  storeWinHandle(winHandle);
  return winHandle;
}

function storeWinHandle(which)
{
  try
  {
    if(!top.openWins)
      top.openWins = [];
    top.openWins.push(which);
  }
  catch(e) {}
}

function navigatePOST(URL,target)
{
  var urlParts = URL.split('?');
  formElements = urlParts[1].split('&');
  var oForm = document.createElement('FORM');
  oForm.method = 'POST';
  oForm.action = urlParts[0];
  for(var i=0;i<formElements.length;i++)
  {
    NVPair = formElements[i].split('=');
    oElm = document.createElement('INPUT');
    oElm.type = 'hidden';
    oElm.name = NVPair[0];
    oElm.value = decodeURIComponent(NVPair[1]);
    oForm.appendChild(oElm);
  }
  if(!document.body)
     document.documentElement.appendChild(document.createElement('BODY'));   
  document.body.appendChild(oForm);
  if(target)
    oForm.target = target;
  oForm.submit();
}
