/*
requires Libraries_JS/function_extensions.js

methods:
  flash_object - create flash_view object,shows and plays the flash
    params:
      name            - (string) name of the flash dom object
     
      on_pause        - (function) callback on the pause event 
      on_change_frame - (function) callback on the change frame event 
      on_end          - (function) callback on the end event 
      
  set_callback - set / overwrite call back methods
    params:
      on_pause        - (function) callback on the pause event 
      on_change_frame - (function) callback on the change frame event 
      on_end          - (function) callback on the end event 

  play        - plays the flash
  
  stop        - pause the flash
  
  rewind      - rewind the flash
  
  next_frame  - show the next frame of the flash
  
  zoom_out    - zoom out
  
  zoom_in     - zoom in
  
  send_data   - sends a text to the flash   (currently unused)
    args: (string) text to be send to flash
  
  get_data    - gets a text from the flash  (currently unused)
    return: (string) text send by the flash
  
 vars:
   current_frame - (integer) number of the current frame
   end_frame     - (integer) number of the last frame
*/

function flash_object(param)
{
  if(!(param && param.name))
    return;
  this.name = param.name;
  
  //callbacks
  this.on_pause        =  null;
  this.on_change_frame =  null;
  this.on_end          =  null;
  this.set_callback(param);

  this.timer_id = null;
  if (window.document[this.name])
  {
    this.obj = window.document[name];
  }
  if (navigator.appName.indexOf("Microsoft Internet")==-1)
  {
    if (document.embeds && document.embeds[this.name])
      this.obj = document.embeds[this.name];
  }
  else // if (navigator.appName.indexOf("Microsoft Internet")!=-1)
  {
    this.obj = document.getElementById(this.name);
  }
  //vars
  this.previous_frame = null;
  this.get_end_frame();
  this.get_current_frame();
}
flash_object.prototype.get_end_frame = function(param)
{
  if(!this.end_frame)
    try
    { 
      this.end_frame = this.obj.TGetProperty("/", 5);
    }
    catch(e)
    {
      this.end_frame = null;
    }
  return this.end_frame;
}
flash_object.prototype.get_current_frame = function(param)
{
  if(!this.current_frame) 
    try
    {
      this.current_frame = this.obj.TGetProperty("/", 4);
    }
    catch(e)
    {
      this.current_frame = null;
    }
  return this.current_frame;
}
flash_object.prototype.set_callback = function(param)
{
  if(!param)
    return;

  //callbacks
  this.on_pause        = (param.on_pause       ) ? param.on_pause        : this.on_pause;
  this.on_change_frame = (param.on_change_frame) ? param.on_change_frame : this.on_change_frame;
  this.on_end          = (param.on_end         ) ? param.on_end          : this.on_end;
}

flash_object.prototype.stop = function()
{
  this.obj.StopPlay();
  window.clearInterval(this.timer_id);
  this.timer_id = null;
  if(this.on_pause) try{  this.on_pause(); } catch(e) {}
}

flash_object.prototype.check = function()
{
  this.current_frame = this.obj.TGetProperty("/", 4);
  if(this.on_change_frame && this.previous_frame != this.current_frame)
  {
    this.previous_frame = this.current_frame;
    try{this.on_change_frame();} catch(e){}
  }
  if(this.current_frame == this.get_end_frame())
  {
    window.clearInterval(this.timer_id);
    this.timer_id = null;
    if(this.on_end) try {  this.on_end();} catch(e) {}
  }
}
flash_object.prototype.play = function()
{
  this.obj.Play();
  this.timer_id = window.setInterval(this.check.bind(this), 100);
}

flash_object.prototype.rewind = function()
{
  this.obj.Rewind();
  this.current_frame = parseInt(this.obj.TGetProperty("/", 4));
  if(this.on_change_frame)
  {
    try{this.on_change_frame();} catch(e){}
  }
}

flash_object.prototype.next_frame = function()
{
  this.current_frame = parseInt(this.obj.TGetProperty("/", 4));
  var next= this.current_frame >= this.get_end_frame() ? 0: this.current_frame;
  
  this.obj.GotoFrame(next);
  if(this.on_change_frame)
  {
    try{this.on_change_frame();} catch(e){}
  }

}
flash_object.prototype.zoom_in = function()
{
  this.obj.Zoom(90);
}
flash_object.prototype.zoom_out = function()
{
  this.obj.Zoom(110);
}
flash_object.prototype.send_data = function(text)
{
  this.obj.SetVariable("/:message", text);
}
flash_object.prototype.get_data = function(text)
{
  return this.obj.GetVariable("/:message");
}
