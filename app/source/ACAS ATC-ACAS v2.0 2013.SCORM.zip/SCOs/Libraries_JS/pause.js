var pageTimers = {};
function pausePage()
{
  parent.Media_Player.pause(parent.document.getElementById("smilAudio"));
  for(var i in pageTimers)
    pageTimers[i].pause();
}
function unpausePage()
{
  for(var i in pageTimers)
    pageTimers[i].unpause();
  parent.Media_Player.unpause(parent.document.getElementById("smilAudio"));
}
function pausableTimeout(func,millisec)
{
  var which = this;
  this.func = function() { which.fired = true;if(typeof(func) == 'function') func(); else eval(func); }
  this.fired = false;
  this.paused = false;
  this.timeout = setTimeout(this.func,millisec);
  this.fireTime = new Date().valueOf();
  this.timeLeft = millisec;
}
pausableTimeout.prototype.pause = function()
{
  this.timeLeft -= (new Date().valueOf()-this.fireTime);
  clearTimeout(this.timeout);
  this.paused = true;
}
pausableTimeout.prototype.unpause = function()
{
  if(!this.fired && this.paused)
  {
    if(this.timeLeft < 0) //latency between timeout call and time calculation
      this.timeLeft = 0;
    this.paused = false;
    this.timeout = setTimeout(this.func,this.timeLeft);
    this.fireTime = new Date().valueOf();
  }
}
pausableTimeout.prototype.stop = function()
{
  this.fired = true;
  this.pause();
}
function pausableInterval(func,millisec)
{
  this.func = func;
  this.millisec = millisec;
  this.stopped = false;
  this.paused = false;
  this.interval = setInterval(func,millisec);
}
pausableInterval.prototype.pause = function()
{
  clearInterval(this.interval);
  this.paused = true;
}
pausableInterval.prototype.unpause = function()
{
  if(!this.stopped && this.paused)
  {
    this.paused = false;
    this.interval = setInterval(this.func,this.millisec);
  }
}
pausableInterval.prototype.stop = function()
{
  this.stopped = true;
  this.pause();
}
