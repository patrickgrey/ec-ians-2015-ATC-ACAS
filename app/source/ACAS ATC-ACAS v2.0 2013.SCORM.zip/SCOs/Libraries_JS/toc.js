/****************************************************************************************************
depth			(int - default: 1) the number of folders into the root the containing page is
				E.g. <root>/ObjectFiles/HTMLImport/rootuser/H5/containing_file.html has a depth of 4
ignore_field	OPTIONAL (string) the page attribute name used to determine if a page should be
				rendered in the menu list
ignore_text		OPTIONAL (string) if this text exists in the ignore_field page attribute, the page
				will not be rendered in the menu list
				NOTE: if no ignore_text is specified, but an ignore_field is, the page will be
				ignored if there is any value in the attribute
nav_access		[(free)|visited]
				free		learners may skip to whatever page they desire
				visited		learners may only go to a page they've already visited or the next
							new page
****************************************************************************************************/
var ToC = function( params )
{
	params = params || {};
	
	this.json = params.json || [];
	
	this.clusters = [];
	this.pages = []; // stores pointers to all pages in all clusters in order - specifically to support faux clusters formed from page metadata
	
	// callbacks
	this.finished_page_display = params.finished_page_display || null;
	this._end_load_data = params.end_load_data || null;
	
	this.accordion_params = params.accordion_params || {fillSpace : true};
	this.container_id	= params.container_id	|| "ToC_container";
	this.data			= params.data			|| "";
	this.ignore_field	= params.ignore_field	|| "";
	this.ignore_text	= params.ignore_text	|| "";
	this.nav_access		= params.nav_access		|| "free";
	this.height			= params.height;
	this.start_disabled	= params.start_disabled	|| false;
	this.depth			= params.depth			|| 1;
	this.offline		= params.offline		|| false;
	this.path_to_root	= "";
	for ( var i = 0; i < this.depth; i++ )
		this.path_to_root += "../";
	this.data_source	= params.data_source	|| (this.path_to_root + "API/get_course_page_json.php");
	this.curr_page_index = 0;
	this.curr_cluster	= null;
	
	this.user_id = params.user_id || "";
	this.session_key = params.session_key || "";
	
	this.cluster_class	= params.cluster_class || "toc_cluster";
	this.page_class		= params.page_class || "toc_page";
	this.pages_container_class = params.pages_container_class || "toc_page_container";
	
	this.container = document.getElementById(this.container_id);
	
	this.load_data();
};
ToC.prototype.generate = function()
{
	var num_clusters = this.json.length;
	for ( var i = 0; i < num_clusters; i++ )
	{
		var cluster = new ToC.Cluster({toc : this, json : this.json[i], index : i, finished_page_display : this.finished_page_display});
		this.clusters.push( cluster );
		
		// appending cluster elements
		this.container.appendChild( cluster.header );
		this.container.appendChild( cluster.pages_container );
	}
};
ToC.prototype.load_data = function() { new AJAX({ path : this.data_source, data : this.data, processor : this.process_data.bind(this), return_type : "json", asynchronous : true }); };
ToC.prototype.process_data = function( json )
{
	this.json = json;
	
	this.generate();
	
	// fixing a display bug in IE
	if ( this.height )
		this.container.style.height = this.height;
	
	setTimeout(this.set_accordion.bind(this), 200);
};
ToC.prototype.set_accordion = function()
{
	$("#" + this.container_id).accordion("destroy").accordion( this.accordion_params );
	
	if ( this.height && this.clusters.length > 1 && (this.clusters[1].header.offsetTop == 0 || this.clusters[1].header.offsetTop > Number(this.height.replace(/px/,""))) )
		setTimeout(this.set_accordion.bind(this), 200);
	else
	{
		this.highlight_pages();
		if ( this._end_load_data )
			this._end_load_data(this);
	}
};
ToC.prototype.highlight_pages = function()
{
	var num_clusters = this.clusters.length;
	for ( var i = 0; i < num_clusters; i++ )
	{
		var cluster = this.clusters[i];
		var num_pages = cluster.pages.length;
		for ( var j = 0; j < num_pages; j++ )
		{
			if ( !cluster.pages[j].is_valid() )
				cluster.pages[j].disable();
			else
				cluster.pages[j].enable();
		}
	}
};
ToC.Cluster = function( params )
{
	params = params || {};
	
	this.toc = params.toc;
	this.json = params.json || [];
	this.index = params.index || 0;
	this.locked = false; // if true, display is disabled
	this.pages = [];
	this.finished_page_display = params.finished_page_display || null;
	
	this.header = document.createElement("h3");
	this.header.className = this.toc.cluster_class;
	
	this.link = document.createElement("a");
	this.link.href = "javascript:void(0);";
	
	this.header.appendChild(this.link);
	
	this.pages_container = document.createElement("div");
	this.pages_container.className = this.toc.pages_container_class;
	
	this.generate();
};
ToC.Cluster.prototype.lock = function() { this.locked = true; }
ToC.Cluster.prototype.unlock = function() { this.locked = false; }
ToC.Cluster.prototype.display = function()
{
	if ( !this.locked && this.pages[0] && !this.pages[0].disabled )
		this.pages[0].display();
};
ToC.Cluster.prototype.generate = function()
{
	var cluster = this.json;
	
	this.link.innerHTML = cluster.title;
	
	// attaching go to page for the cluster header
	if ( this.link.addEventListener )
		this.link.addEventListener("click", this.display.bind(this));
	else
		this.link.attachEvent("onclick", this.display.bind(this), false);
	
	// building the pages
	var pages = cluster.pages;
	var num_pages = pages.length;
	
	for ( var i = 0; i < num_pages; i++ )
	{
		var page = new ToC.Page({toc : this.toc, cluster : this, json : pages[i], index : i, finished_display : this.finished_page_display});
		this.pages.push( page );
		
		// adding to the toc page list
		page.index_in_toc = this.toc.pages.length;
		this.toc.pages.push( page );
		
		// appending page element
		this.pages_container.appendChild(page.item);
	}
};
ToC.Page = function( params )
{
	params = params || [];
	
	this.toc = params.toc;
	this.cluster = params.cluster;
	this.index = params.index || 0;
	this.index_in_toc = params.index_in_toc || 0;
	this.json = params.json || [];
	this.finished_display = params.finished_display || null;
	
	this.item = document.createElement("div");
	this.link = document.createElement("a");
	this.item.appendChild(this.link);
	this.item.className = this.toc.page_class;
	
	this.disabled = false;
	
	this.generate();
};
ToC.Page.prototype.disable = function()
{
	this.link.style.fontWeight = "normal";
	this.link.style.color = "#cc0000";
	this.disabled = true;
};
ToC.Page.prototype.display = function( path_to_root )
{
	if ( this.disabled == true )
		return;
	
	path_to_root = typeof path_to_root == "string" ? path_to_root : this.toc.path_to_root;
	
	if ( !this.toc.offline )
	{
		var user_id = encodeURIComponent(this.toc.user_id);
		var session_key = this.toc.session_key;
		var course_id = parent.g_sCourseID;
		
		var template_id = this.json.template_id || "";
		
		if ( this.toc.curr_cluster !== null && this.toc.curr_cluster != this.cluster.index )
			parent.leave_sco();
		this.toc.curr_cluster = this.cluster.index;
		
		var url = path_to_root + "NewLinx/RunThruCluster.php?UserID=" + user_id
			+ "&SessionKey=" + session_key + "&CourseID=" + course_id + "&CourseVersion=1&PDA=&Preview=N"
			+ "&ClusterID=" + this.cluster.json.id + "&ClusterVersion=1&ClusterNumber=" + (this.cluster.json.number + 1)
			+ "&DocID=" + this.json.id
			+ "&DocNumber=" + this.json.number
			+ "&TemplateID=" + template_id;
		parent.Content.location.href = url;
	}
	else
		parent.Functions.fGoToPage(this.index_in_toc + 1, path_to_root + "DOCs/");
	
	this.activate();
	
	if ( this.finished_display )
		this.finished_display( this );
};
ToC.Page.prototype.enable = function()
{
	this.link.style.fontWeight = "normal";
	this.link.style.color = "#49758d";
	this.disabled = false;
};
ToC.Page.prototype.activate = function()
{
	if ( this.toc.active_page )
		this.toc.active_page.enable();
	
	if ( this.index + 1 < this.cluster.pages.length )
		this.cluster.pages[this.index + 1].enable();
	else if ( this.cluster.index + 1 < this.toc.clusters.length )
		this.toc.clusters[this.cluster.index+1].pages[0].enable();
	
	// ensuring the dom is visible
	this.cluster.lock();
	this.cluster.link.click();
	this.cluster.unlock();
	
	this.toc.active_page = this;
	this.toc.curr_page_index = this.index_in_toc;
	
	this.link.style.color = "#333333";
	this.link.style.fontWeight = "bold";
	this.disabled = false;
};
ToC.Page.prototype.is_valid = function()
{
	var cluster_status = "";
	var viewed = false;
	var prev_is_viewed = false;
	if ( parent.TrackingData )
	{
		var page_index = !this.json.group_name ? this.index : this.index_in_toc;
		cluster_status = parent.TrackingData[this.toc.clusters[this.cluster.index].json.id].Status;
		viewed = parent.TrackingData[this.toc.clusters[this.cluster.index].json.id].pages[page_index].viewed;
		if ( page_index > 0 && parent.TrackingData[this.toc.clusters[this.cluster.index].json.id].pages[page_index - 1].viewed )
			prev_is_viewed = true;
		if ( page_index == 0 && this.cluster.index > 0 && parent.TrackingData[this.toc.clusters[this.cluster.index-1].json.id].pages[parent.TrackingData[this.toc.clusters[this.cluster.index-1].json.id].pages.length-1].viewed )
			prev_is_viewed = true;
	}
	else if ( parent.PagesVisited )
	{
		var page_index = !this.json.group_name ? this.index : this.index_in_toc;
		cluster_status = parent.API.LMSGetValue("cmi.core.lesson_status");
		viewed = parent.PagesVisited[this.json.id].visited;
		if ( page_index > 0 && parent.PagesVisited[this.toc.pages[page_index-1].json.id].visited )
			prev_is_viewed = true;
	}
	
	if ( viewed || prev_is_viewed )
		return true;
	
	if ( this.toc.nav_access == "visited"
		&& (this.index != 0 || this.cluster.index != 0)
		&&	((this.index == 0 && this.cluster.index != 0
				&& (cluster_status == "incomplete" || cluster_status == "not attempted" || cluster_status == ""))
			|| (this.index != 0 && !viewed )
			)
		)
		return false;
	
	return true;
};
ToC.Page.prototype.generate = function()
{
	var page = this.json;
	
	this.link.href = "javascript:void(0);";
	this.link.innerHTML = page.title;
	
	if ( this.link.addEventListener )
		this.link.addEventListener("click", this.display.bind(this));
	else
		this.link.attachEvent("onclick", this.display.bind(this), false);
	
	// determining if a page should be ignored
	// if the beginning of the selected page attribute text is equal to the ignore text, do not display the page in the menu
	if ( this.toc.ignore_field && page[this.toc.ignore_field] && page[this.toc.ignore_field].slice(0,this.toc.ignore_text.length) == this.toc.ignore_text )
		this.item.style.display = "none";
	
	if ( this.toc.start_disabled )
		this.disable();
};