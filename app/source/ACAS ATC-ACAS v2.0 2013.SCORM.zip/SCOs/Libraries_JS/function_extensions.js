/********************
DESCRIPTION
This file contains extensions to JavaScript objects to
make it easier to support some of the more common activities

REQUIREMENTS
none

FUNCTIONS
bind					this function allows you to replace the meaning of the this pointer with another
						e.g. if you have an instance of an object called my_obj and you are using it to assign
							a function to an HTML element event, applying .bind(this) will mean that when the
							function in question is called, this will refer to the my_obj object instead of
							to the HTML element

ARRAYS
is_array				property of all array objects. returns true if the object is an array, false or null if not

contains( params )		param may be an object or an array of objects
						returns true if the param (or any object in the param array) is present
							in the array

EXAMPLES
is_array				if ( my_var.is_array ) alert("my_var is an array");

contains( params )		my_array.contains( "bob" ); // returns true if one of the elements in my_array is a string with a value of bob
						my_array.contains( "bob", "jim" ); // returns true if one of the elements in my_array is a string with a value of either bob or jim
********************/

Function.prototype.bind = function( object )
{
	var __method = this;
	return function() { return __method.apply( object, arguments ); }
}


if ( typeof($) == "undefined" ) // ensuring $ does not overwrite the version defined by prototype (used by the tabs in SB)
$ = function( id ) { return document.getElementById( id ); }

function disableElement(element,disabled)
{
  if(element.getAttribute)
  {
    element.disabled = disabled;
	disableElementOnClick(element,disabled);
  }
  for(var i=0,n=element.children.length;i<n;i++)
  {
    if(element.children[i].children.length > 0)
      disableElement(element.children[i],disabled);
    else if(element.children[i].getAttribute)
    {
      element.children[i].disabled = disabled;
      disableElementOnClick(element.children[i],disabled);
    }
  }
}

function disableElementOnClick(elm,disabled)
{
  if(elm.tagName == 'IMG')
    elm.style.display = disabled ? 'none' : 'inline';
  else if(elm.tagName == 'A')
  {
    if(elm.getAttribute('dummyDisabled') || eval(elm.getAttribute('disabledState')) == disabled)
      return;
    if(disabled)
    {
      if(elm.previousElementSibling && elm.previousElementSibling.getAttribute('dummyDisabled'))
        elm.previousElementSibling.style.display = elm.currentStyle.display;
      else
      {
        var obj = elm.ownerDocument.createElement('A');
        obj.className = elm.className;
        obj.style.cssText = elm.style.cssText;
        obj.innerText = elm.innerText;
        obj.setAttribute('dummyDisabled','1');
        elm.parentNode.insertBefore(obj,elm);
      }
      elm.style.display = 'none';
    }
    else
    {
      if(elm.previousElementSibling && elm.previousElementSibling.getAttribute('dummyDisabled'))
      {
        elm.style.display = elm.previousElementSibling.currentStyle.display;
        elm.previousElementSibling.style.display = 'none';
      }
    }
    elm.setAttribute('disabledState',disabled);
  }
}

function extendBrowserFeatures() 
{
  if(document.attachEvent === undefined)
  {
    Object.defineProperty(Node.prototype, "attachEvent", {configurable: true, value : function attachEvent(a, b)
    {
      if(a.toLowerCase() == 'onpropertychange')
      {
        if(window.WebKitMutationObserver)
        {
          this.observer = new WebKitMutationObserver(function (mutations) { mutations.forEach(b); });
          return this.observer.observe(this, { attributes: true, subtree: false });
        }
        else
          a = 'onDOMAttrModified';
      }
      return this.addEventListener(a.slice(2), b, false);
    }});
    Object.defineProperty(Node.prototype, "detachEvent", {configurable: true, value : function detachEvent(a, b)
    {
      if(a.toLowerCase() == 'onpropertychange')
      {
        if(window.WebKitMutationObserver)
          return this.observer.disconnect();
        else
          a = 'onDOMAttrModified';
      }
      return this.removeEventListener(a.slice(2), b, false); 
    }});
    Object.defineProperty(Node.prototype, "innerText", {configurable : true, get : function get() { return this.textContent; }, set : function set(text) { this.textContent = text; }});
    Object.defineProperty(Node.prototype, "currentStyle", {configurable : true, get : function get() { return document.defaultView.getComputedStyle(this,""); }});
    Object.defineProperty(Node.prototype, "uniqueID", {configurable : true, get : function get() { return 'x'+Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15); }});
    Object.defineProperty(Node.prototype, "insertAdjacentElement", {configurable: true, value : function insertAdjacentElement(verb, obj)
    {
      switch(verb)
      {
        case 'beforeBegin':
          return this.parentNode.insertBefore(obj, this);
          break;
        case 'afterBegin':
          return this.insertBefore(obj, this.firstElementChild);
          break;
        case 'beforeEnd':
            if ( this.lastElementChild )
              return this.insertBefore(obj, this.lastElementChild.nextElementSibling);
			else
			  return this.appendChild(obj);
          break;
        case 'afterEnd':
          return this.parentNode.insertBefore(obj, this.nextElementSibling);
          break;
      }
    }});
	Object.defineProperty(Node.prototype, "removeNode", {configurable : true, value : function removeNode( cascade )
	{
		var self = this;
		if ( cascade )
			return this.parentNode.removeChild(self);
		else
		{
			var range = document.createRange();
			range.selectNodeContents(self);
			return this.parentNode.replaceChild(range.extractContents(), self);
		}
	}});
    HTMLDivElement.prototype.getAttributeNative = HTMLDivElement.prototype.getAttribute;
    HTMLDivElement.prototype.getAttribute = function(attr)
    {
      var value = this.getAttributeNative(attr);
      var attrType = this.getAttributeNative('typeof'+attr);
      switch(attrType)
      {
        case 'object':
          value = JSON.parse(value);
          break;
        case 'array':
          value = value.split(String.fromCharCode(9));
          break;
        case 'boolean':
          value = eval(value);
          break;
      }
      return value;
    };
    HTMLDivElement.prototype.setAttributeNative = HTMLDivElement.prototype.setAttribute;
    HTMLDivElement.prototype.setAttribute = function(attr,value)
    {
      var attrType = typeof(value);
      if(attrType == 'object')
        value = JSON.stringify(value);
      else if(attrType == 'array')
        value = value.join(String.fromCharCode(9));
      this.setAttributeNative('typeof'+attr,attrType);
      this.setAttributeNative(attr,value);
    };
	HTMLDivElement.prototype.select = function()
	{
		var range = document.createRange();
		range.selectNodeContents(this);
		var selection = window.getSelection();
		selection.removeAllRanges();
		selection.addRange(range);
	};
  }
  else if(window.Element)
  {
    if(document.documentElement.firstElementChild === undefined)
    {
      Object.defineProperty(Element.prototype, "firstElementChild", {configurable : true, get: function get() { return this.firstChild; } });
      Object.defineProperty(Element.prototype, "lastElementChild", {configurable : true, get: function get() { return this.lastChild; } });
      Object.defineProperty(Element.prototype, "nextElementSibling", {configurable : true, get: function get() { return this.nextSibling; } });
      Object.defineProperty(Element.prototype, "previousElementSibling", {configurable : true, get: function get() { return this.previousSibling; } });
      Object.defineProperty(Element.prototype, "getAttribute", {configurable : true, value: function get(attr,flag) 
      {
        var value = this[attr];
        var attrType = this['typeof'+attr];
        switch(attrType)
        {
          case 'object':
            value = JSON.parse(value);
            break;
          case 'array':
            value = value.split(String.fromCharCode(9));
            break;
          case 'boolean':
            value = eval(value);
            break;
        }
        return value;
      } });
      Object.defineProperty(Element.prototype, "setAttribute", {configurable : true, value: function set(attr,value,flag)
      {
        var attrType = typeof(value);
        if(attrType == 'object')
          value = JSON.stringify(value);
        else if(attrType == 'array')
          value = value.join(String.fromCharCode(9));
        this['typeof'+attr] = attrType;
        this[attr] = value;
      } });
    }
    else
    {
      Element.prototype.getAttributeNative = Element.prototype.getAttribute;
      Element.prototype.getAttribute = function(attr)
      {
        var value = this.getAttributeNative(attr);
        var attrType = this.getAttributeNative('typeof'+attr);
        switch(attrType)
        {
          case 'object':
            value = JSON.parse(value);
            break;
          case 'array':
            value = value.split(String.fromCharCode(9));
            break;
          case 'boolean':
            value = eval(value);
            break;
        }
        return value;
      };
      Element.prototype.setAttributeNative = Element.prototype.setAttribute;
      Element.prototype.setAttribute = function(attr,value)
      {
        var attrType = typeof(value);
        if(attrType == 'object')
          value = JSON.stringify(value);
        else if(attrType == 'array')
          value = value.join(String.fromCharCode(9));
        this.setAttributeNative('typeof'+attr,attrType);
        this.setAttributeNative(attr,value);
      };
    }
  }
}
if(!window.browserAlreadyExtended)
{
  window.browserAlreadyExtended = true;
  extendBrowserFeatures();
}