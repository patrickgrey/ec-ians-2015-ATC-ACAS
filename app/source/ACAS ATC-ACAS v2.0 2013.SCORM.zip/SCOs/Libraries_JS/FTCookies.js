function FTCookie(params)
{
  this.validCookie = true;

  //Value is required
  if(typeof(params.Value) != 'undefined')
  {
    if(!this.SetValue(params.Value))
    {
      this.validCookie = false;
      return;
    }
  }
  else
  {
    alert('You must provide a "Value" to create an FTCookie\n\nExample:\n\nparent.SetFTCookie({Name:"myCookie",Value:"myValue"})');
    this.validCookie = false;
    return;
  }

  //Expiry is optional
  if(typeof(params.Expiry) != 'undefined')
  {
    if(!this.SetExpiry(params.Expiry))
    {
      this.validCookie = false;
      return;
    }
  }

  //Reset value is optional
  if(typeof(params.ResetValue) != 'undefined')
  {
    if(!this.SetResetValue(params.ResetValue))
    {
      this.validCookie = false;
      return;
    }
  }
}
FTCookie.prototype.GetValue = function()
{
  return this.Value;
}
FTCookie.prototype.SetValue = function(value)
{
  if(!this.validValue(value,"Value"))
    return false;
  this.Value = value;
  this.ValueType = typeof(this.Value);
  return true;
}
FTCookie.prototype.SetResetValue = function(value)
{
  if(!this.validValue(value,"ResetValue"))
    return false;
  this.ResetValue = value;
  this.ResetValueType = typeof(this.ResetValue);
  return true;
}
FTCookie.prototype.SetExpiry = function(value)
{
  if(value == 'never' || value.isValidDate())
    this.Expiry = value;
  else
  {
    alert('Invalid Expiry. Possible values are:\n\nnever (never expire)\nYYYY-MM-DD (expiry on this date)');
    return false;
  }
  return true;
}
FTCookie.prototype.validValue = function(value,field)
{
  var valueType = typeof(value);
  if(valueType != 'string' && valueType != 'number' && valueType != 'boolean')
  {
    alert('Cookie "'+field+'" must be string, number or boolean');
    return false;
  }
  if(valueType == 'string' && value.length > 255)
  {
    alert('Cookie "'+field+'" cannot be more than 255 characters');
    return false;
  }
  return true;
}
function SetFTCookie(params)
{
  if(params.Name)
  {
    if(FTCookies[params.Name]) //cookie already exists
    {
      if(typeof(params.Value) != 'undefined')
        FTCookies[params.Name].SetValue(params.Value);
      if(typeof(params.ResetValue) != 'undefined')
        FTCookies[params.Name].SetResetValue(params.ResetValue);
      if(typeof(params.Expiry) != 'undefined')
        FTCookies[params.Name].SetExpiry(params.Expiry);
    }
    else //new cookie
    {
      if(params.Name.length > 255)
      {
        alert('Cookie "Name" cannot be more than 255 characters');
        alert('Cookie "' + params.Name + '" was not created');
        return;
      }
      var newCookie = new FTCookie(params);
      if(newCookie.validCookie)
        FTCookies[params.Name] = newCookie;
      else
        alert('Cookie "' + params.Name + '" was not created');
    }
  }
  else
    alert('You must provide a "Name" to create/update an FTCookie\n\nExample:\n\nparent.SetFTCookie({Name:"myCookie",Value:"myValue"})');
}
function GetFTCookie(name,debugMode)
{
  if(FTCookies[name])
    return FTCookies[name].GetValue();
  else
  {
    if(debugMode)
      CookieNotFound(name,'GetFTCookie');
    return null;
  }
}
function DeleteFTCookie(name,debugMode)
{
  if(FTCookies[name])
  {
    delete FTCookies[name];
    return true;
  }
  else
  {
    if(debugMode)
      CookieNotFound(name,'DeleteFTCookie');
    return false;
  }
}
function CookieNotFound(name,method)
{
  alert('The cookie "' + name + '" could not be found (' + method + ')');
}
