var offline = location.href.indexOf('NewLinx') == -1 ? (location.href.indexOf('SCOs') == -1 ? 'SCOs/DOCs/' : 'DOCs/') : false; 
function ObjectActions( actions ) // at course player level
{
	// event and action data - also supports mouseout, but that is only populated via automation to undo mouseover actions such as show tooltip
	this.actions = {}; // object_num : {trigger_key : {click : [{ action_type, action_params }], mouseover : [...]}} - populated by the page level player
	
	if ( actions )
		this.add_actions( actions );
};

// tooltip
ObjectActions.coords = [0,0];
ObjectActions.create_tooltip = function(id)
{
	var tooltip = Content.document.createElement('SPAN');
	tooltip.id = id;
	tooltip.style.position = "absolute";
	tooltip.style.left = tooltip.style.top = 0;
	tooltip.style.backgroundColor = "#FFFFE1";
	tooltip.style.border = "1px solid black";
	tooltip.style.zIndex = 100000;
	tooltip.style.padding = "3px";
	tooltip.style.fontFamily = "arial";
	tooltip.style.fontSize = "8pt";
	tooltip.style.visibility = "hidden";
	Content.document.body.appendChild( tooltip );
};
ObjectActions.set_tooltip = function( tooltip, html )
{
	tooltip.innerHTML = html;
	
	var x = ObjectActions.coords[0];
	var y = ObjectActions.coords[1];
	
	// x
	var right = document.body.clientWidth - x;
	var left = x;
	if ( tooltip.clientWidth < right )
		tooltip.style.left = x + 10 + "px";
	else if ( tooltip.clientWidth < left )
		tooltip.style.left = x - tooltip.clientWidth - 10 + "px";
	else
	{
		if ( right > left )
		{
			tooltip.style.width = right - 20 + "px";
			tooltip.style.left  = x + 10 + "px";
		}
		else
		{
			tooltip.style.width = left - 20 + "px";
			tooltip.style.left  = x - tooltip.clientWidth - 10 + "px";
		}
	}
	
	// y
	var bottom = document.body.clientHeight - y;
	var top = y;
	if ( tooltip.clientHeight < bottom )
		tooltip.style.top = y + 10 + "px";
	else if ( tooltip.clientHeight < top )
		tooltip.style.top = y - tooltip.clientHeight - 10 + "px";
	else
	{
		if ( bottom > top )
		{
			tooltip.style.height = bottom - 10 + "px";
			tooltip.style.top   = y + 10 + "px";
		}
		else
		{
			tooltip.style.height = top - 10 + "px";
			tooltip.style.top  = y - tooltip.clientHeight - 10 + "px";
		}
	}
	
	tooltip.style.visibility = "visible";
};

// class methods
ObjectActions.prototype.add = function( object_number, trigger_key, event_type, action_type, params )
{
	if ( !this.actions[object_number] )
		this.actions[object_number] = {};
	if ( !this.actions[object_number][trigger_key] )
		this.actions[object_number][trigger_key] = {};
	if ( !this.actions[object_number][trigger_key][event_type] )
		this.actions[object_number][trigger_key][event_type] = [];
	if ( typeof params == "string" ) // if the action type is one that requires an array for a param, make the conversion it is passed as a string
	{
		if ( params.charAt(0) != "[" && params.charAt(0) != "{" && params.charAt(0) != '"' )
			params = '"' + params.replace(/"/g, '\\"') + '"';
		params = eval(params.replace(/\r\n/g, '\\r\\n'));
	}
	this.actions[object_number][trigger_key][event_type].push({"action_type" : action_type, action_params : params});
	if ( event_type == "mouseover" && action_type == "show_tooltip" ) // adding hide tooltip when show tooltip is added
	{
		if ( !this.actions[object_number][trigger_key].mouseout )
			this.actions[object_number][trigger_key].mouseout = [];
		this.actions[object_number][trigger_key].mouseout[ this.actions[object_number][trigger_key][event_type].length - 1 ] = {"action_type" : "hide_tooltip", action_params : params};
	}
};
// actions is an indexed array of keyed arrays matching the ObjectActions::add param list
ObjectActions.prototype.add_actions = function( actions )
{
	var num_actions = actions.length;
	for ( var i = 0; i < num_actions; i++ )
		this.add(actions[i].object_number, actions[i].trigger_key, actions[i].event_type, actions[i].action_type, actions[i].params);
};
ObjectActions.prototype.apply_global_events = function() // adds event listeners to the main object divs where appropriate
{
	var objects = Content.document.body.children;
	var num_objects = objects.length;
	for ( var i = 0; i < num_objects; i++ )
	{
		var object = objects[i];
		
		// skip all non-object nodes
		if ( object.tagName != "DIV" || !object.getAttribute("object_number") )
			continue;
		
		var object_number = object.getAttribute("object_number");
		var object_actions = this;
		if ( this.actions[object_number] && this.actions[object_number].global )
		{
			if ( this.actions[object_number].global.click )
			{
				object.style.cursor = 'pointer';
				if ( object.addEventListener )
					object.addEventListener("click", function(event){object_actions.click(event, this.getAttribute("object_number"), "global");}.bind(object));
				else
					object.attachEvent("onclick", function(event){object_actions.click(event, this.getAttribute("object_number"), "global");}.bind(object), false);
			}
			if ( this.actions[object_number].global.mouseout )
			{
				if ( object.addEventListener )
					object.addEventListener("mouseout", function(event){object_actions.mouseout(event, this.getAttribute("object_number"), "global");}.bind(object));
				else
					object.attachEvent("onmouseout", function(event){object_actions.mouseout(event, this.getAttribute("object_number"), "global");}.bind(object), false);
			}
			if ( this.actions[object_number].global.mouseover )
			{
				if ( object.addEventListener )
					object.addEventListener("mouseover", function(event){object_actions.mouseover(event, this.getAttribute("object_number"), "global");}.bind(object));
				else
					object.attachEvent("onmouseover", function(event){object_actions.mouseover(event, this.getAttribute("object_number"), "global");}.bind(object), false);
			}
		}
	}
};
ObjectActions.prototype.get = function( object_number, trigger_key, event_type )
{
	if ( !trigger_key )
		return this.actions[object_number] || [];
	else if ( !event_type )
		return this.actions[object_number] ? this.actions[object_number][trigger_key] || [] : [];
	else
		return this.actions[object_number] && this.actions[object_number][trigger_key] ? this.actions[object_number][trigger_key][event_type] || [] : [];
}
ObjectActions.prototype.get_serialized_actions = function(pageID)
{
	// object_num : {trigger_key : {click : [{ action_type, action_params }], mouseover : [...]}}
	var string = "";
	for ( object_num in this.actions )
	{
		for ( trigger_key in this.actions[object_num] )
		{
			var trigger_key_actions = this.actions[object_num][trigger_key];
			for ( event_type in trigger_key_actions )
			{
				var actions = trigger_key_actions[event_type];
				var num_actions = actions.length;
				for ( var i = 0; i < num_actions; i++ )
				{
					var action_params = actions[i].action_params;
					var action_string = "";
					if ( typeof action_params != "string" )
					{
						action_string = "[";
						for ( var j = 0; j < action_params.length; j++ )
							action_string += (j != 0 ? "," : "") + (typeof action_params[j] == "string" ? '"' : "") + action_params[j].replace(/"/g,'\\"') + (typeof action_params[j] == "string" ? '"' : "");
						action_string += "]";
						action_params = action_string;
					}
					else // quoting and escaping for database storage
						action_params = '"' + action_params.replace(/"/g,'\\"') + '"';
					string += "&page_id[]=" + pageID + "&object_number[]=" + object_num + "&trigger_key[]=" + trigger_key + "&event_type[]=" + event_type + "&action_type[]=" + actions[i].action_type + "&action_params[]=" + encodeURIComponent(action_params);
				}
			}
		}
	}
	return string;
};
ObjectActions.prototype.click = function( event, object_number, trigger_key ) { this.process(event, object_number, trigger_key, "click"); };
ObjectActions.prototype.get_credentials_params = function() { return "UserID=" + encodeURIComponent(Content.document.forms.Main.UserID.value) + "&SessionKey=" + Content.document.forms.Main.SessionKey.value; };
ObjectActions.prototype.mouseout = function( event, object_number, trigger_key ) { this.process(event, object_number, trigger_key, "mouseout"); };
ObjectActions.prototype.mouseover = function( event, object_number, trigger_key ) { this.process(event, object_number, trigger_key, "mouseover"); };
ObjectActions.prototype.process = function( event, object_number, trigger_key, event_type )
{
	if ( !event_type ) // if the param list is actually just object_number, event_type
	{
		event_type = trigger_key;
		trigger_key = "global";
	}
	
	if ( event.pageX )
		ObjectActions.coords = [event.pageX, event.pageY];
	else if ( event.clientX )
		ObjectActions.coords = [event.clientX, event.clientY];
	
	// do not attempt to process non-existent actions
	if ( !this.actions[object_number] || !this.actions[object_number][trigger_key] )
		return;
	
	var actions = this.actions[object_number][trigger_key][event_type] || [];
	var num_actions = actions.length;
	for ( var i = 0; i < num_actions; i++ )
		this[actions[i].action_type]( actions[i].action_params );
};
ObjectActions.prototype.remove = function( object_number, trigger_key, event_type, event_index )
{
	if ( !event_index )
		event_index = 0;
	
	if ( event_index )
	{
		try
		{
			delete this.actions[object_number][trigger_key][event_type][event_index];
		}
		catch(e) { return false; }
	}
	else if ( event_type )
	{
		try { delete this.actions[object_number][trigger_key][event_type]; }
		catch(e) { return false; }
	}
	else if ( trigger_key )
	{
		try { delete this.actions[object_number][trigger_key]; }
		catch(e) { return false; }
	}
	else if ( object_number )
	{
		try { delete this.actions[object_number]; }
		catch(e) { return false; }
	}
	
	if ( event_type == "mouseover" && this.actions[object_number][trigger_key].mouseout[event_index] )
		delete this.actions[object_number][trigger_key].mouseout[event_index];
	
	// removing empty data arrays
	if ( event_type && this.actions[object_number][trigger_key][event_type] != null && !this.actions[object_number][trigger_key][event_type].length )
	{
		delete this.actions[object_number][trigger_key][event_type];
		if ( event_type == "mouseover" && this.actions[object_number][trigger_key].mouseover ) // removing hide tooltip if add tooltip has been removed
			delete this.actions[object_number][trigger_key].mouseover;
	}
	if ( trigger_key && this.actions[object_number][trigger_key] != null && !this.actions[object_number][trigger_key].length )
		delete this.actions[object_number][trigger_key];
	if ( object_number && this.actions[object_number] != null && !this.actions[object_number].length )
		delete this.actions[object_number];
};
ObjectActions.prototype.set_data_source = function( data_source ) { this.actions = data_source; };

// action methods
ObjectActions.prototype.hide_tooltip = function( params ) // tooltip object id
{
	var id = params[0];
	
	if ( !Content.document.getElementById(id) )
		id = "object_actions_tooltip";
	
	if ( !Content.document.getElementById(id) )
		return;
	
	Content.document.getElementById(id).style.visibility = "hidden";
	Content.document.getElementById(id).innerHTML = "";
};
ObjectActions.prototype.open_course = function ( params ) // 0: course id, 1: title
{
	windowOpenPOST
	(
		window,
		"RunCourse.php?CourseID=" + params[0] + "&CourseVersion=1&" + this.get_credentials_params(),
		"",
		"width=790,height=544,top=0,left=0,scrollbars=yes"
	);
};
ObjectActions.prototype.open_page = function ( params ) { PageLink.show( params[0] ); }; // 0: page id, 1: title
ObjectActions.prototype.cluster_link = function ( params ) { Functions.RedirectLocation(params[0], null, null, params[2]); }; //0: cluster id, 2: doc number
ObjectActions.prototype.view_page = function ( params ) { Content.ViewPage(params[0],params[2],params[3],params[4],params[5],params[6],offline) }; // 0: page id, 2: x, 3: y, 4: w, 5: h, 6: title
ObjectActions.prototype.open_url = function( params ) { if(offline && params.substr(0,11) == 'ObjectFiles') params = offline+params; window.open( params, "_blank", "top=0" ); }; // url
ObjectActions.prototype.show_graphic = function( params ) { (top.windowOpenPOST ? top : opener.top ).windowOpenPOST(window, 'SlidePage.php?UserID=' + encodeURIComponent(Content.document.forms.Main.UserID.value) + '&Source=../ObjectFiles/'+encodeURIComponent(params[2])+'&Alternate='+encodeURIComponent(params[3]), '', 'width=100,height=100,top=0,left=0resizable=yes'); }; // 0: object id, 1: title, 2: file name, 3: graphic text
ObjectActions.prototype.play_sound = function( params ) // 0: object id, 1: title, 2: file name, 3: audio text
{
	if ( Content.UserHearingImpaired )
	{
		if ( modal && modal.alert )
			modal.alert(params[3]);
		else
			alert(params[3]);
		return;
	}
	
	Media_Player.play( params[2], document.getElementById("smilAudio"), true, null, null, true );
};
ObjectActions.prototype.run_command = function ( params )
{
	// ensuring the runtime supports course functions; doc level preview, for example, does not
	if ( !Functions || !Functions[params] )
		return;
	
	Functions[params]();
}; // system command
ObjectActions.prototype.run_script = function( params ) { try { eval(params); } catch(e) {} }; // JavaScript
ObjectActions.prototype.show_tooltip = function( params ) // 0 : tooltip object id, 1 : text
{
	var id = params[0];
	var html = params[1];
	
	if ( !Content.document.getElementById(id) )
		ObjectActions.create_tooltip(id);
	if ( tooltip = Content.document.getElementById(id) )
		ObjectActions.set_tooltip(tooltip,html);
};
ObjectActions.prototype.show_term = function( params ) // 0 : glossary object id, 1 : title
{ top.windowOpenPOST(window, "ShowGlossary.php?ObjLanguage=&ObjectID=" + params[0] + "&" + this.get_credentials_params(),"","left=100,top=200,width=600,height=300,resizable=yes,scrollbars=yes"); }