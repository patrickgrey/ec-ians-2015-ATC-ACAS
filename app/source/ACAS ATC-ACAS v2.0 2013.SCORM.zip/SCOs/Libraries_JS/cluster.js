// params : cluster_id, children, parent, metadata
Cluster = function( params )
{
	this.id = params.cluster_id;
	this.level = params.level;
	this.parent = params.parent;
	this.metadata = params.metadata || {};
	this.children = [];
	
	this.add_child = function( params ) { this.children.push( new Cluster( params ) ); }
	this.get_metadata = function( key, index ) { return !index ? this.metadata[ key ] : this.metadata[key][index]; }
	
	if ( this.level === 0 )
		Cluster.sco_object_pointers.push( this );
	
	if ( params.children !== null )
	{
		for ( var i = 0; i < params.children.length; i++ )
		{
			params.children[i].parent = this; // adding this as the parent param of the child
			this.add_child( params.children[i] );
		}
	}
}
Cluster.sco_object_pointers = [];
Cluster.levels = {}; // array of cluster levels keyed off the english language name
Cluster.get_level_from_string = function( level_string ) { return Cluster.levels[ level_string ] !== null ? Cluster.levels[ level_string ] : false; }
Cluster.get_curr_element_metadata = function( target_level, key, index ) // can only be used within RunCourse.php
{
	// converting target_level to a number if necessary
	if ( typeof( target_level ) == "string" )
		target_level = Cluster.get_level_from_string( target_level );
	
	// locating the current sco object
	var current_sco_index = Number(Content.document.forms.Main.elements.ClusterNumber.value) - 1;
	if ( !Cluster.sco_object_pointers[ current_sco_index ] )
		return;
	
	// finding the target object
	var curr_element = Cluster.sco_object_pointers[ current_sco_index ];
	for ( var i = 0; i < target_level; i++ )
	{
		if ( curr_element.parent )
			curr_element = curr_element.parent;
		else // if the target doesn't exist in the cluster object data tree
			return false;
	}
	
	return curr_element.get_metadata( key, index );
}