/********************
DESCRIPTION
This object is designed to retrieve data from the server dynamically without the use of frames.

REQUIREMENTS
function_extensions.js

DIRECTIONS
New up an AJAX object with the required path and processor parameters described below. 
The function designated as the processor will be run when the data has completed loading,
and is passed the ajax object. You can then access the properties described below.  With
synchronous communication (the default), it is possible to simply access the .text and .xml
data without having to use a processor function as the rest of the script will wait until
the AJAX operations have completed.

Remember, when parsing XML, text inside an element is considered a node and you return the text
inside the text node by referring to the nodeValue property.
For example <menu>item 1</menu> is referred to by
[xml].getElementsByTagName("menu").childNodes[0].nodeValue.

Also note that when Firefox returns each chunk of white space as a text node.
For example:
<menu>
	item 1
</menu>
is obtained via [xml].getElementsByTagName("menu").childNodes[1].nodeValue in Firefox
whereas <menu>item 1</menu>
is obtained via [xml].getElementsByTagName("menu").childNodes[0].nodeValue in Firefox
IE ignores white space and always uses childNodes[0] for the internal text node.

PARAMETERS
path			the path to the file that will return the data (e.g. a php or xml file)
processor		OPTIONAL - a pointer to a function that will process the data when it is loaded
				This is required for asynchronous communication
script			OPTIONAL - if you want the object to store the result of a function on
				the page specified in the path instead of processing the entire page,
				you may specify a string that represents the function call and parameters
				NOTE: when the function is to return an xml value, you must set the
				return_type parameter to xml
asynchronous	OPTIONAL - [false | true] if you want asynchronous communication, pass a boolean false
				Processor becomes a required param when asynchronous communication is set to true
base path		OPTIONAL - This is the default path to get to the API_processor.php file. This will need
				to be altered if calling from a place other than the same directory as the calling page.
method			OPTIONAL - [get | post]
form			OPTIONAL - a form object to be submitted to the path or the action of the form if no path is specified
form id			OPTIONAL - same as form, except you pass the id of the form instead of the object
data			OPTIONAL - a string of data to be submitted to the path
				FORMAT: var1Name=data1&var2Name=data2&...
return type		OPTIONAL - when calling a function that returns xml data, this value must be set to xml

PROPERTIES
xml				the data store for any xml data returned - this can be parsed using built-in methods
				like .childNodes and .nodeValue (to retrieve data in a given element)
text			the data store for any text data returned
trigger			a pointer to the object that newed up the AJAX object

EXAMPLE - SYNCHRONOUS COMMUNICATION
function body_onload()
{
	var ajax = new AJAX({ path: "myData.php?Record=13" });
	alert( ajax.text ); // displays any returned text
	alert( ajax.xml ); // displays [object] if there is any xml returned as this is actually an xml object
	alert( ajax.trigger ); // this will return null as it was called by the onload of the body in this example
}

EXAMPLE - ASYNCHRONOUS COMMUNICATION
function body_onload()
{
	new AJAX({ path: "myData.php?Record=13", processor: processData });
}
function processData( ajax )
{
	alert( ajax.text ); // displays any returned text
	alert( ajax.xml ); // displays [object] if there is any xml returned as this is actually an xml object
	alert( ajax.trigger ); // this will return null as it was called by the onload of the body in this example
}

EXAMPLE - CALLING DATA VIA A USER DRIVEN EVENT
function processData( ajax )
{
	// inserts a space separated list of the text in each item tag within the first menu tag
	var div = document.getElementById( ajax.trigger.value );
	var items = ajax.xml.getElementsByTagName("menu")[0].getElementsByTagName("item");
	for ( var i = 0; i < items.length; i++ )
		div.innerHTML += items[i].childNodes[0].nodeValue + " ";
}
<div id="div1"></div>
<div id="div2"></div>
<select id="mySelect" onchange="new AJAX({ path: 'myData.php', processor: processData });">
	<option value="" selected>select an option</option>
	<option value="div1">option 1</option>
	<option value="div2">option 2</option>
</select>

function processData( ajax )
{
	// inserts a space separated list of the text in each item tag within the first menu tag
	// displays 1 if option 1 was selected and 2 if option 2 was selected
	alert( ajax.xml.getElementsByTagName("data")[0].childNodes[0] );
}
<select id="mySelect" onchange="if ( this.value != '' ) new AJAX({ path: 'myData.php?display='+this.value, processor: processData });">
	<option value="" selected>select an option</option>
	<option value="1">option 1</option>
	<option value="2">option 2</option>
</select>

function processData( ajax )
{
	// inserts a space separated list of the text in each item tag within the first menu tag
	// displays 1 if option 1 was selected and 2 if option 2 was selected
	alert( ajax.text );
}
<select id="mySelect" onchange="if ( this.value != '' ) new AJAX({ path: 'myData.php?display='+this.value, processor: processData });">
	<option value="" selected>select an option</option>
	<option value="1">option 1</option>
	<option value="2">option 2</option>
</select>

EXAMPLE - PROCESSING A FUNCTION INSTEAD OF A PAGE
// instead of returning the result of the whole myAPIs.php page, it instead runs the getID function in myAPIs.php with a parameter
// of kevin, and returns the results of the function call (i.e. ajax.xml and ajax.text will be based on the return value of the function
// instead of what's on the myAPIs.php page)
new AJAX({ path: "myAPIs.php", processor: myProcessorFunction, script: "getID('kevin')" });

EXAMPLE - POSTING A FORM
new AJAX({ "form id" : "myForm" }); // all other settings are handled automatically and the form action is used as the path
********************/

function AJAX( params )
{
	if ( params.script )
		this.script = encodeURIComponent( params.script );
	this.basePath = params["base path"] ? params["base path"] : "../Libraries_JS/";
	this.path = params.path;
	this.processor = params.processor;
	this.method = params.method ? params.method : "post";
	this.data = params.data ? params.data : "";
	this.asynchronous = params.asynchronous ? params.asynchronous : false;
	if ( params["return type"] )
		params.return_type = params["return type"];
	this.returnType = params.return_type || "";
	this.form = params.form;
	if ( params["form id"] )
		this.form = document.getElementById( params["form id"] );
	if ( params["form_id"] )
		this.form = document.getElementById( params["form_id"] );
	this.eventObj = params['e'] ? params['e'].target : window.event ? window.event.srcElement : null;
	if ( this.form )
	{
		this.method = "post";
		this.serializeForm(); // converts the form element data to this.data
		if ( !this.path )
			this.path = this.form.action;
	}
	if ( this.data )
		this.method = "post";
	
	this.text = null;
	this.xml = null;
	this.json = {};
	
	// if the AJAX obj is to process a script in the path file instead of running the path itself...
	if ( this.script )
	{
		// ensuring the script has a trailing ;
		if ( this.script.charAt(this.script.length - 1) != ";" )
			this.script += ";";
		this.path = this.basePath + "API_processor.php?API_URL=" + escape(this.path) + "&Script=" + this.script + ( this.returnType == "xml" ? "&ReturnType=xml" : "" );
	}
	
	var e = null;
	this.trigger = null;
	if ( typeof event != "undefined" ) // IE
		e = event;
	else if ( typeof params.e != "undefined" ) // Firefox
		e = params.e;
	if ( e && typeof e.target != "undefined" ) // Firefox
		this.trigger = e.target;
	else if ( e && e.srcElement ) // IE
		this.trigger = e.srcElement;
	
	this.obj = this.getObj();
	this.startProcess();
}
AJAX.prototype.iframe_process_complete = function()
{
	this.text = window.frames[ this.iframe_name ].document.body.innerHTML;
	try { eval("this.json = " + window.frames[ this.iframe_name ].document.body.innerHTML) } catch(e){ this.json = {error:this.text}; };
	
	this.iframe.removeNode(true);
	
	if ( this.processor )
		this.processor( !this.returnType ? this : this[this.returnType] );
}
AJAX.prototype.startProcess = function()
{
	if ( this.obj )
	{
		// if the call is asynchronous, the data will not be processed until it is ready
		if ( this.asynchronous )
			this.obj.onreadystatechange = this.processData.bind(this);
		
		// try is used to catch cross domain calls
		try { this.obj.open( this.method, this.path, this.asynchronous ); }
		catch (e) { return; }
		
		if ( this.method == "post" )
		{
			this.obj.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			if ( this.data.length == 0 )
				this.convertGetToPost();
		}
		this.obj.send( this.data );
		
		// if the call is synchronous, the data will be processed now
		// this is required due to Firefox's inability to process the readystate in a synchronous transaction
		if ( !this.asynchronous )
		{
			this.xml = this.obj.responseXML;
			this.text = this.obj.responseText;
			try { eval("this.json = " + this.obj.responseText) } catch(e){ this.json = {error:this.text}; };
			
			if ( this.processor )
				this.processor( !this.returnType ? this : this[this.returnType] );
		}
	}
}
AJAX.prototype.getObj = function()
{
	var obj = null;
	
	// find native XMLHttpRequest object
	if ( window.XMLHttpRequest )
	{
		try { obj = new XMLHttpRequest(); }
		catch (e) { obj = null; }
	}
	else if ( window.ActiveXObject )
	{
		try { obj = new ActiveXObject("Msxml2.XMLHTTP"); }
		catch (e)
		{
			try { obj = new ActiveXObject("Microsoft.XMLHTTP"); }
			catch (e) { obj = null; }
		}
	}
	
	return obj;
}
AJAX.prototype.processData = function()
{
	if ( this.obj.readyState == 4 ) // the object is finished loading
	{
		if ( this.obj.status == 200 ) // the object is valid
		{
			this.xml = this.obj.responseXML;
			this.text = this.obj.responseText;
			try { eval("this.json = " + this.obj.responseText) } catch(e){ this.json = {error:this.text}; };
			
			if ( this.processor )
				this.processor( !this.returnType ? this : this[this.returnType] );
		}
		else if ( this.obj.status == 403 ) // session failure
			alert( "Your session has been terminated" );
		else
			alert( "There was a problem retrieving the XML data:\n" + this.obj.statusText );
	}
}
AJAX.prototype.serializeForm = function()
{
	var temp_data = new Array();
	
	for ( var i = 0; i < this.form.elements.length; i++ )
	{
		if ( this.form.elements[i].type == 'radio' )
		{
			if ( this.form.elements[i].checked )
				temp_data.push( this.form.elements[i].name + "=" + encodeURIComponent(this.form.elements[i].value) );
			continue;
		}
		if ( this.form.elements[i].type == "checkbox" && !this.form.elements[i].checked )
			temp_data.push( this.form.elements[i].name + "=0" );
		else if ( this.form.elements[i].type == "select-multiple" )
		{
			for ( j = 0; j < this.form.elements[i].options.length; j++ )
			{
				if ( this.form.elements[i].options[j].selected )
					temp_data.push( this.form.elements[i].name + "=" + encodeURIComponent(this.form.elements[i].options[j].value) );
			}
		}
		else if ( this.form.elements[i].type == "button" && this.form.elements[i].name == 'SubmitBtn')
		{
			if(this.form.elements[i] == this.eventObj)
				temp_data.push( "ButtonVal=" + encodeURIComponent(this.form.elements[i].value) );
		}
		else
			temp_data.push( this.form.elements[i].name + "=" + encodeURIComponent(this.form.elements[i].value) );
	}
	
	this.data = temp_data.join("&");
}
AJAX.prototype.convertGetToPost = function()
{
	var temp = this.path.split('?');
	if(temp.length > 1)
		this.data = temp[1];
}