var DaysInMonthArray = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
String.prototype.isValidDate = function()
{
  Parts = this.split("-");

  if(this.substr(4,1) != '-' || this.substr(7,1) != '-' || Parts.length != 3)
    return false;

  yyyy = Parts[0];
  mm   = Parts[1];
  dd   = Parts[2];

  if(yyyy != parseInt(yyyy,10) || yyyy.length != 4)
    return false;
  
  if(mm.length != 2 || mm != parseInt(mm,10) || mm < 1 || mm > 12)
    return false;
 
  DaysInMonth = DaysInMonthArray[mm-1];
  if(mm == 2)
    if(!(yyyy % 4) && (yyyy % 100) || !(yyyy % 400))
      DaysInMonth++;

  if(dd.length != 2 || dd != parseInt(dd,10) || dd < 1 || dd > DaysInMonth)
    return false;

  return true;
}