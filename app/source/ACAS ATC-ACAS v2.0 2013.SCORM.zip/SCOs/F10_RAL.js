/********************
ForceTen Runtime Abstraction Layer

DESCRIPTION
Used to turn standard content event calls into the following standards:
SCORM 2004
SCORM 1.2

F10_RAL_Commit()
Run when you wish to commit LO level variables to the database

F10_RAL_EnterLO()
Run when a learning object is entered

F10_RAL_ExitLO()
Run when a learning object is exited

F10_RAL_GetAPI( p_sAPI )
Returns the API found in the local or parent frames or in the opener window or its parent frames
p_sAPI              The API type for which you wish to search

F10_RAL_GetDiagnostic( p_nErrorNum )

F10_RAL_GetErrorString( p_nErrorNum )

F10_RAL_GetValue( p_sVar )
Run when retrieving an LO level variable

F10_RAL_SetValue( p_sVar, p_sValue )
Run when setting an LO level variable


MAPPING
SCORM 1.2
LMSCommit           F10_RAL_Commit
LMSFinish           F10_RAL_ExitLO
LMSGetDiagnostic    F10_RAL_GetDiagnostic
LMSGetErrorString   F10_RAL_GetErrorString
LMSGetLastError     F10_RAL_GetLastError
LMSGetValue         F10_RAL_GetValue
LMSInitialize       F10_RAL_EnterLO
LMSSetValue         F10_RAL_SetValue

SCORM 2004
Commit              F10_RAL_Commit
GetDiagnostic       F10_RAL_GetDiagnostic
GetErrorString      F10_RAL_GetErrorString
GetLastError        F10_RAL_GetLastError
GetValue            F10_RAL_GetValue
Initialize          F10_RAL_EnterLO
SetValue            F10_RAL_SetValue
Terminate           F10_RAL_ExitLO
********************/

// GLOBAL VARIABLES

var F10_RAL = new Array();
F10_RAL["API"] = null;              // The actual API object that was found
F10_RAL["API_Type"] = null;         // A string representing the API that was found -- i.e. SCORM 2004, SCORM 1.2
F10_RAL["API_To_Find"] = null;      // A string representing the API for which to search -- used by F10_RAL_FindAPI
F10_RAL["Content_Type"] = null;     // The API for which the content was originally designed
F10_RAL["Max_API_Depth"] = 7;       // maximum number of parents through which F10_RAL_GetAPI will search
F10_RAL["Curr_API_Depth"] = 0;      // the current depth of the API search
F10_RAL["Display_Errors"] = false;
F10_RAL["CMI"] = new Array();

// ACCESSIBLE F10 RAL FUNCTIONS

function F10_RAL_Commit()
{
    if ( !F10_RAL["API"] )
        return;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":
            return F10_RAL["API"].Commit("");
        case "SCORM 1.2":
            return F10_RAL["API"].LMSCommit("");
    }
}

function F10_RAL_EnterLO()
{
    if ( !F10_RAL["API"] )
        return;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":
            return F10_RAL["API"].Initialize("");
        case "SCORM 1.2":
            return F10_RAL["API"].LMSInitialize("");
    }
}

function F10_RAL_ExitLO()
{
    if ( !F10_RAL["API"] )
        return;
    
	if ( init_session_time )
	{
		// get SCORM 1.2 session time
		var session_time = get_scorm_time_from_milliseconds( Number( new Date() ) - init_session_time );
		
	    switch ( F10_RAL["API_Type"] )
	    {
	        case "SCORM 2004":
	            F10_RAL_SetValue( "cmi.session_time", F10_RAL_Get1_2To2004TimeInterval( session_time ) );
	            break;
	        case "SCORM 1.2":
		F10_RAL_SetValue( "cmi.core.session_time", session_time );
	            break;
	    }
	}
	
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":
            var sReturn = F10_RAL["API"].Terminate("");
            return sReturn;
        case "SCORM 1.2":
            var sReturn = F10_RAL["API"].LMSFinish("");
            return sReturn;
    }
}

function F10_RAL_GetValue( p_sElement )
{
    if ( !F10_RAL["API"] )
        return;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":      return F10_RAL_2004_GetValue( p_sElement );
        case "SCORM 1.2":       return F10_RAL_1_2_GetValue( p_sElement );
    }
}

function F10_RAL_SetValue( p_sElement, p_sValue )
{
    if ( !F10_RAL["API"] )
        return;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":      return F10_RAL_2004_SetValue( p_sElement, p_sValue );
        case "SCORM 1.2":       return F10_RAL_1_2_SetValue( p_sElement, p_sValue );
    }
}

// API LOCATOR

function F10_RAL_GetAPI( p_sAPI )
{
    var asAPIs = new Array();
    asAPIs["SCORM 2004"] = "API_1484_11";
    asAPIs["SCORM 1.2"] = "API";
    
    if ( p_sAPI )
    {
        var oAPI = F10_RAL_GetSpecificAPI( asAPIs[p_sAPI] );
        if ( oAPI )
            F10_RAL["API_Type"] = p_sAPI;
        
        return oAPI;
    }
    
    for ( sKey in asAPIs )
    {
        var oAPI = F10_RAL_GetSpecificAPI( asAPIs[sKey] );
        if ( oAPI )
        {
            F10_RAL["API_Type"] = sKey;
            return oAPI;
        }
    }
}

// ERROR HANDLERS

function F10_RAL_GetDiagnostic( p_nErrorNum )
{
    if ( !F10_RAL["API"] )
        return null;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":      return F10_RAL["API"].GetDiagnostic( p_nErrorNum );
        case "SCORM 1.2":       return F10_RAL["API"].LMSGetDiagnostic( p_nErrorNum );
    }
}

function F10_RAL_GetErrorString( p_nErrorNum )
{
    if ( !F10_RAL["API"] )
        return null;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":      return F10_RAL["API"].GetErrorString( p_nErrorNum );
        case "SCORM 1.2":       return F10_RAL["API"].LMSGetErrorString( p_nErrorNum );
    }
}

function F10_RAL_GetLastError()
{
    if ( !F10_RAL["API"] )
        return null;
    
    switch ( F10_RAL["API_Type"] )
    {
        case "SCORM 2004":      return F10_RAL["API"].GetLastError();
        case "SCORM 1.2":       return F10_RAL["API"].LMSGetLastError();
    }
}

// INTERNAL HELPER FUNCTIONS

// p_oWindow    The window in which to search
// p_sAPI       The API type to find
function F10_RAL_FindAPI( p_oWindow, p_sAPI )
{
    F10_RAL["Curr_API_Depth"] = 0;
    
    while ( p_oWindow[p_sAPI] == null && p_oWindow.parent != null && p_oWindow.parent != p_oWindow )
    {
        F10_RAL["Curr_API_Depth"]++;
        if ( F10_RAL["Curr_API_Depth"] > F10_RAL["Max_API_Depth"] )
            return null;
        p_oWindow = p_oWindow.parent;
    }
    
    return p_oWindow[p_sAPI];
}

// p_sAPI       The API type to find
function F10_RAL_GetSpecificAPI( p_sAPI )
{
    F10_RAL["API"] = F10_RAL_FindAPI( window, p_sAPI );
    if ( F10_RAL["API"] == null && window.opener != null && typeof( window.opener ) != "undefined" )
        F10_RAL["API"] = F10_RAL_FindAPI( window.opener, p_sAPI );
    if ( F10_RAL["API"] == null && window.opener != null && typeof( window.opener ) != "undefined" && window.opener.opener != null && typeof( window.opener.opener ) != "undefined" )
        F10_RAL["API"] = F10_RAL_FindAPI( window.opener.opener, p_sAPI );
    
    return F10_RAL["API"];
}


// CONVERTERS TO 1.2 (used when the LMS is using SCORM 1.2
function F10_RAL_1_2_GetCMIElement( p_sElement )
{
    p_sElement = p_sElement.replace( /learner_/g, "student_" );
    
    if ( p_sElement.indexOf("cmi.score.") != -1 )
        return "cmi.core.score." + p_sElement.slice(10);
    
    if ( p_sElement.indexOf("cmi.objectives.") != -1 )
    {
        if ( p_sElement.indexOf("completion_status") != -1 )
            return p_sElement.replace( /\.completion_status/g, ".lesson_status" );
        if ( p_sElement.indexOf("success_status") != -1 )
            return p_sElement.replace( /\.success_status/g, ".lesson_status" );
    }
    
    switch ( p_sElement )
    {
        case "cmi.credit":                              return "cmi.core.credit";
        case "cmi.comments_from_learner.0.comment":     return "cmi.comments";
        case "cmi.comments_from_lms.0.comment":         return "cmi.comments_from_lms";
        case "cmi.completion_status":
        case "cmi.success_status":                      return "cmi.core.lesson_status";
        case "cmi.entry":                               return "cmi.core.entry";
        case "cmi.exit":                                return "cmi.core.exit";
        case "cmi.location":                            return "cmi.core.lesson_location";
        case "cmi.max_time_allowed":                    return "cmi.student_data.max_time_allowed";
        case "cmi.mode":                                return "cmi.core.lesson_mode";
        case "cmi.scaled_passing_score":                return "cmi.student_data.mastery_score";
        case "cmi.session_time":                        return "cmi.core.session_time";
        case "cmi.student_preference.audio_captioning": return "cmi.student_preference.text";
        case "cmi.student_preference.audio_level":      return "cmi.student_preference.audio";
        case "cmi.student_preference.delivery_speed":   return "cmi.student_preference.speed";
        case "cmi.time_limit_action":                   return "cmi.student_data.time_limit_action";
        case "cmi.total_time":                          return "cmi.core.total_time";
        
        default:                                        return p_sElement;
    }
}

// p_sElement   The CMI element for which the value is to be retrieved
function F10_RAL_1_2_GetValue( p_sElement )
{
    if ( p_sElement.indexOf( "cmi.interactions." ) != -1 )
    {
        if ( p_sElement.indexOf( ".latency" ) != -1 )
        {
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 2004":
                    return F10_RAL_Get1_2To2004TimeInterval( F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) ) );
                default:
                    return F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) );
            }
        }
        
		if ( p_sElement.indexOf( ".learner_response" ) != -1 )
		{
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 2004":
					if ( F10_RAL["CMI"][p_sElement] )
						return F10_RAL["CMI"][p_sElement];
					else
		                return F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) );
                default:
                    return F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) );
            }
		}
		
        if ( p_sElement.indexOf( ".timestamp" ) != -1 )
            return F10_RAL_Get1_2To2004Time( F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement.replace( /\.timestamp/g, ".time" ) ) ) );
    }
    
    switch ( p_sElement )
    {
        // time interval data types
        case "cmi.total_time":
        case "cmi.session_time":
        case "cmi.max_time_allowed":
            return F10_RAL_Get1_2To2004TimeInterval( F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) ) );
        case "cmi.scaled_passing_score":
            return String ( Number( F10_RAL["API"].LMSGetValue( "cmi.student_data.mastery_score" ) ) / 100 );
        
        default:
            return F10_RAL["API"].LMSGetValue( F10_RAL_1_2_GetCMIElement( p_sElement ) );
    }
}

// p_sElement   The CMI element to be set
// p_sValue     The value to which the CMI element is to be set
function F10_RAL_1_2_SetValue( p_sElement, p_sValue )
{
    if ( p_sElement.indexOf( "cmi.interactions." ) != -1 )
    {
        if ( p_sElement.indexOf( ".latency" ) != -1 )
        {
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 2004":
                    return F10_RAL["API"].LMSSetValue( F10_RAL_1_2_GetCMIElement( p_sElement ), F10_RAL_Get2004To1_2TimeInterval( p_sValue ) );
                default:
                    return F10_RAL["API"].LMSSetValue( F10_RAL_1_2_GetCMIElement( p_sElement ), p_sValue );
            }
        }
        
		if ( p_sElement.indexOf( ".learner_response" ) != -1 )
		{
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 2004":
					F10_RAL["CMI"][p_sElement] = p_sValue;
					break;
            }
		}
		
        if ( p_sElement.indexOf( ".timestamp" ) != -1 )
            return F10_RAL["API"].LMSSetValue( F10_RAL_1_2_GetCMIElement( p_sElement.replace( /\.timestamp/g, ".time" ) ), F10_RAL_Get2004To1_2Time( p_sValue ) );
    }
    
    switch ( p_sElement )
    {
        // time interval data types
        case "cmi.total_time":
        case "cmi.session_time":
        case "cmi.max_time_allowed":
            return F10_RAL["API"].LMSSetValue( F10_RAL_1_2_GetCMIElement( p_sElement ), F10_RAL_Get2004To1_2TimeInterval( p_sValue ) );
        case "cmi.scaled_passing_score":
            return F10_RAL["API"].LMSSetValue( "cmi.student_data.mastery_score", ( Number( p_sValue ) * 100 ) );
        
        default:
            return F10_RAL["API"].LMSSetValue( F10_RAL_1_2_GetCMIElement( p_sElement ), p_sValue );
    }
}


// CONVERTERS TO 2004 (used when the LMS is using SCORM 2004)

// p_sElement   The CMI element to be converted
function F10_RAL_2004_GetCMIElement( p_sElement )
{
    p_sElement = p_sElement.replace( /\.core\./g, "." );
    p_sElement = p_sElement.replace( /\.student_data\./g, "." );
    p_sElement = p_sElement.replace( /lesson_/g, "" );
    p_sElement = p_sElement.replace( /student_/g, "learner_" );
    
    switch ( p_sElement )
    {
        case "cmi.comments":                    return "cmi.comments_from_learner.0.comment";
        case "cmi.comments_from_lms":           return "cmi.comments_from_lms.0.comment";
        case "cmi.learner_preference.audio":    return "cmi.learner_preference.audio_level";
        case "cmi.learner_preference.speed":    return "cmi.learner_preference.delivery_speed";
        case "cmi.learner_preference.text":     return "cmi.learner_preference.audio_captioning";
        
        default:                                return p_sElement;
    }
}

// p_sElement   The CMI element for which the value is to be retrieved
function F10_RAL_2004_GetValue( p_sElement )
{
    if ( p_sElement.indexOf( "cmi.objectives." ) != -1 )
    {
        var sSuccessStatus = F10_RAL["API"].GetValue( p_sElement.replace( /\.status/g, ".success_status" ) );
        if ( sSuccessStatus == "passed" || sSuccessStatus == "failed" )
            return sSuccessStatus;
        else
            return F10_RAL["API"].GetValue( p_sElement.replace( /\.status/g, ".completion_status" ) );
    }
    
    if ( p_sElement.indexOf( "cmi.interactions." ) != -1 )
    {
        if ( p_sElement.indexOf( ".latency" ) != -1 )
        {
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 1.2":
                    return F10_RAL_Get2004To1_2TimeInterval( F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( p_sElement ) ) );
                default:
                    return F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( p_sElement ) );
            }
        }
        
        if ( p_sElement.indexOf( ".time" ) != -1 )
        {
            var sElement = p_sElement.replace( /\.time/g, ".timestamp" );
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 1.2":
                    return F10_RAL_Get2004To1_2Time( F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( sElement ) ) );
                default:
                    return F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( p_sElement ) );
            }
        }
    }
    
    switch ( p_sElement )
    {
        case "cmi.core._children":
            return "student_id,student_name,lesson_location,credit,lesson_status,entry,score,total_time,lesson_mode,exit,session_time";
        case "cmi.core.lesson_status":
            var sSuccessStatus = F10_RAL["API"].GetValue( "cmi.success_status" );
            if ( sSuccessStatus == "passed" || sSuccessStatus == "failed" )
                return sSuccessStatus;
            else
                return F10_RAL["API"].GetValue( "cmi.completion_status" );
        case "cmi.student_data._children":
            return "mastery_score,max_time_allowed,time_limit_action";
        case "cmi.student_data.mastery_score":
            return Number( F10_RAL["API"].GetValue( "cmi.scaled_passing_score" ) ) * 100;
        // time interval data types
        case "cmi.core.total_time":
        case "cmi.core.session_time":
        case "cmi.student_data.max_time_allowed":
            return F10_RAL_Get2004To1_2TimeInterval( F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( p_sElement ) ) );
        
        default:
            return F10_RAL["API"].GetValue( F10_RAL_2004_GetCMIElement( p_sElement ) );
    }
}

// p_sElement   The CMI element to be set
// p_sValue     The value to which the CMI element is to be set
function F10_RAL_2004_SetValue( p_sElement, p_sValue )
{
    if ( p_sElement.indexOf( "cmi.objectives." ) != -1 )
    {
        if ( p_sValue == "passed" || p_sValue == "failed" )
            return F10_RAL["API"].SetValue( p_sElement.replace( /\.status/g, ".success_status" ), p_sValue );
        else
            return F10_RAL["API"].SetValue( p_sElement.replace( /\.status/g, ".completion_status" ), p_sValue );
    }
    
    if ( p_sElement.indexOf( "cmi.interactions." ) != -1 )
    {
        if ( p_sElement.indexOf( "latency" ) != -1 )
        {
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 1.2":
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), F10_RAL_Get1_2To2004TimeInterval( p_sValue ) );
                default:
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), p_sValue );
            }
        }
        
        if ( p_sElement.indexOf( "time" ) != -1 )
        {
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 1.2":
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), F10_RAL_Get1_2To2004Time( p_sValue ) );
                default:
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), p_sValue );
            }
        }
    }
    
    switch ( p_sElement )
    {
        case "cmi.core.lesson_status":
			// setting success status
			var value = p_sValue;
			if ( value == "completed" )
				value = "passed";
			if ( value == "incomplete" || value == "not attempted" )
				value = "unknown";
			F10_RAL["API"].SetValue( "cmi.success_status", value );
			
			// setting completion status
			value = p_sValue;
			if ( value == "passed" || value == "failed" )
				value = "completed";
			return F10_RAL["API"].SetValue( "cmi.completion_status", value );
		case "cmi.core.score.raw":
            var ret_val = F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), p_sValue );
			F10_RAL["API"].SetValue( "cmi.score.scaled", (p_sValue/100) );
			return ret_val;
        case "cmi.student_data.mastery_score":
            return F10_RAL["API"].SetValue( "cmi.scaled_passing_score", ( Number( p_sValue ) / 100 ) );
        
        // time interval data types
        case "cmi.core.total_time":
        case "cmi.core.session_time":
        case "cmi.student_data.max_time_allowed":
            switch ( F10_RAL["Content_Type"] )
            {
                case "SCORM 1.2":
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), F10_RAL_Get1_2To2004TimeInterval( p_sValue ) );
                default:
                    return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), p_sValue );
            }
        
        default:
            return F10_RAL["API"].SetValue( F10_RAL_2004_GetCMIElement( p_sElement ), p_sValue );
    }
}

// p_sTime          YYYY-MM-DDTHH:MM:SS.SS -> HH:MM:SS.SS
function F10_RAL_Get2004To1_2Time( p_sTime )
{
    if ( p_sTime.indexOf("T") != -1 )
        return p_sTime.slice( p_sTime.indexOf("T") + 1 );
    else
        return "";
}

// p_sTime          HH:MM:SS.SS -> YYYY-MM-DDTHH:MM:SS.SS
function F10_RAL_Get1_2To2004Time( p_sTime )
{
    return "T" + p_sTime;
}

// p_sTimeInterval  P#Y#M#DT#H#M#S -> HHHH:MM:SS.SS
function F10_RAL_Get2004To1_2TimeInterval( p_sTimeInterval )
{
    var sTimeInterval = p_sTimeInterval.slice(1);
    var nHours = 0;
    var nMinutes = 0;
    var nSeconds = 0;
    var sFractionalSeconds = 0;
    var nTIndex = -1;
    
    var nYearIndex = sTimeInterval.indexOf("Y");
    if ( nYearIndex != -1 )
    {
        nSeconds += Number( sTimeInterval.slice( 0, nYearIndex ) ) * 365 * 24 * 60 * 60;
        sTimeInterval = sTimeInterval.slice( nYearIndex + 1);
    }
    var nMonthIndex = sTimeInterval.indexOf("M");
    nTIndex = sTimeInterval.indexOf("T");
    if ( nMonthIndex != -1 && nMonthIndex < nTIndex )
    {
        nSeconds += Number( sTimeInterval.slice( 0, nMonthIndex ) ) * 28 * 24 * 60 * 60; // assumes 28 days a month
        sTimeInterval = sTimeInterval.slice( nMonthIndex + 1);
    }
    var nDayIndex = sTimeInterval.indexOf("D");
    if ( nDayIndex != -1 )
    {
        nSeconds += Number( sTimeInterval.slice( 0, nDayIndex ) ) * 24 * 60 * 60;
        sTimeInterval = sTimeInterval.slice( nDayIndex + 1);
    }
    nTIndex = sTimeInterval.indexOf("T");
    if ( nTIndex != -1 )
        sTimeInterval = sTimeInterval.slice( nTIndex + 1);
    var nHourIndex = sTimeInterval.indexOf("H");
    if ( nHourIndex != -1 )
    {
        nSeconds += Number( sTimeInterval.slice( 0, nHourIndex ) ) * 60 * 60;
        sTimeInterval = sTimeInterval.slice( nHourIndex + 1);
    }
    var nMinuteIndex = sTimeInterval.indexOf("M");
    if ( nMinuteIndex != -1 )
    {
        nSeconds += Number( sTimeInterval.slice( 0, nMinuteIndex ) ) * 60;
        sTimeInterval = sTimeInterval.slice( nMinuteIndex + 1);
    }
    var nSecondIndex = sTimeInterval.indexOf("S");
    if ( nSecondIndex != -1 )
    {
        var sOriginalSeconds = sTimeInterval.slice( 0, nSecondIndex );
        nSeconds += Math.floor( Number( sOriginalSeconds ) );
        if ( sOriginalSeconds.indexOf(".") != -1 )
            sFractionalSeconds = sOriginalSeconds.slice( sOriginalSeconds.indexOf(".") );
    }
    
    nMinutes = Math.floor( nSeconds / 60 );
    nSeconds = ( nSeconds % 60 ) + sFractionalSeconds;
    if ( Number( nSeconds ) < 10 )
        nSeconds = "0" + nSeconds;
    nHours = Math.floor( nMinutes / 60 );
    nMinutes = nMinutes % 60;
    if ( nMinutes < 10 )
        nMinutes = "0" + nMinutes;
    if ( nHours < 10 )
        nHours = "0" + nHours;
    else if ( nHours > 9999 )
        nHours = 9999;
    
    return nHours + ":" + nMinutes + ":" + nSeconds;
}

// p_sTimeInterval  HHHH:MM:SS.SS -> P#Y#M#DT#H#M#S
function F10_RAL_Get1_2To2004TimeInterval( p_sTimeInterval )
{
    var asTimespan = p_sTimeInterval.split( ":" );
    var nHours = Number( asTimespan[0] );
    var nMinutes = Number( asTimespan[1] );
    var nSeconds = Number( asTimespan[2] );
    
    var nDays = 0;
    var nYears = 0;
    if ( nHours >= 24 )
    {
        nDays = Math.floor( nHours / 24 );
        nHours = nHours % 24;
    }
    if ( nDays >= 1 )
    {
        nYears = Math.floor( nDays / 365 );
        nDays = nDays % 365;
    }
    
    return "P" + nYears + "Y" + nDays + "DT" + nHours + "H" + nMinutes + "M" + nSeconds + "S";
}

function get_scorm_time_from_milliseconds( p_nMilliseconds )
{
  // resultant times
  var nCarryOver = 0;
  var nMilliseconds = Math.floor(p_nMilliseconds / 10) * 10; // rounding off last digit
  var nSeconds = (nMilliseconds / 1000) % 60;
  nCarryOver = Math.floor(nMilliseconds / 1000 / 60);
  var nMinutes = nCarryOver % 60;
  nCarryOver = Math.floor(nCarryOver / 60);
  var nHours = nCarryOver;

  // applying formatting
  // hours
  var sHours = String(nHours);
  if ( nHours < 10000 )
  { 
    var nMissingZeros = 4 - sHours.length;
    for ( var i = 0; i < nMissingZeros; i++ )
      sHours = "0" + sHours;
  }
  else
    sHours = "9999";
  // minutes
  var sMinutes = String(nMinutes);
  if ( sMinutes.length < 2 )
    sMinutes = "0" + sMinutes;
  // seconds
  var sSeconds = String(nSeconds);
  if ( sSeconds.indexOf(".") == -1 )
    sSeconds += ".0";
  if ( sSeconds.slice(0, sSeconds.indexOf(".")).length < 2 )
    sSeconds = "0" + sSeconds;
  if ( sSeconds.indexOf(".") != -1 && sSeconds.length > 5 )
    sSeconds = sSeconds.slice(0, 5);

  return sHours + ":" + sMinutes + ":" + sSeconds;
}
