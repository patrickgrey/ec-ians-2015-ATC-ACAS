// NOTE: Course level tracking 
// assumes TrackingData exists
// currently, this means that SCO Level = Course
function fbCourseFinished()
{
	var aTD = TrackingData;
	for ( sSCO_ID in aTD )
	{
		if( aTD[ sSCO_ID ]["Include_In_Course_Credit"] )
		{
			if ( aTD[ sSCO_ID ]["Status"] != "passed"
				&& aTD[ sSCO_ID ]["Status"] != "failed"
				&& aTD[ sSCO_ID ]["Status"] != "completed" )
			{
				return false;
			}
		}
	}
	
	return true;
}
// inline comments describe method of determining status
function fsGetCourseStatus()
{
	var aTD = TrackingData;
	
	// if no SCO was failed, but one or more elements are incomplete, the course is considered incomplete
	if ( !fbCourseFinished() )
		return "incomplete";
	
	// if any SCO was failed, the course is considered failed
	// if it is for credit
	for ( sSCO_ID in aTD )
	{
		if ( isForCredit(aTD[ sSCO_ID ]) && aTD[ sSCO_ID ]["Status"] == "failed" )
			return "failed";
	}
	
	// if every SCO is completed and none are failed, then the course is considered passed if the course is for credit
	// and completed if it is not for credit
	if ( fsGetCourseCredit() == "credit" )
		return "passed";
	else
		return "completed";
}
// the course score is equal to the average of the scores of all SCOs that are for credit
function fsGetCourseScore()
{
	var aTD = TrackingData;
	var nScore = 0;
	var nNumCreditSCOs = 0;
	
	for ( sSCO_ID in aTD )
	{
		var sco = aTD[ sSCO_ID ];
		if ( isForCredit(sco) && (sco["Cluster Type"] != "UL" || (sco["Cluster Type"] == "UL" && sco["Status"] != "completed")) )//'UL' & 'SCORE' -> imported SCORM
		{
			nScore += Number( aTD[ sSCO_ID ]["Score"] );
			nNumCreditSCOs++;
		}
	}
	
	if ( nNumCreditSCOs > 0 )
		nScore = Math.floor( nScore / nNumCreditSCOs );
	
	return nScore;
}
function isForCredit( SCO )
{
	return SCO["Credit"] == "credit" || isImportedSCORM( SCO  )
}
function isImportedSCORM( SCO )
{
	return SCO["Cluster Type"] == 'UL' &&  isNumber(SCO["Score"])
}
function isNumber( target )
{
	return target !== '' && target != null && !isNaN(target)  
}
// if any SCO is for credit, the course is for credit, otherwise the course is no-credit
function fsGetCourseCredit()
{
	var aTD = TrackingData;
	for ( sSCO_ID in aTD )
		if ( isForCredit( aTD[ sSCO_ID ]) )
			return "credit";
	
	return "no-credit";
}
